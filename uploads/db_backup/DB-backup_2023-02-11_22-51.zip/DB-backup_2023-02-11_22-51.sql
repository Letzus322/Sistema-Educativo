#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `balance` double(18,2) NOT NULL DEFAULT 0.00,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: advance_salary
#

DROP TABLE IF EXISTS `advance_salary`;

CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `deduct_month` varchar(20) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `reason` text CHARACTER SET utf32 COLLATE utf32_unicode_ci DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `paid_date` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=pending,2=paid,3=rejected',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `issued_by` varchar(200) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS `attachments`;

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `type_id` int(11) NOT NULL,
  `uploader_id` varchar(20) NOT NULL,
  `class_id` varchar(20) DEFAULT 'unfiltered',
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `subject_id` varchar(200) DEFAULT 'unfiltered',
  `session_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: attachments_type
#

DROP TABLE IF EXISTS `attachments_type`;

CREATE TABLE `attachments_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: award
#

DROP TABLE IF EXISTS `award`;

CREATE TABLE `award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `gift_item` varchar(255) NOT NULL,
  `award_amount` decimal(18,2) NOT NULL,
  `award_reason` text NOT NULL,
  `given_date` date NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book
#

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `author` varchar(255) NOT NULL,
  `isbn_no` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `description` text NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `total_stock` varchar(20) NOT NULL,
  `issued_copies` varchar(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book_category
#

DROP TABLE IF EXISTS `book_category`;

CREATE TABLE `book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book_issues
#

DROP TABLE IF EXISTS `book_issues`;

CREATE TABLE `book_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(18,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = accepted, 2 = rejected, 3 = returned',
  `issued_by` varchar(255) DEFAULT NULL,
  `return_by` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `stu_generate` tinyint(3) NOT NULL DEFAULT 0,
  `stu_username_prefix` varchar(255) NOT NULL,
  `stu_default_password` varchar(255) NOT NULL,
  `grd_generate` tinyint(3) NOT NULL DEFAULT 0,
  `grd_username_prefix` varchar(255) NOT NULL,
  `grd_default_password` varchar(255) NOT NULL,
  `teacher_restricted` tinyint(1) DEFAULT 1,
  `due_days` float NOT NULL DEFAULT 30,
  `due_with_fine` tinyint(4) NOT NULL DEFAULT 1,
  `unique_roll` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: bulk_msg_category
#

DROP TABLE IF EXISTS `bulk_msg_category`;

CREATE TABLE `bulk_msg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT 'sms=1, email=2',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: bulk_sms_email
#

DROP TABLE IF EXISTS `bulk_sms_email`;

CREATE TABLE `bulk_sms_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) DEFAULT NULL,
  `sms_gateway` varchar(55) DEFAULT '0',
  `message` text DEFAULT NULL,
  `email_subject` varchar(255) DEFAULT NULL,
  `message_type` tinyint(3) DEFAULT 0 COMMENT 'sms=1, email=2',
  `recipient_type` tinyint(3) NOT NULL COMMENT 'group=1, individual=2, class=3',
  `recipients_details` longtext DEFAULT NULL,
  `additional` longtext DEFAULT NULL,
  `schedule_time` datetime DEFAULT NULL,
  `posting_status` tinyint(3) NOT NULL COMMENT 'schedule=1,competed=2',
  `total_thread` int(11) NOT NULL,
  `successfully_sent` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: call_log
#

DROP TABLE IF EXISTS `call_log`;

CREATE TABLE `call_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `purpose_id` int(11) DEFAULT NULL,
  `call_type` tinyint(1) DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `follow_up` date DEFAULT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: call_purpose
#

DROP TABLE IF EXISTS `call_purpose`;

CREATE TABLE `call_purpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: card_templete
#

DROP TABLE IF EXISTS `card_templete`;

CREATE TABLE `card_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `layout_width` varchar(11) NOT NULL DEFAULT '54',
  `layout_height` varchar(11) NOT NULL DEFAULT '86',
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: certificates_templete
#

DROP TABLE IF EXISTS `certificates_templete`;

CREATE TABLE `certificates_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `page_layout` tinyint(1) NOT NULL,
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: class
#

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_numeric` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: complaint
#

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `assigned_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `date_of_solution` date DEFAULT NULL,
  `file` varchar(500) NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: complaint_type
#

DROP TABLE IF EXISTS `complaint_type`;

CREATE TABLE `complaint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_field
#

DROP TABLE IF EXISTS `custom_field`;

CREATE TABLE `custom_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(50) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text DEFAULT NULL,
  `field_type` enum('text','textarea','dropdown','date','checkbox','number','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `show_on_table` varchar(5) DEFAULT NULL,
  `field_order` int(11) NOT NULL,
  `bs_column` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_fields_online_values
#

DROP TABLE IF EXISTS `custom_fields_online_values`;

CREATE TABLE `custom_fields_online_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_fields_values
#

DROP TABLE IF EXISTS `custom_fields_values`;

CREATE TABLE `custom_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_pass` varchar(255) DEFAULT NULL,
  `smtp_port` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (1, 'account_registered', '{institute_name}, {name}, {login_username}, {password}, {user_role}, {login_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (2, 'forgot_password', '{institute_name}, {username}, {email}, {reset_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (3, 'change_password', '{institute_name}, {name}, {email}, {password}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (4, 'new_message_received', '{institute_name}, {recipient}, {message}, {message_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (5, 'payslip_generated', '{institute_name}, {username}, {month_year}, {payslip_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (6, 'award', '{institute_name}, {winner_name}, {award_name}, {gift_item}, {award_reason}, {given_date}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (7, 'leave_approve', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (8, 'leave_reject', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (9, 'advance_salary_approve', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (10, 'advance_salary_reject', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (11, 'apply_online_admission', '{institute_name}, {admission_id}, {applicant_name}, {applicant_mobile}, {class}, {section}, {apply_date}, {payment_url}, {admission_copy_url}, {paid_amount}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (12, 'student_admission', '{institute_name}, {academic_year}, {admission_date}, {admission_no}, {roll}, {category}, {student_name}, {student_mobile}, {class}, {section}, {login_username}, {password}, {login_url}');


#
# TABLE STRUCTURE FOR: email_templates_details
#

DROP TABLE IF EXISTS `email_templates_details`;

CREATE TABLE `email_templates_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_body` text NOT NULL,
  `notified` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry
#

DROP TABLE IF EXISTS `enquiry`;

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` tinyint(1) DEFAULT 0,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `previous_school` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `reference_id` int(11) NOT NULL,
  `response_id` int(11) NOT NULL,
  `response` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(255) NOT NULL,
  `assigned_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `no_of_child` float NOT NULL,
  `class_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_follow_up
#

DROP TABLE IF EXISTS `enquiry_follow_up`;

CREATE TABLE `enquiry_follow_up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `next_date` date NOT NULL,
  `response` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `note` varchar(255) NOT NULL,
  `follow_up_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_reference
#

DROP TABLE IF EXISTS `enquiry_reference`;

CREATE TABLE `enquiry_reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_response
#

DROP TABLE IF EXISTS `enquiry_response`;

CREATE TABLE `enquiry_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enroll
#

DROP TABLE IF EXISTS `enroll`;

CREATE TABLE `enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` tinyint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: event
#

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` text NOT NULL,
  `audition` longtext NOT NULL,
  `selected_list` longtext NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `show_web` tinyint(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: event_types
#

DROP TABLE IF EXISTS `event_types`;

CREATE TABLE `event_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam
#

DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) NOT NULL COMMENT '1=mark,2=gpa,3=both',
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `remark` text NOT NULL,
  `mark_distribution` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam_attendance
#

DROP TABLE IF EXISTS `exam_attendance`;

CREATE TABLE `exam_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, L=Late',
  `remark` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam_hall
#

DROP TABLE IF EXISTS `exam_hall`;

CREATE TABLE `exam_hall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hall_no` longtext NOT NULL,
  `seats` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam_mark_distribution
#

DROP TABLE IF EXISTS `exam_mark_distribution`;

CREATE TABLE `exam_mark_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam_term
#

DROP TABLE IF EXISTS `exam_term`;

CREATE TABLE `exam_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fee_allocation
#

DROP TABLE IF EXISTS `fee_allocation`;

CREATE TABLE `fee_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `prev_due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fee_fine
#

DROP TABLE IF EXISTS `fee_fine`;

CREATE TABLE `fee_fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `fine_value` varchar(20) NOT NULL,
  `fine_type` varchar(20) NOT NULL,
  `fee_frequency` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fee_groups
#

DROP TABLE IF EXISTS `fee_groups`;

CREATE TABLE `fee_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `system` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fee_groups_details
#

DROP TABLE IF EXISTS `fee_groups_details`;

CREATE TABLE `fee_groups_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_groups_id` int(11) NOT NULL,
  `fee_type_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fee_payment_history
#

DROP TABLE IF EXISTS `fee_payment_history`;

CREATE TABLE `fee_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allocation_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `collect_by` varchar(20) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL,
  `fine` decimal(18,2) NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `remarks` longtext NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fees_reminder
#

DROP TABLE IF EXISTS `fees_reminder`;

CREATE TABLE `fees_reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(255) NOT NULL,
  `days` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `student` tinyint(3) NOT NULL,
  `guardian` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fees_type
#

DROP TABLE IF EXISTS `fees_type`;

CREATE TABLE `fees_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `fee_code` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `system` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Welcome to School', 'Best Education Mangment Systems', 'About Us', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat rutrum eros amet sollicitudin interdum. Suspendisse pulvinar, velit nec pharetra interdum, ante tellus ornare mi, et mollis tellus neque vitae elit. Mauris adipiscing mauris fringilla turpis interdum sed pulvinar nisi malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n                        </p>\r\n                        <p>\r\n                            Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula. Mauris sit amet neque nec nunc gravida. \r\n                        </p>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                    <li><a href=\"#\">Dermitology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                        </div>', 'about1.jpg', 'about1.png', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_admission
#

DROP TABLE IF EXISTS `front_cms_admission`;

CREATE TABLE `front_cms_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `terms_conditions_title` varchar(255) DEFAULT NULL,
  `terms_conditions_description` text NOT NULL,
  `fee_elements` text DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_admission` (`id`, `title`, `description`, `page_title`, `terms_conditions_title`, `terms_conditions_description`, `fee_elements`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Make An Admission', '<p>Lorem ipsum dolor sit amet, eum illum dolore concludaturque ex, ius latine adipisci no. Pro at nullam laboramus definitiones. Mandamusconceptam omittantur cu cum. Brute appetere it scriptorem ei eam, ne vim velit novum nominati. Causae volutpat percipitur at sed ne.</p>\r\n', 'Admission', '', '', '', 'admission1.jpg', 'Ramom - School Management System With CMS', 'Ramom  Admission Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_admitcard
#

DROP TABLE IF EXISTS `front_cms_admitcard`;

CREATE TABLE `front_cms_admitcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `templete_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_admitcard` (`id`, `page_title`, `templete_id`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Admit Card', 1, 'admit_card1.jpg', 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.', 'Ramom - School Management System With CMS', 'Ramom Admit Card Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_certificates
#

DROP TABLE IF EXISTS `front_cms_certificates`;

CREATE TABLE `front_cms_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_certificates` (`id`, `page_title`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Certificates', 'certificates1.jpg', 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.', 'Ramom - School Management System With CMS', 'Ramom Admit Card Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'WE\'D LOVE TO HEAR FROM YOU', 'Fusce convallis diam vitae velit tempus rutrum. Donec nisl nisl, vulputate eu sapien sed, adipiscing vehicula massa. Mauris eget commodo neque, id molestie enim.', 'contact-info-box1.png', 'Get in touch by filling the form below', '4896  Romrog Way, LOS ANGELES,\r\nCalifornia', '954-648-1802, \r\n963-612-1782', 'info@example.com\r\nsupport@example.com', 'Send', '<iframe width=\"100%\" height=\"350\" id=\"gmap_canvas\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3313.3833161665298!2d-118.03745848530627!3d33.85401093559897!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dd2c6c97f8f3ed%3A0x47b1bde165dcc056!2sOak+Dr%2C+La+Palma%2C+CA+90623%2C+USA!5e0!3m2!1sen!2sbd!4v1544238752504\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"></iframe>', 'Contact Us', 'contact1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_events
#

DROP TABLE IF EXISTS `front_cms_events`;

CREATE TABLE `front_cms_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_events` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Upcoming Events', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p><p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 'Events', 'events1.jpg', 'Ramom - School Management System With CMS', 'Ramom Events Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_exam_results
#

DROP TABLE IF EXISTS `front_cms_exam_results`;

CREATE TABLE `front_cms_exam_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `grade_scale` tinyint(1) NOT NULL,
  `attendance` tinyint(1) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_exam_results` (`id`, `page_title`, `grade_scale`, `attendance`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Exam Results', 1, 1, 'exam_results1.jpg', 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.', 'Ramom - School Management System With CMS', 'Ramom Admit Card Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Frequently Asked Questions', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p>\r\n\r\n<p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven&#39;t heard of them accusamus labore sustainable VHS.</p>', 'Faq', 'faq1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (1, 'Any Information you provide on applications for disability, life or accidental insurance ?', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (2, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (3, 'Opposed to using \'Content here, content here\', making it look like readable English ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (4, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (5, 'What types of documents are required to travel?', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari quilabores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n</ol>', 1);


#
# TABLE STRUCTURE FOR: front_cms_gallery
#

DROP TABLE IF EXISTS `front_cms_gallery`;

CREATE TABLE `front_cms_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_gallery` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Gallery', 'gallery1.jpg', 'Ramom - School Management System With CMS', 'Ramom Gallery  Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_gallery_category
#

DROP TABLE IF EXISTS `front_cms_gallery_category`;

CREATE TABLE `front_cms_gallery_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_gallery_content
#

DROP TABLE IF EXISTS `front_cms_gallery_content`;

CREATE TABLE `front_cms_gallery_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb_image` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `category_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `elements` longtext NOT NULL,
  `show_web` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (1, 'Welcome To Education', 'We will give you future', 'wellcome', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using content.\r\n\r\nMaking it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '{\"image\":\"wellcome1.png\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (2, 'Experience Teachers Team', NULL, 'teachers', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.', '{\"teacher_start\":\"0\",\"image\":\"featured-parallax1.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (3, 'WHY CHOOSE US', NULL, 'services', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (4, 'Request for a free Education Class', 'Medical Services', 'cta', '', '{\"mobile_no\":\"+2484-398-8987\",\"button_text\":\"Request Now\",\"button_url\":\"http:\\/\\/localhost\\/multi_pro\\/home\\/admission\\/\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (5, 'Wellcome To <span>Ramom</span>', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"View Services\",\"button_url1\":\"https:\\/\\/www.youtube.com\\/watch?v=Zec8KQmoSOU\",\"button_text2\":\"Learn More\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582779.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (6, 'Online <span>Live Class</span> Facility', NULL, 'slider', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"position\":\"c-left\",\"button_text1\":\"Read More\",\"button_url1\":\"#\",\"button_text2\":\"Get Started\",\"button_url2\":\"#\",\"image\":\"home-slider-1592582805.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (7, 'Online Classes', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-video\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (8, 'Scholarship', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-graduation-cap\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (9, 'Books & Liberary', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-book-reader\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (10, 'Trending Courses', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fab fa-discourse\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (11, 'WHAT PEOPLE SAYS', NULL, 'testimonial', 'Fusce sem dolor, interdum in efficitur at, faucibus nec lorem. Sed nec molestie justo.', '', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (12, '20 years experience in the field of study', NULL, 'statistics', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"image\":\"counter-parallax1.jpg\",\"widget_title_1\":\"Certified Teachers\",\"widget_icon_1\":\"fas fa-user-tie\",\"type_1\":\"teacher\",\"widget_title_2\":\"Students Enrolled\",\"widget_icon_2\":\"fas fa-user-graduate\",\"type_2\":\"student\",\"widget_title_3\":\"Classes\",\"widget_icon_3\":\"fas fa-graduation-cap\",\"type_3\":\"class\",\"widget_title_4\":\"Section\",\"widget_icon_4\":\"fas fa-award\",\"type_4\":\"section\"}', 1, 1);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`, `branch_id`) VALUES (1, 'Home', 'Ramom  Home Page', 'Ramom - School Management System With CMS', 1);


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `open_new_tab` int(11) NOT NULL DEFAULT 0,
  `ext_url` tinyint(3) NOT NULL DEFAULT 0,
  `ext_url_address` text DEFAULT NULL,
  `publish` tinyint(3) NOT NULL,
  `system` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (1, 'Home', 'index', 1, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (2, 'Events', 'events', 3, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (3, 'Teachers', 'teachers', 2, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (4, 'About Us', 'about', 4, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (5, 'FAQ', 'faq', 5, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (6, 'Online Admission', 'admission', 6, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (7, 'Contact Us', 'contact', 9, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (8, 'Pages', 'pages', 8, 0, 0, 1, '#', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (9, 'Admit Card', 'admit_card', 10, 8, 0, 0, '', 1, 1, 0, '2021-03-16 00:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (10, 'Exam Results', 'exam_results', 11, 8, 0, 0, '', 1, 1, 0, '2021-03-16 00:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (13, 'Certificates', 'certificates', 14, 8, 0, 0, '', 1, 1, 0, '2021-03-21 08:04:44');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (14, 'Gallery', 'gallery', 7, 0, 0, 0, '', 1, 1, 0, '2021-03-21 08:04:44');


#
# TABLE STRUCTURE FOR: front_cms_menu_visible
#

DROP TABLE IF EXISTS `front_cms_menu_visible`;

CREATE TABLE `front_cms_menu_visible` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `parent_id` varchar(11) DEFAULT NULL,
  `ordering` varchar(20) DEFAULT NULL,
  `invisible` tinyint(2) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`, `branch_id`) VALUES (1, 'Get Well Soon', 'Our Best <span>Services</span>', 'service_parallax1.jpg', 1);


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (1, 'Online Course Facilities', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text.', 'fas fa-headphones', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (2, 'Modern Book Library', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-book-open', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (3, 'Be Industrial Leader', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model.', 'fas fa-industry', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (4, 'Programming Courses', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will.', 'fas fa-code', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (5, 'Foreign Languages', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-language', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (6, 'Alumni Directory', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a for \'lorem ipsum\' will uncover.', 'fas fa-user-graduate', 1);


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `url_alias` varchar(255) DEFAULT NULL,
  `cms_active` tinyint(4) NOT NULL DEFAULT 0,
  `online_admission` tinyint(4) NOT NULL DEFAULT 0,
  `theme` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `copyright_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `footer_about_text` varchar(300) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `url_alias`, `cms_active`, `online_admission`, `theme`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `copyright_text`, `fav_icon`, `logo`, `footer_about_text`, `working_hours`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`, `branch_id`) VALUES (1, 'School Management System With CMS', 'example', 0, 1, 'red', 'disable', '', '', 'Your Address', '+12345678', '12345678', 'info@example.com', 'info@demo.com', 'Copyright © 2020 <span>Ramom</span>. All Rights Reserved.', 'fav_icon1.png', 'logo1.png', 'If you are going to use a passage LorIsum, you anythirassing hidden in the middle of text. Lators on the Internet tend to.', '<span>Hours : </span>  Mon To Fri - 10AM - 04PM,  Sunday Closed', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com', 1);


#
# TABLE STRUCTURE FOR: front_cms_teachers
#

DROP TABLE IF EXISTS `front_cms_teachers`;

CREATE TABLE `front_cms_teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_teachers` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Teachers', 'teachers1.jpg', 'Ramom - School Management System With CMS', 'Ramom  Teachers Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (1, 'Gartrell Wright', 'Los Angeles', 'defualt.png', 'Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 1, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (2, 'Clifton Hyde', 'Newyork City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (3, 'Emily Lemus', 'Los Angeles', 'defualt.png', '“Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 5, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (4, 'Michel Jhon', 'CEO', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 3, 2, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (5, 'Hilda Howard', 'Chicago City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 2, 1, '2019-08-23 08:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institution_code` varchar(255) NOT NULL,
  `reg_prefix` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `currency_symbol` varchar(100) NOT NULL,
  `sms_service_provider` varchar(100) NOT NULL,
  `session_id` int(11) NOT NULL,
  `translation` varchar(100) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `animations` varchar(100) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `date_format` varchar(100) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `cron_secret_key` varchar(255) DEFAULT NULL,
  `preloader_backend` tinyint(1) NOT NULL DEFAULT 1,
  `cms_default_branch` int(11) NOT NULL,
  `image_extension` text DEFAULT NULL,
  `image_size` float NOT NULL DEFAULT 1024,
  `file_extension` text DEFAULT NULL,
  `file_size` float DEFAULT 1024,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `global_settings` (`id`, `institute_name`, `institution_code`, `reg_prefix`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `sms_service_provider`, `session_id`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `cron_secret_key`, `preloader_backend`, `cms_default_branch`, `image_extension`, `image_size`, `file_extension`, `file_size`, `created_at`, `updated_at`) VALUES (1, 'aiacadec', 'RSM-', 'on', 'ramom@example.com', '', '', 'USD', '$', 'disabled', 4, 'english', '© 2022 Ramom School Management - NullCave.club', 'fadeInUp', 'America/Lima', 'd.M.Y', '', '', '', '', '', 2, 1, 'jpeg, jpg, bmp, png', '2048', 'txt, pdf, doc, xls, docx, xlsx, jpg, jpeg, png, gif, bmp, zip, mp4, 7z, wmv, rar', '2048', '2018-10-22 05:07:49', '2020-05-01 22:37:06');


#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grade_point` varchar(255) NOT NULL,
  `lower_mark` int(11) NOT NULL,
  `upper_mark` int(11) NOT NULL,
  `remark` text NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hall_allocation
#

DROP TABLE IF EXISTS `hall_allocation`;

CREATE TABLE `hall_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `hall_no` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: homework
#

DROP TABLE IF EXISTS `homework`;

CREATE TABLE `homework` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `date_of_homework` date NOT NULL,
  `date_of_submission` date NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `sms_notification` tinyint(2) NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `document` varchar(255) NOT NULL,
  `evaluation_date` date DEFAULT NULL,
  `evaluated_by` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: homework_evaluation
#

DROP TABLE IF EXISTS `homework_evaluation`;

CREATE TABLE `homework_evaluation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `rank` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: homework_submit
#

DROP TABLE IF EXISTS `homework_submit`;

CREATE TABLE `homework_submit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `message` varchar(355) NOT NULL,
  `enc_name` varchar(355) DEFAULT NULL,
  `file_name` varchar(355) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel
#

DROP TABLE IF EXISTS `hostel`;

CREATE TABLE `hostel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `address` longtext NOT NULL,
  `watchman` longtext NOT NULL,
  `remarks` longtext DEFAULT NULL,
  `branch_id` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel_category
#

DROP TABLE IF EXISTS `hostel_category`;

CREATE TABLE `hostel_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `description` longtext DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel_room
#

DROP TABLE IF EXISTS `hostel_room`;

CREATE TABLE `hostel_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `no_beds` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `bed_fee` decimal(18,2) NOT NULL,
  `remarks` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `lang_field` varchar(600) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'English', 'english', 1, '2018-11-15 06:36:31', '2020-04-18 20:05:12');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (4, 'French', 'french', 1, '2018-11-15 06:36:31', '2019-01-20 03:04:55');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (7, 'Italian', 'italian', 1, '2018-11-15 06:36:31', '2019-01-20 03:00:14');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (11, 'Portuguese', 'portuguese', 1, '2018-11-15 06:36:31', '2019-01-20 03:00:20');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (17, 'German', 'german', 1, '2018-11-15 06:36:31', '2019-03-29 02:44:39');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (19, 'Spanish', 'spanish', 1, '2018-11-15 06:36:31', '2019-03-29 02:44:39');


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) NOT NULL,
  `english` varchar(255) NOT NULL,
  `french` varchar(255) NOT NULL,
  `italian` varchar(255) NOT NULL,
  `portuguese` varchar(255) NOT NULL,
  `german` varchar(255) NOT NULL,
  `spanish` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1145 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1, 'language', 'Language', 'La langue', 'Lingua', 'Língua', 'Sprache', 'Idioma');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (2, 'attendance_overview', 'Attendance Overview', 'Aperçu de la fréquentation', 'Panoramica delle presenze', 'Visão geral de participação', 'Anwesenheitsübersicht', 'Resumen de asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (3, 'annual_fee_summary', 'Annual Fee Summary', 'Résumé des frais annuels', 'Riepilogo della tariffa annuale', 'Resumo da taxa anual', 'Jährliche Gebührenübersicht', 'Resumen anual de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (4, 'my_annual_attendance_overview', 'My Annual Attendance Overview', 'Mon assiduité annuelle', 'La mia panoramica sulla partecipazione annuale', 'Minha visão geral de comparecimento anual', 'Meine jährliche Anwesenheitsübersicht', 'Resumen de mi asistencia anual');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (5, 'schedule', 'Schedule', 'des horaires', 'orari', 'horários', 'Zeitplan', 'Calendario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (6, 'student_admission', 'Student Admission', 'Admission des étudiants', 'Ammissione degli studenti', 'Admissão de estudantes', 'Studentenzulassung', 'Admisión de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (7, 'returned', 'Returned', 'Revenu', 'tornati', 'Devolvida', 'Ist zurückgekommen', 'Devuelto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (8, 'user_name', 'User Name', 'Nom d\'utilisateur', 'Nome utente', 'Nome de usuário', 'Nutzername', 'Nombre de usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (9, 'rejected', 'Rejected', 'Rejeté', 'Respinto', 'Rejeitado', 'Abgelehnt', 'Rechazado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (10, 'route_name', 'Route Name', 'Nom de l\'itinéraire', 'Nome della rotta', 'Nome da rota', 'Routenname', 'Nombre de ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (11, 'route_fare', 'Route Fare', 'Tarif d\'itinéraire', 'Route Fare', 'Tarifa da rota', 'Routentarif', 'Tarifa de ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (12, 'edit_route', 'Edit Route', 'Modifier la route', 'Modifica la rotta', 'Editar rota', 'Route bearbeiten', 'Editar ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (13, 'this_value_is_required', 'This value is required.', 'Cette valeur est requise', 'Questo valore è richiesto', 'Este valor é obrigatório', 'Dieser Wert ist erforderlich.', 'Este valor es obligatorio.');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (14, 'vehicle_no', 'Vehicle No', 'Numéro de véhicule', 'N', 'Veículo não', 'Fahrzeug Nr', 'No vehiculo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (15, 'insurance_renewal_date', 'Insurance Renewal Date', 'Date de renouvellement de l&#39;assurance', 'Data di rinnovo dell\'assicurazione', 'Data de renovação do seguro', 'Verlängerungsdatum der Versicherung', 'Fecha de renovación del seguro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (16, 'driver_name', 'Driver Name', 'Nom du conducteur', 'Nome del driver', 'Nome do motorista', 'Fahrername', 'Nombre del conductor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (17, 'driver_license', 'Driver License', 'Permis de conduire', 'Patente di guida', 'Carteira de motorista', 'Führerschein', 'Licencia de conducir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (18, 'select_route', 'Select Route', 'Sélectionnez l\'itinéraire', 'Seleziona Route', 'Selecione a rota', 'Wählen Sie Route', 'Seleccionar ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (19, 'edit_vehicle', 'Edit Vehicle', 'Modifier le véhicule', 'Modifica il veicolo', 'Editar veículo', 'Fahrzeug bearbeiten', 'Editar vehículo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (20, 'add_students', 'Add Students', 'Ajouter des étudiants', 'Aggiungere gli studenti', 'Adicionar alunos', 'Schüler hinzufügen', 'Agregar alumnos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (21, 'vehicle_number', 'Vehicle Number', 'Numéro de véhicule', 'Numero di veicolo', 'Número do veículo', 'Fahrzeugnummer', 'Número de vehículo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (22, 'select_route_first', 'Select Route First', 'Sélectionnez l\'itinéraire d\'abord', 'Seleziona Route First', 'Selecione a rota primeiro', 'Wählen Sie Route zuerst', 'Seleccione la ruta primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (23, 'transport_fee', 'Transport Fee', 'Frais de transport', 'Tassa di trasporto', 'Tarifa de transporte', 'Transportkosten', 'Tarifa de transporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (24, 'control', 'Control', 'contrôle', 'controllo', 'ao controle', 'Steuerung', 'Control');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (25, 'set_students', 'Set Students', 'Mettre les élèves', 'Impostare gli studenti', 'Definir estudantes', 'Schüler einstellen', 'Establecer estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (26, 'hostel_list', 'Hostel List', 'Liste d\'auberges', 'Lista degli ostelli', 'Lista de albergue', 'Hostel List', 'Lista de albergues');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (27, 'watchman_name', 'Watchman Name', 'Nom du gardien', 'Nome guardiano', 'Nome do Vigilante', 'Name des Wächters', 'Nombre del vigilante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (28, 'hostel_address', 'Hostel Address', 'Adresse de l\'auberge', 'Indirizzo dell\'ostello', 'Endereço do albergue', 'Hostel Adresse', 'Dirección del albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (29, 'edit_hostel', 'Edit Hostel', 'Modifier hostel', 'Modifica ostello', 'Editar albergue', 'Edit Hostel', 'Editar albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (30, 'room_name', 'Room Name', 'Nom de la salle', 'Nome della stanza', 'Nome da sala', 'Raumname', 'Nombre de la habitación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (31, 'no_of_beds', 'No Of Beds', 'Nombre de lits', 'Numero di letti', 'Número de leitos', 'Anzahl der Betten', 'No de camas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (32, 'select_hostel_first', 'Select Hostel First', 'Sélectionnez l\'auberge en premier', 'Selezionare l\'ostello prima', 'Selecione albergue primeiro', 'Wählen Sie zuerst Hostel', 'Seleccione el albergue primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (33, 'remaining', 'Remaining', 'Restant', 'Rimanente', 'Restante', 'Verbleibend', 'Restante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (34, 'hostel_fee', 'Hostel Fee', 'Tarif de l\'auberge', 'Tariffa ostello', 'Taxa de albergue', 'Hostel Fee', 'Tarifa de albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (35, 'accountant_list', 'Accountant List', 'Liste comptable', 'Elenco dei contabili', 'Lista de contadores', 'Buchhalterliste', 'Lista de contadores');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (36, 'students_fees', 'Students Fees', 'Frais d\'étudiants', 'Le tasse degli studenti', 'Taxas de estudantes', 'Studentengebühren', 'Tarifas de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (37, 'fees_status', 'Fees Status', 'Statut des frais', 'Status dei diritti', 'Status de tarifas', 'Gebührenstatus', 'Estado de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (38, 'books', 'Books', 'livres', 'libri', 'Livros', 'Bücher', 'Libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (39, 'home_page', 'Home Page', 'Page d\'accueil', 'Home page', 'pagina inicial', 'Startseite', 'Página de inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (40, 'collected', 'Collected', 'collecté', 'raccolto', 'coletado', 'Gesammelt', 'Recogido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (41, 'student_mark', 'Student Mark', 'Marque étudiante', 'Marchio studente', 'Marca estudantil', 'Student Mark', 'Marca de estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (42, 'select_exam_first', 'Select Exam First', 'Sélectionnez l\'examen en premier', 'Selezionare l\'esame per primo', 'Selecione o exame primeiro', 'Wählen Sie zuerst Prüfung', 'Seleccione el examen primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (43, 'transport_details', 'Transport Details', 'Détails de transport', 'Dettagli di trasporto', 'Detalhes do transporte', 'Transport Details', 'Detalles de transporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (44, 'no_of_teacher', 'No of Teacher', 'Nombre de professeurs', 'Nemo autem magister', 'Não professor', 'Nein des Lehrers', 'No de profesor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (45, 'basic_details', 'Basic Details', 'Détails de base', 'Dettagli di base', 'Detalhes Básicos', 'Grundlegende Details', 'Detalles básicos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (46, 'fee_progress', 'Fee Progress', 'Progression des frais', 'Avanzamento della tassa', 'Progresso de taxas', 'Gebührenfortschritt', 'Progreso de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (47, 'word', 'Word', 'mot', 'parola', 'palavra', 'Wort', 'Palabra');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (48, 'book_category', 'Book Category', 'Catégorie livre', 'Categoria di libri', 'Categoria de livro', 'Buchkategorie', 'Categoría de libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (49, 'driver_phone', 'Driver Phone', 'Driver Phone', 'Telefono del conducente', 'Driver Phone', 'Fahrertelefon', 'Teléfono del conductor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (50, 'invalid_csv_file', 'Invalid / Corrupted CSV File', 'fichier CSV invalide / corrompu', 'file CSV non valido / danneggiato', 'arquivo CSV inválido / corrompido', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (51, 'requested_book_list', 'Requested Book List', 'Liste de livres demandée', 'L\'elenco dei libri richiesti', 'Lista de livros solicitada', 'Angeforderte Buchliste', 'Lista de libros solicitados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (52, 'request_status', 'Request Status', 'Statut de demande', 'Stato di richiesta', 'Status de solicitação', 'Anforderungsstatus', 'Estado de la solicitud');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (53, 'book_request', 'Book Request', 'Demande de livre', 'Richiesta di libro', 'Pedido de livro', 'Buchanfrage', 'Solicitud de libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (54, 'logout', 'Logout', 'Connectez - Out', 'logout', 'sair', 'Ausloggen', 'Cerrar sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (55, 'select_payment_method', 'Select Payment Method', 'Sélectionnez le mode de paiement', 'scegli il metodo di pagamento', 'Selecione o método de pagamento', 'Wählen Sie die Zahlungsmethode', 'Seleccionar forma de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (56, 'select_method', 'Select Method', 'Méthode choisie', 'Selezionare il metodo', 'Método selecionado', 'Wählen Sie Methode', 'Seleccionar método');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (57, 'payment', 'Payment', 'Paiement', 'Pagamento', 'Pagamento', 'Zahlung', 'Pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (58, 'filter', 'Filter', 'Filtre', 'Filtro', 'Filtro', 'Filter', 'Filtrar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (59, 'status', 'Status', 'statut', 'Stato', 'estado', 'Status', 'Estado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (60, 'paid', 'Paid', 'Payé', 'Pagato', 'Pago', 'Bezahlt', 'Pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (61, 'unpaid', 'Unpaid', 'Non payé', 'non pagato', 'não remunerado', 'Unbezahlt', 'No pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (62, 'method', 'Method', 'la méthode', 'metodo', 'Método', 'Methode', 'Método');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (63, 'cash', 'Cash', 'Argent liquide', 'Contanti', 'Dinheiro', 'Kasse', 'Efectivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (64, 'check', 'Check', 'Vérifier', 'Dai un\'occhiata', 'Verifica', 'Prüfen', 'Cheque');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (65, 'card', 'Card', 'Carte', 'Carta', 'Cartão', 'Karte', 'Tarjeta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (66, 'payment_history', 'Payment History', 'historique de paiement', 'Storico dei pagamenti', 'Histórico de pagamento', 'Zahlungshistorie', 'historial de pagos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (67, 'category', 'Category', 'Catégorie', 'Categoria', 'Categoria', 'Kategorie', 'Categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (68, 'book_list', 'Book List', 'Liste de livres', 'Lista di libri', 'Lista de livros', 'Bücherliste', 'Lista de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (69, 'author', 'Author', 'Auteur', 'Autore', 'Autor', 'Autor', 'Autor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (70, 'price', 'Price', 'Prix', 'Prezzo', 'Preço', 'Preis', 'Precio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (71, 'available', 'Available', 'Disponible', 'A disposizione', 'Disponível', 'Verfügbar', 'Disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (72, 'unavailable', 'Unavailable', 'Indisponible', 'non disponibile', 'Indisponível', 'Verfügbar', 'Disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (73, 'transport_list', 'Transport List', 'Liste des transports', 'Lista dei trasporti', 'Lista de transportes', 'Transportliste', 'Lista de transporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (74, 'edit_transport', 'Edit Transport', 'Modifier Transport', 'Modifica Trasporti', 'Editar Transportes', 'Transport bearbeiten', 'Editar transporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (75, 'hostel_name', 'Hostel Name', 'Nom Dortoir', 'Nome dormitorio', 'Nome dormitório', 'Hostel Name', 'Nombre del albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (76, 'number_of_room', 'Hostel Of Room', 'Nombre de chambres', 'Il numero di stanze', 'Número de salas', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (77, 'yes', 'Yes', 'Oui', 'sì', 'sim', 'Ja', 'si');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (78, 'no', 'No', 'Non', 'No', 'Não', 'Nein', 'No');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (79, 'messages', 'Messages', 'messages', 'messaggi', 'mensagens', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (80, 'compose', 'Compose', 'Ecrire un nouveau message', 'Scrivi nuovo messaggio', 'Escrever Nova Mensagem', 'Komponieren', 'Componer');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (81, 'recipient', 'Recipient', 'Bénéficiaire', 'Destinatario', 'beneficiário', 'Empfänger', 'Recipiente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (82, 'select_a_user', 'Select A User', 'Sélectionnez un utilisateur', 'Selezionare un utente', 'Selecione um usuário', 'Wählen Sie einen Benutzer', 'Seleccione un usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (83, 'send', 'Send', 'Envoyer', 'Inviare', 'Enviar', 'Senden', 'Enviar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (84, 'global_settings', 'Global Settings', 'Les paramètres du système', 'Impostazioni di sistema', 'Configurações de sistema', 'Globale Einstellungen', 'Ajustes globales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (85, 'currency', 'Currency', 'Devise', 'Moneta', 'Moeda', 'Währung', 'Moneda');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (86, 'system_email', 'System Email', 'système Email', 'sistema di posta elettronica', 'sistema de E-mail', 'System-E-Mail', 'Correo electrónico del sistema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (87, 'create', 'Create', 'créer', 'creare', 'crio', 'Erstellen', 'Crear');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (88, 'save', 'Save', 'sauvegarder', 'Salvare', 'Salvar', 'speichern', 'Salvar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (89, 'file', 'File', 'Fichier', 'File', 'Arquivo', 'Datei', 'Expediente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (90, 'theme_settings', 'Theme Settings', 'Réglage des thèmes', 'Impostazioni tema', 'Configurações de tema', 'Themen Einstellungen', 'Configuración de temas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (91, 'default', 'Default', 'Défaut', 'Predefinito', 'Padrão', 'Standard', 'Defecto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (92, 'select_theme', 'Select Theme', 'Sélectionne un thème', 'Seleziona il tema', 'Escolha um tema', 'Thema wählen', 'Seleccione el tema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (93, 'upload_logo', 'Upload Logo', 'Télécharger Logo', 'Carica Logo', 'Carregar Logo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (94, 'upload', 'Upload', 'Télécharger', 'Caricare', 'Envio', 'Hochladen', 'Subir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (95, 'remember', 'Remember', 'Rappelles toi', 'Ricorda', 'Lembrar', 'Merken', 'Recuerda');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (96, 'not_selected', 'Not Selected', 'Non séléctionné', 'Non selezionato', 'Não selecionado', 'Nicht ausgewählt', 'No seleccionado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (97, 'disabled', 'Disabled', 'désactivé', 'Disabilitato', 'Desativado', 'Behindert', 'Discapacitado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (98, 'inactive_account', 'Inactive Account', 'Compte inactif', 'Account inattivo', 'Conta inativa', 'Inaktives Benutzerkonto', 'Cuenta inactiva');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (99, 'update_translations', 'Update Translations', 'actualiser les traductions', 'aggiornare le traduzioni', 'atualizar traduções', 'Übersetzungen aktualisieren', 'Actualizar traducciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (100, 'language_list', 'Language List', 'Liste des langues', 'Elenco lingue', 'Lista idioma', 'Sprachliste', 'Lista de idiomas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (101, 'option', 'Option', 'Option', 'Opzione', 'Opção', 'Option', 'Opción');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (102, 'edit_word', 'Edit Word', 'modifier le mot', 'modifica parola', 'editar palavra', 'Wort bearbeiten', 'Editar palabra');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (103, 'update_profile', 'Update Profile', 'Mettre à jour le profil', 'Aggiorna il profilo', 'Atualizar perfil', 'Profil aktualisieren', 'Actualización del perfil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (104, 'current_password', 'Current Password', 'Mot de passe actuel', 'Password attuale', 'senha atual', 'derzeitiges Passwort', 'contraseña actual');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (105, 'new_password', 'New Password', 'nouveau mot de passe', 'nuova password', 'Nova senha', 'Neues Kennwort', 'Nueva contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (106, 'login', 'Login', 'S\'identifier', 'Accesso', 'Entrar', 'Anmeldung', 'Iniciar sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (107, 'reset_password', 'Reset Password', 'réinitialiser le mot de passe', 'Resetta la password', 'Trocar a senha', 'Passwort zurücksetzen', 'Restablecer la contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (108, 'present', 'Present', 'Présent', 'Presente', 'Presente', 'Vorhanden', 'Presente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (109, 'absent', 'Absent', 'Absent', 'Assente', 'Ausente', 'Abwesend', 'Ausente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (110, 'update_attendance', 'Update Attendance', 'Mise à jour de présence', 'Aggiornamento presenze', 'Presença atualização', 'Teilnahme aktualisieren', 'Actualización de asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (111, 'undefined', 'Undefined', 'Indéfini', 'Non definito', 'Indefinido', 'Nicht definiert', 'Indefinido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (112, 'back', 'Back', 'Arrière', 'Indietro', 'Costas', 'Zurück', 'atrás');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (113, 'save_changes', 'Save Changes', 'Sauvegarder les modifications', 'Salva I Cambiamenti', 'Salvar alterações', 'Änderungen speichern', 'Guardar cambios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (114, 'uploader', 'Uploader', 'Uploader', 'Uploader', 'Uploader', 'Uploader', 'Cargador');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (115, 'download', 'Download', 'Télécharger', 'Scaricare', 'baixar', 'Herunterladen', 'Descargar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (116, 'remove', 'Remove', 'Retirer', 'Cancella', 'Remover', 'Entfernen', 'Eliminar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (117, 'print', 'Print', 'Impression', 'Stampare', 'Impressão', 'Drucken', 'Impresión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (118, 'select_file_type', 'Select File Type', 'Sélectionner le type de fichier', 'Selezionare il tipo di file', 'Selecionar Tipo de Arquivo', 'Wählen Sie Dateityp', 'Seleccionar tipo de archivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (119, 'excel', 'Excel', 'Exceller', 'Eccellere', 'sobressair', 'Excel', 'Excel');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (120, 'other', 'Other', 'Autre', 'Altro', 'De outros', 'Andere', 'Otro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (121, 'students_of_class', 'Students Of Class', 'Les élèves de la classe', 'Gli studenti della classe', 'Os alunos da classe', 'Schüler der Klasse', 'Estudiantes de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (122, 'marks_obtained', 'Marks Obtained', 'Notes obtenues', 'Voti Ottenuti', 'notas obtidas', 'Erhaltene Noten', 'marcas obtenidas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (123, 'attendance_for_class', 'Attendance For Class', 'Participation Pour la classe', 'Partecipazione Per la Classe', 'Presença Para a Classe', 'Teilnahme am Unterricht', 'Asistencia a clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (124, 'receiver', 'Receiver', 'Récepteur', 'Ricevitore', 'recebedor', 'Empfänger', 'Receptor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (125, 'please_select_receiver', 'Please Select Receiver', 'S\'il vous plaît Sélectionnez Receiver', 'Selezionare Ricevitore', 'Selecione Receiver', 'Bitte wählen Sie Empfänger', 'Por favor seleccione receptor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (126, 'session_changed', 'Session Changed', 'session Changed', 'sessione cambiato', 'sessão Changed', 'Sitzung geändert', 'Sesión cambiada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (127, 'exam_marks', 'Exam Marks', 'Marques d\'examen', 'Marks esame', 'Marcas de exame', 'Prüfungsnoten', 'Marcas de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (128, 'total_mark', 'Total Mark', 'total Mark', 'Mark totale', 'total de Mark', 'Gesamtnote', 'Marca total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (129, 'mark_obtained', 'Mark Obtained', 'Mark Obtenu', 'Mark Ottenuto', 'Mark Obtido', 'Mark erhalten', 'Marca obtenida');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (130, 'invoice/payment_list', 'Invoice / Payment List', 'Facture / Liste de paiement', 'Fattura / Lista pagamento', 'Invoice / Lista de pagamento', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (131, 'obtained_marks', 'Obtained Marks', 'Les notes obtenues', 'punteggi ottenuti', 'notas obtidas', 'Erhaltene Noten', 'Marcas obtenidas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (132, 'highest_mark', 'Highest Mark', 'le plus élevé Mark', 'Massima Mark', 'maior Mark', 'Höchste Note', 'Marca más alta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (133, 'grade', 'Grade (GPA)', 'Qualité', 'Grado', 'Grau', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (134, 'dashboard', 'Dashboard', 'Tableau de bord', 'Cruscotto', 'painel de instrumentos', 'Instrumententafel', 'Tablero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (135, 'student', 'Student', 'Élève', 'Alunno', 'Aluna', 'Schüler', 'Estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (136, 'rename', 'Rename', 'rebaptiser', 'rinominare', 'renomear', 'Umbenennen', 'Rebautizar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (137, 'class', 'Class', 'Classe', 'Classe', 'Classe', 'Klasse', 'Clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (138, 'teacher', 'Teacher', 'Professeur', 'Insegnante', 'Professor', 'Lehrer', 'Profesor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (139, 'parents', 'Parents', 'Des parents', 'genitori', 'Pais', 'Eltern', 'Padres');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (140, 'subject', 'Subject', 'Assujettir', 'Soggetto', 'Sujeito', 'Gegenstand', 'Tema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (141, 'student_attendance', 'Student Attendance', 'Participation des étudiants', 'Frequenza degli studenti', 'Freqüência de estudantes', 'Teilnahme von Studenten', 'Asistencia estudiantil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (142, 'exam_list', 'Exam List', 'Liste d\'examen', 'Lista esame', 'Lista de exame', 'Prüfungsliste', 'Lista de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (143, 'grades_range', 'Grades Range', 'Gamme de notes', 'Gamma di gradi', 'Escala de notas', 'Notenbereich', 'Rango de Grados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (144, 'loading', 'Loading', 'chargement', 'Caricamento in corso', 'Carregando', 'Wird geladen', 'Cargando');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (145, 'library', 'Library', 'Bibliothèque', 'Biblioteca', 'Biblioteca', 'Bibliothek', 'Biblioteca');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (146, 'hostel', 'Hostel', 'Dortoir', 'Dormitorio', 'Dormitório', 'Hostel', 'Hostal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (147, 'events', 'Events', 'Tableau d\'affichage', 'Bacheca', 'Quadro de notícias', 'Veranstaltungen', 'Eventos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (148, 'message', 'Message', 'Message', 'Messaggio', 'Mensagem', 'Botschaft', 'Mensaje');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (149, 'translations', 'Translations', 'traductions', 'traduzioni', 'traduções', 'Übersetzungen', 'Traducciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (150, 'account', 'Account', 'Compte', 'account', 'Conta', 'Konto', 'Cuenta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (151, 'selected_session', 'Selected Session', 'session sélectionnée', 'sessione selezionata', 'sessão selecionada', 'Ausgewählte Sitzung', 'Sesión Seleccionada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (152, 'change_password', 'Change Password', 'Changer le mot de passe', 'Cambia la password', 'Mudar senha', 'Ausgewählte Sitzung', 'Sesión Seleccionada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (153, 'section', 'Section', 'Section', 'Sezione', 'Seção', 'Sektion', 'Sección');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (154, 'edit', 'Edit', 'modifier', 'Modifica', 'Editar', 'Bearbeiten', 'Editar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (155, 'delete', 'Delete', 'Effacer', 'cancellare', 'Excluir', 'Löschen', 'Eliminar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (156, 'cancel', 'Cancel', 'Annuler', 'Annulla', 'Cancelar', 'Stornieren', 'Cancelar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (157, 'parent', 'Parent', 'Parent', 'Genitore', 'parente', 'Elternteil', 'Padre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (158, 'attendance', 'Attendance', 'Présence', 'partecipazione', 'Comparecimento', 'Teilnahme', 'Asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (159, 'addmission_form', 'Admission Form', 'Formulaire d\'admission', 'Modulo di ammissione', 'Formulário de admissão', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (160, 'name', 'Name', 'prénom', 'Nome', 'Nome', 'Name', 'Nombre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (161, 'select', 'Select', 'Sélectionner', 'Selezionare', 'selecionar', 'Wählen', 'Seleccione');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (162, 'roll', 'Roll', 'Roulent', 'Rotolo', 'Rolo', 'Rollen', 'Rodar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (163, 'birthday', 'Date Of Birth', 'Anniversaire', 'Compleanno', 'Aniversário', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (164, 'gender', 'Gender', 'Le genre', 'Genere', 'Gênero', 'Geschlecht', 'Género');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (165, 'male', 'Male', 'Mâle', 'Maschio', 'Masculino', 'Männlich', 'Masculino');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (166, 'female', 'Female', 'Femelle', 'Femmina', 'Fêmea', 'Weiblich', 'Hembra');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (167, 'address', 'Address', 'Adresse', 'Indirizzo', 'Endereço', 'Adresse', 'Habla a');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (168, 'phone', 'Phone', 'Téléphone', 'Telefono', 'Telefone', 'Telefon', 'Teléfono');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (169, 'email', 'Email', 'Email', 'E-mail', 'O email', 'Email', 'Correo electrónico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (170, 'password', 'Password', 'Mot de passe', 'parola d\'ordine', 'Senha', 'Passwort', 'Contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (171, 'transport_route', 'Transport Route', 'Transport Route', 'Transport Route', 'Itinerários', 'Straßentransport', 'Transporte por carretera');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (172, 'photo', 'Photo', 'photo', 'Foto', 'foto', 'Foto', 'Foto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (173, 'select_class', 'Select Class', 'Sélectionnez la classe', 'Seleziona classe', 'Selecionar classe', 'Wählen Sie Klasse', 'Seleccione clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (174, 'username_password_incorrect', 'Username Or Password Is Incorrect', 'L\'identifiant ou le mot de passe est incorrect', 'Nome utente o password non sono corretti', 'Nome de usuário ou senha está incorreta', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (175, 'select_section', 'Select Section', 'Sélectionnez Section', 'Seleziona sezione', 'Select Section', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (176, 'options', 'Options', 'options de', 'Opzioni', 'opções', 'Optionen', 'Opciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (177, 'mark_sheet', 'Mark Sheet', 'Mark Sheet', 'Libretto universitario', 'Mark Sheet', 'Markierungsblatt', 'Marcar hoja');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (178, 'profile', 'Profile', 'Profil', 'Profilo', 'Perfil', 'Profil', 'Perfil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (179, 'select_all', 'Select All', 'Sélectionner tout', 'Seleziona tutto', 'Selecionar tudo', 'Wählen Sie Alle', 'Seleccionar todo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (180, 'select_none', 'Select None', 'Ne rien sélectionner', 'Non selezionare niente', 'Selecione nenhum', 'Nichts ausgewählt', 'No seleccionar ninguno');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (181, 'average', 'Average', 'Moyenne', 'Media', 'Média', 'Durchschnittlich', 'Promedio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (182, 'transfer', 'Transfer', 'transfert', 'trasferimento', 'transferir', 'Transfer', 'Transferir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (183, 'edit_teacher', 'Edit Teacher', 'Modifier enseignant', 'Modifica Maestro', 'Editar professor', 'Lehrer bearbeiten', 'Editar profesor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (184, 'sex', 'Sex', 'Sexe', 'Sesso', 'Sexo', 'Sex', 'Sexo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (185, 'marksheet_for', 'Marksheet For', 'Marquer les feuilles pour', 'fogli marchio per', 'Marcar folhas para', 'Markenblatt für', 'Hoja de cálculo para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (186, 'total_marks', 'Total Marks', 'total de points', 'Marks totali', 'total de Marcas', 'Gesamtnoten', 'Notas totales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (187, 'parent_phone', 'Parent Phone', 'Parent téléphone', 'Parent Phone', 'pais Telefone', 'Übergeordnetes Telefon', 'Teléfono de los padres');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (188, 'subject_author', 'Subject Author', 'Sujet Auteur', 'Autore del soggetto', 'Assunto Autor', 'Betreff Autor', 'Autor sujeto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (189, 'update', 'Update', 'Mettre à jour', 'Aggiornare', 'Atualizar', 'Aktualisieren', 'Actualizar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (190, 'class_list', 'Class List', 'Liste des classes', 'Lista Class', 'Lista de Classes', 'Klassenliste', 'Lista de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (191, 'class_name', 'Class Name', 'Nom du cours', 'Nome della classe', 'Nome da classe', 'Klassenname', 'Nombre de la clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (192, 'name_numeric', 'Name Numeric', 'Nom numérique', 'nome numerico', 'nome numérico', 'Name Numerisch', 'Nombre numérico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (193, 'select_teacher', 'Select Teacher', 'Sélectionnez ce professeur', 'Seleziona insegnante', 'Escolha um professor', 'Wählen Sie Lehrer', 'Seleccionar profesor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (194, 'edit_class', 'Edit Class', 'Modifier la classe', 'Modifica Class', 'Editar Classe', 'Klasse bearbeiten', 'Editar clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (195, 'section_name', 'Section Name', 'Nom de la section', 'Nome sezione', 'Nome da seção', 'Abteilungsname', 'Nombre de la sección');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (196, 'add_section', 'Add Section', 'Ajouter Section', 'Aggiungere Sezione', 'Adicionar Seção', 'Abschnitt hinzufügen', 'Agregar sección');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (197, 'subject_list', 'Subject List', 'Liste Sujet', 'soggetto List', 'Assunto Lista', 'Betreffliste', 'Lista de temas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (198, 'subject_name', 'Subject Name', 'Nom Sujet', 'soggetto Nome', 'Nome Assunto', 'Subjekt Name', 'Nombre del tema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (199, 'edit_subject', 'Edit Subject', 'Modifier Objet', 'Modifica oggetto', 'Editar assunto', 'Betreff bearbeiten', 'Editar asunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (200, 'day', 'Day', 'journée', 'Giorno', 'Dia', 'Tag', 'Día');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (201, 'starting_time', 'Starting Time', 'Heure de départ', 'Tempo di partenza', 'Tempo de partida', 'Anfangszeit', 'Tiempo de empezar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (202, 'hour', 'Hour', 'Heure', 'Ora', 'Hora', 'Stunde', 'Hora');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (203, 'minutes', 'Minutes', 'Minutes', 'Minuti', 'Minutos', 'Protokoll', 'Minutos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (204, 'ending_time', 'Ending Time', 'Fin Temps', 'Fine Tempo', 'Tempo Final', 'Endzeit', 'Tiempo final');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (205, 'select_subject', 'Select Subject', 'Sélectionnez Objet', 'Selezionare Oggetto', 'Selecione Assunto', 'Wählen Sie Betreff', 'Seleccione Asunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (206, 'select_date', 'Select Date', 'Sélectionnez date', 'Selezionare Data', 'Selecione Data', 'Datum auswählen', 'Seleccione fecha');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (207, 'select_month', 'Select Month', 'Sélectionnez un mois', 'Selezionare il mese', 'Selecione o mês', 'Wähle einen Monat', 'Seleccione mes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (208, 'select_year', 'Select Year', 'Sélectionnez Année', 'Seleziona Anno', 'Selecione o ano', 'Wählen Sie Jahr', 'Seleccione año');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (209, 'add_language', 'Add Language', 'ajouter une langue', 'aggiungere la lingua', 'adicionar linguagem', 'Sprache hinzufügen', 'Agregar idioma');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (210, 'exam_name', 'Exam Name', 'Nom d\'examen', 'Nome esame', 'exame Nome', 'Prüfungsname', 'Nombre del examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (211, 'date', 'Date', 'date', 'Data', 'Encontro', 'Datum', 'Fecha');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (212, 'comment', 'Comment', 'Commentaire', 'Commento', 'Comente', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (213, 'edit_exam', 'Edit Exam', 'Modifier examen', 'Modifica esame', 'Editar Exame', 'Prüfung bearbeiten', 'Editar examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (214, 'grade_list', 'Grade List', 'Liste de grade', 'Lista grado', 'Lista Grade', 'Notenliste', 'Lista de calificaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (215, 'grade_name', 'Grade Name', 'Nom de grade', 'Nome grado', 'Nome grau', 'Notenname', 'Nombre de grado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (216, 'grade_point', 'Grade Point', 'grade point', 'Grade Point', 'Ponto de classificação', 'Notenpunkt', 'Punto de grado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (217, 'select_exam', 'Select Exam', 'Sélectionnez Exam', 'Selezionare esame', 'Select Exam', 'Wählen Sie Prüfung', 'Seleccionar examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (218, 'students', 'Students', 'Élèves', 'Alunni', 'estudantes', 'Studenten', 'Estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (219, 'subjects', 'Subjects', 'Sujets', 'Soggetti', 'assuntos', 'Themen', 'Asignaturas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (220, 'total', 'Total', 'Total', 'Totale', 'Total', 'Gesamt', 'Total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (221, 'select_academic_session', 'Select Academic Session', 'Séance scolaire sélectionnée', 'Selezionare sessione accademica', 'Selecione a sessão acadêmica', 'Wählen Sie Akademische Sitzung', 'Seleccione sesión académica');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (222, 'invoice_informations', 'Invoice Informations', 'Informations de facturation', 'Informazioni fattura', 'Informações factura', 'Rechnungsinformationen', 'Informaciones de factura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (223, 'title', 'Title', 'Titre', 'Titolo', 'Título', 'Titel', 'Título');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (224, 'description', 'Description', 'La description', 'Descrizione', 'Descrição', 'Beschreibung', 'Descripción');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (225, 'payment_informations', 'Payment Informations', 'Informations de paiement', 'Informazioni di pagamento', 'Informações de pagamento', 'Zahlungsinformationen', 'Informacion de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (226, 'view_invoice', 'View Invoice', 'Voir la facture', 'Visualizza fattura', 'Ver Invoice', 'Rechnung anzeigen', 'Mirar la factura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (227, 'payment_to', 'Payment To', 'Paiement à', 'pagamento a', 'Pagamento para', 'Zahlung an', 'Pago Para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (228, 'bill_to', 'Bill To', 'Facturer', 'Fatturare a', 'Projeto de lei para', 'Gesetzesentwurf für', 'Cobrar a');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (229, 'total_amount', 'Total Amount', 'Montant total', 'Importo totale', 'Valor total', 'Gesetzesentwurf für', 'Cobrar a');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (230, 'paid_amount', 'Paid Amount', 'Montant payé', 'Importo pagato', 'Quantidade paga', 'Bezahlte Menge', 'Monto de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (231, 'due', 'Due', 'Dû', 'Dovuto', 'Devido', 'Fällig', 'Debido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (232, 'amount_paid', 'Amount Paid', 'Le montant payé', 'Importo pagato', 'Quantia paga', 'Bezahlter Betrag', 'Cantidad pagada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (233, 'payment_successfull', 'Payment has been successful', 'Paiement Successfull', 'Successfull pagamento', 'Successfull pagamento', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (234, 'add_invoice/payment', 'Add Invoice/payment', 'Ajouter Facture / paiement', 'Aggiungere fattura / pagamento', 'Adicionar fatura / pagamento', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (235, 'invoices', 'Invoices', 'factures', 'Fatture', 'facturas', 'Rechnungen', 'Facturas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (236, 'action', 'Action', 'action', 'Azione', 'Açao', 'Aktion', 'Acción');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (237, 'required', 'Required', 'Obligatoire', 'richiesto', 'Requeridos', 'Erforderlich', 'Necesario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (238, 'info', 'Info', 'Info', 'Informazioni', 'informações', 'Die Info', 'Informacion');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (239, 'month', 'Month', 'mois', 'mese', 'mês', 'Monat', 'Mes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (240, 'details', 'Details', 'Détails', 'Dettagli', 'Detalhes', 'Details', 'Detalles');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (241, 'new', 'New', 'Nouveau', 'Nuovo', 'Novo', 'Neu', 'Nuevo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (242, 'reply_message', 'Reply Message', 'Réponse au message', 'messaggio di risposta', 'Resposta da mensagem', 'Nachricht beantworten', 'Mensaje de respuesta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (243, 'message_sent', 'Message Sent', '', 'Messaggio inviato', 'Mensagem enviada', 'Nachricht gesendet', 'Mensaje enviado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (244, 'search', 'Search', 'chercher', 'ricerca', 'pesquisa', 'Suche', 'Buscar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (245, 'religion', 'Religion', 'Religion', 'Religione', 'Religião', 'Religion', 'Religión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (246, 'blood_group', 'Blood group', 'groupe sanguin', 'gruppo sanguigno', 'grupo sanguíneo', 'Blutgruppe', 'Grupo sanguíneo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (247, 'database_backup', 'Database Backup', 'Sauvegarde de base de données', 'Database Backup', 'Backup de banco de dados', 'Datenbanksicherung', 'Copia de seguridad de la base de datos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (248, 'search', 'Search', 'chercher', 'ricerca', 'pesquisa', 'Suche', 'Buscar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (249, 'payments_history', 'Fees Pay / Invoice', 'honoraires payer / facture', 'tasse di pagamento / fattura', 'taxas de pagamento / fatura', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (250, 'message_restore', 'Message Restore', 'Restauration de message', 'Messaggio di ripristino', 'Restaurar mensagem', 'Gebühren bezahlen / Rechnung', 'Tasas de pago / factura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (251, 'write_new_message', 'Write New Message', 'Ecrire un nouveau message', 'Scrivi nuovo messaggio', 'Escrever Nova Mensagem', 'Neue Nachricht schreiben', 'Escribir nuevo mensaje');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (252, 'attendance_sheet', 'Attendance Sheet', 'Feuille de présence', 'Foglio presenze', 'Folha de Atendimento', 'Anwesenheitsliste', 'Hoja de asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (253, 'holiday', 'Holiday', 'Vacances', 'Vacanza', 'Feriado', 'Urlaub', 'Fiesta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (254, 'exam', 'Exam', 'Examen', 'Esame', 'Exame', 'Prüfung', 'Examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (255, 'successfully', 'Successfully', 'Avec succès', 'Con successo', 'Com sucesso', 'Erfolgreich', 'Exitosamente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (256, 'admin', 'Admin', 'Admin', 'Admin', 'Admin', 'Administrator', 'Administración');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (257, 'inbox', 'Inbox', 'Boîte de réception', 'Posta in arrivo', 'Caixa de entrada', 'Posteingang', 'Bandeja de entrada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (258, 'sent', 'Sent', 'Envoyé', 'Inviato', 'Enviei', 'Geschickt', 'Expedido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (259, 'important', 'Important', 'Important', 'Importante', 'Importante', 'Wichtig', 'Importante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (260, 'trash', 'Trash', 'Poubelle', 'Spazzatura', 'Lixo', 'Müll', 'Basura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (261, 'error', 'Unsuccessful', 'Infructueux', 'Senza esito', 'Mal sucedido', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (262, 'sessions_list', 'Sessions List', 'Liste des sessions', 'Elenco Sessioni', 'Lista de Sessões', 'Sitzungsliste', 'Lista de sesiones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (263, 'session_settings', 'Session Settings', 'Paramètres de la session', 'Impostazioni sessione', 'Configurações da Sessão', 'Sitzungseinstellungen', 'Configuraciones de sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (264, 'add_designation', 'Add Designation', 'Ajouter une désignation', 'Aggiungi designazione', 'Adicionar Designação', 'Bezeichnung hinzufügen', 'Agregar designación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (265, 'users', 'Users', 'Utilisateurs', 'utenti', 'Comercial', 'Benutzer', 'Los usuarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (266, 'librarian', 'Librarian', 'Bibliothécaire', 'Bibliotecario', 'Bibliotecário', 'Bibliothekar', 'bibliotecario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (267, 'accountant', 'Accountant', 'Comptable', 'Contabile', 'Contador', 'Buchhalter', 'Contador');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (268, 'academics', 'Academics', 'institutionnellement', 'istituzionalmente', 'institucionalmente', 'Akademiker', 'Académica');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (269, 'employees_attendance', 'Employees Attendance', 'Participation des employés', 'La presenza dei dipendenti', 'Atendimento dos funcionários', 'Anwesenheit der Mitarbeiter', 'Asistencia de empleados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (270, 'set_exam_term', 'Set Exam Term', 'Terminer l\'examen', 'Imposta il termine dell\'esame', 'Definir Termo de Exame', 'Prüfungsdauer festlegen', 'Establecer plazo de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (271, 'set_attendance', 'Set Attendance', 'Assurer la fréquentation', 'Impostare la frequenza', 'Definir atendimento', 'Anwesenheit einstellen', 'Establecer asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (272, 'marks', 'Marks', 'Des notes', 'votazione', 'Marcas', 'Markierungen', 'Marcas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (273, 'books_category', 'Books Category', 'Catégorie de livres', 'Categoria di libri', 'Categoria de livro', 'Buchkategorie', 'Categoría de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (274, 'transport', 'Transport', 'Transport', 'Trasporto', 'Transporte', 'Transport', 'Transporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (275, 'fees', 'Fees', 'honoraires', 'tasse', 'honorários', 'Gebühren', 'Tarifa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (276, 'fees_allocation', 'Fees Allocation', 'répartition des frais', 'assegnazione dei diritti', 'alocação de tarifas', 'Gebührenverteilung', 'Asignación de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (277, 'fee_category', 'Fee Category', 'Catégorie tarifaire', 'Categoria di tassa', 'Categoria de taxa', 'Gebührenkategorie', 'Categoría de tarifa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (278, 'report', 'Report', 'rapport', 'rapporto', 'relatório', 'Bericht', 'Reporte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (279, 'employee', 'Employee', 'employés', 'dipendenti', 'Funcionários', 'Mitarbeiter', 'Empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (280, 'invoice', 'Invoice', 'facture d\'achat', 'fattura', 'fatura', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (281, 'event_catalogue', 'Event Catalogue', 'Catalogue des événements', 'Catalogo eventi', 'Catálogo de Eventos', 'Veranstaltungskatalog', 'Catálogo de eventos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (282, 'total_paid', 'Total Paid', 'Total payé', 'Totale pagato', 'Total pago', 'Ganz bezahlt', 'Total pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (283, 'total_due', 'Total Due', 'Total dû', 'Totale dovuto', 'Total Due', 'Ganz bezahlt', 'Total pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (284, 'fees_collect', 'Fees Collect', 'Frais collectés', 'Le tasse si raccolgono', 'Taxas cobradas', 'Gebühren sammeln', 'Tasas por cobrar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (285, 'total_school_students_attendance', 'Total School Students Attendance', 'Participation totale des étudiants', 'La frequenza totale degli studenti delle scuole', 'Total de frequência escolar', 'Gesamtzahl der Schüler', 'Asistencia total de estudiantes de la escuela');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (286, 'overview', 'Overview', 'Aperçu', 'Panoramica', 'Visão geral', 'Überblick', 'Visión general');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (287, 'currency_symbol', 'Currency Symbol', 'symbole de la monnaie', 'Simbolo di valuta', 'Símbolo monetário', 'Währungszeichen', 'Símbolo de moneda');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (288, 'enable', 'Enable', 'Activer', 'Abilitare', 'Habilitar', 'Aktivieren', 'Habilitar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (289, 'disable', 'Disable', 'Désactiver', 'disattivare', 'Desativar', 'Deaktivieren', 'Inhabilitar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (290, 'payment_settings', 'Payment Settings', 'Paramètres de paiement', 'Impostazioni di pagamento', 'Configurações de pagamento', 'Zahlungseinstellungen', 'Configuraciones de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (291, 'student_attendance_report', 'Student Attendance Report', 'Rapport de présence étudiante', 'Rapporto di frequenza degli studenti', 'Relatório de atendimento ao aluno', 'Anwesenheitsbericht für Studenten', 'Informe de asistencia estudiantil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (292, 'attendance_type', 'Attendance Type', 'Type de présence', 'Tipo di partecipazione', 'Tipo de atendimento', 'Anwesenheitsart', 'Tipo de asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (293, 'late', 'Late', 'En retard', 'in ritardo', 'Atrasado', 'Spät', 'Tarde');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (294, 'employees_attendance_report', 'Employees Attendance Report', 'Rapport de présence des employés', 'Rapporto di presenza dei dipendenti', 'Relatório de comparecimento de funcionários', 'Anwesenheitsbericht der Mitarbeiter', 'Informe de asistencia de empleados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (295, 'attendance_report_of', 'Attendance Report Of', 'Rapport de présence de', 'Relazione di partecipazione di', 'Relatório de atendimento de', 'Anwesenheitsbericht von', 'Informe de asistencia de');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (296, 'fee_paid_report', 'Fee Paid Report', 'Rapport payé payé', 'Pagamento pagato rapporto', 'Relatório remunerado', 'Gebührenpflichtiger Bericht', 'Informe de tarifa pagada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (297, 'invoice_no', 'Invoice No', 'Facture non', 'fattura n', 'Factura não', 'Rechnung Nr', 'Factura no');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (298, 'payment_mode', 'Payment Mode', 'mode de paiement', 'metodo di pagamento', 'modo de pagamento', 'Zahlungsart', 'Modo de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (299, 'payment_type', 'Payment Type', 'type de paiement', 'modalità di pagamento', 'tipo de pagamento', 'Zahlungsart', 'Tipo de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (300, 'done', 'Done', 'terminé', 'fatto', 'feito', 'Erledigt', 'Hecho');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (301, 'select_fee_category', 'Select Fee Category', 'Sélectionner la catégorie tarifaire', 'Selezionare la categoria dei diritti', 'Categoria de taxa selecionada', 'Wählen Sie die Gebührenkategorie', 'Seleccionar categoría de tarifa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (302, 'discount', 'Discount', 'remise', 'sconto', 'desconto', 'Rabatt', 'Descuento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (303, 'enter_discount_amount', 'Enter Discount Amount', 'Saisir un montant d\'escompte', 'Inserire l\'importo del sconto', 'Insira valor de desconto', 'Geben Sie den Rabattbetrag ein', 'Ingrese el monto del descuento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (304, 'online_payment', 'Online Payment', 'Paiement à distance', 'Pagamento remoto', 'Pagamento Remoto', 'Onlinebezahlung', 'Pago en línea');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (305, 'student_name', 'Student Name', 'nom d\'étudiant', 'nome dello studente', 'nome do aluno', 'Name des Studenten', 'Nombre del estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (306, 'invoice_history', 'Invoice History', 'Historique des factures', 'La cronologia delle fatture', 'Histórico de faturamento', 'Rechnungsverlauf', 'Historial de facturas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (307, 'discount_amount', 'Discount Amount', 'Montant de l\'escompte', 'totale sconto', 'Valor do desconto', 'Rabattbetrag', 'Importe de descuento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (308, 'invoice_list', 'Invoice List', 'Liste des factures', 'Elenco delle fatture', 'Lista de faturamento', 'Rechnungsliste', 'Lista de facturas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (309, 'partly_paid', 'Partly Paid', 'En partie payé', 'Parzialmente pagato', 'Parcialmente pago', 'Teilweise bezahlt', 'Parcialmente pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (310, 'fees_list', 'Fees List', 'Liste des frais', 'Lista dei diritti', 'Lista de tarifas', 'Gebührenliste', 'Lista de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (311, 'voucher_id', 'Voucher ID', 'Id de bon', 'Voucher Id', 'Id do vale', 'Gutschein-ID', 'ID de comprobante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (312, 'transaction_date', 'Transaction Date', 'transaction date', 'Data di transazione', 'Data da transação', 'Transaktionsdatum', 'Fecha de Transacción');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (313, 'admission_date', 'Admission Date', 'admission date', 'data di ammissione', 'data de admissão', 'Aufnahmedatum', 'Fecha de admisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (314, 'user_status', 'User Status', 'Statut de l\'utilisateur', 'Stato dell\'utente', 'Status do usuário', 'Benutzerstatus', 'Estatus de usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (315, 'nationality', 'Nationality', 'nationalité', 'nazionalità', 'nacionalidade', 'Staatsangehörigkeit', 'Nacionalidad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (316, 'register_no', 'Register No', 'Inscrivez-vous non', 'Registrare n', 'Não registre', 'Register Nr', 'Registrarse No');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (317, 'first_name', 'First Name', 'Prénom', 'nome di battesimo', 'primeiro nome', 'Vorname', 'Nombre de pila');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (318, 'last_name', 'Last Name', 'nom de famille', 'cognome', 'último nome', 'Nachname', 'Apellido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (319, 'state', 'State', 'Etat', 'stato', 'Estado', 'Zustand', 'Estado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (320, 'transport_vehicle_no', 'Transport Vehicle No', 'Véhicule de transport no', 'Veicolo di trasporto n', 'Transport Vehicle No', 'Zustand', 'Estado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (321, 'percent', 'Percent', 'pour cent', 'per cento', 'por cento', 'Prozent', 'Por ciento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (322, 'average_result', 'Average Result', 'Résultat moyen', 'Risultato medio', 'Resultado médio', 'Durchschnittliches Ergebnis', 'Resultado promedio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (323, 'student_category', 'Student Category', 'Catégorie étudiante', 'Categoria studente', 'Categoria de estudante', 'Studentenkategorie', 'Categoría de estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (324, 'category_name', 'Category Name', 'Nom de catégorie', 'Nome della categoria', 'Nome da Categoria', 'Kategoriename', 'nombre de la categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (325, 'category_list', 'Category List', 'Liste des catégories', 'Elenco categorie', 'Lista de categorias', 'Kategorieliste', 'Lista de categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (326, 'please_select_student_first', 'Please Select Students First', 'S\'il vous plaît sélectionner les étudiants de première', 'Per favore seleziona gli studenti prima', 'Selecione os alunos primeiro', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (327, 'designation', 'Designation', 'La désignation', 'Designazione', 'Designação', 'Bezeichnung', 'Designacion');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (328, 'qualification', 'Qualification', 'Qualification', 'Qualificazione', 'Qualificação', 'Qualifikation', 'Calificación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (329, 'account_deactivated', 'Account Deactivated', 'Compte désactivé', 'Account disattivato', 'Conta desativada', 'Konto deaktiviert', 'Cuenta desactivada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (330, 'account_activated', 'Account Activated', 'Compte activé', 'Account attivato', 'Conta ativada', 'Konto aktiviert', 'Cuenta activada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (331, 'designation_list', 'Designation List', 'Liste de désignation', 'Elenco descrizioni', 'Lista de designação', 'Bezeichnungsliste', 'Lista de designaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (332, 'joining_date', 'Joining Date', 'Date d\'inscription', 'Data di adesione', 'Data de ingresso', 'Beitrittsdatum', 'Dia de ingreso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (333, 'relation', 'Relation', 'Relation', 'Relazione', 'Relação', 'Beziehung', 'Relación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (334, 'father_name', 'Father Name', 'nom du père', 'nome del padre', 'nome do pai', 'Der Name des Vaters', 'Nombre del Padre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (335, 'librarian_list', 'Librarian List', 'Liste des bibliothécaires', 'Lista bibliotecaria', 'Lista de bibliotecários', 'Bibliothekar Liste', 'Lista de bibliotecarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (336, 'class_numeric', 'Class Numeric', 'Classe Numérique', 'Class Numerico', 'Classe Numérica', 'Klasse Numerisch', 'Clase numérica');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (337, 'maximum_students', 'Maximum Students', 'Maximum d\'étudiants', 'Studenti massimi', 'Alunos máximos', 'Maximale Schülerzahl', 'Máximo de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (338, 'class_room', 'Class Room', 'Salle de classe', 'aula', 'Sala de aula', 'Klassenzimmer', 'Aula');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (339, 'pass_mark', 'Pass Mark', 'moyenne', 'punteggio minimo', 'Marca de aprovação', 'Mindestpunktzahl', 'Aprobado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (340, 'exam_time', 'Exam Time (Min)', 'Temps d\'examen (min)', 'Tempo di esame', 'hora da prova', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (341, 'time', 'Time', 'temps', 'tempo', 'Tempo', 'Zeit', 'Hora');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (342, 'subject_code', 'Subject Code', 'Code du sujet', 'Codice oggetto', 'Código do assunto', 'Betreff Code', 'Código sujeto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (343, 'full_mark', 'Full Mark', 'Pleine marque', 'Full Mark', 'Nota máxima', 'Volle Note', 'Marca completa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (344, 'subject_type', 'Subject Type', 'Type de sujet', 'Tipo di soggetto', 'Tipo de assunto', 'Betreff Typ', 'Tipo de Asunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (345, 'date_of_publish', 'Date Of Publish', 'Date de publication', 'Data di pubblicazione', 'Data de publicação', 'Datum der Veröffentlichung', 'Fecha de publicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (346, 'file_name', 'File Name', 'Nom de fichier', 'Nome del file', 'Nome do arquivo', 'Dateiname', 'Nombre del archivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (347, 'students_list', 'Students List', 'Liste des étudiants', 'Lista degli studenti', 'Lista de Estudantes', 'Studentenliste', 'Lista de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (348, 'start_date', 'Start Date', 'Date de début', 'Data d\'inizio', 'Data de início', 'Anfangsdatum', 'Fecha de inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (349, 'end_date', 'End Date', 'End Date', 'Data di fine', 'Data final', 'Endtermin', 'Fecha final');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (350, 'term_name', 'Term Name', 'Nom du terme', 'Termine nome', 'Nome do termo', 'Begriff Name', 'Nombre del plazo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (351, 'grand_total', 'Grand Total', 'Grand Total', 'Somma totale', 'Total geral', 'Gesamtsumme', 'Gran total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (352, 'result', 'Result', 'Résultat', 'Risultato', 'Resultado', 'Ergebnis', 'Resultado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (353, 'books_list', 'Books List', 'Liste des livres', 'Elenco libri', 'Lista de livros', 'Bücherliste', 'Lista de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (354, 'book_isbn_no', 'Book ISBN No', 'Livre numéro ISBN', 'Libro ISBN n', 'ISBN do livro', 'Buch ISBN Nr', 'Libro ISBN No');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (355, 'total_stock', 'Total Stock', 'Total Stock', 'Totale azioni', 'Total Stock', 'Gesamtbestand', 'Stock total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (356, 'issued_copies', 'Issued Copies', 'Copies émises', 'Copie emesse', 'Cópias Emitidas', 'Ausgestellte Kopien', 'Copias emitidas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (357, 'publisher', 'Publisher', 'éditeur', 'editore', 'editor', 'Verleger', 'Editor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (358, 'books_issue', 'Books Issue', 'Problème de livre', 'Emissione del libro', 'Problema do livro', 'Bücher Ausgabe', 'Edición de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (359, 'user', 'User', 'Utilisateur', 'Utente', 'Do utilizador', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (360, 'fine', 'Fine', 'Bien', 'Fine', 'Bem', 'Fein', 'Multa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (361, 'pending', 'Pending', 'en attendant', 'in attesa di', 'pendente', 'steht aus', 'Pendiente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (362, 'return_date', 'Return Date', 'date de retour', 'data di ritorno', 'data de retorno', 'Rückflugdatum', 'Fecha de regreso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (363, 'accept', 'Accept', 'Acceptez', 'accettare', 'aceitar', 'Akzeptieren', 'Aceptar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (364, 'reject', 'Reject', 'rejeter', 'rifiutare', 'rejeitar', 'Ablehnen', 'Rechazar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (365, 'issued', 'Issued', 'Publié', 'Rilasciato', 'Emitido', 'Ausgegeben', 'Emitido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (366, 'return', 'Return', 'Revenir', 'Ritorno', 'Retorna', 'Rückkehr', 'Regreso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (367, 'renewal', 'Renewal', 'renouvellement', 'rinnovo', 'renovação', 'Erneuerung', 'Renovación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (368, 'fine_amount', 'Fine Amount', 'Montant fin', 'Ammontare fine', 'Quantidade fina', 'Feiner Betrag', 'Cantidad fina');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (369, 'password_mismatch', 'Password Mismatch', 'Incompatibilité de mot de passe', 'Mancata corrispondenza delle password', 'Incompatibilidade de senha', 'Feiner Betrag', 'Cantidad fina');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (370, 'settings_updated', 'Settings Update', 'Mise à jour de paramètres', 'Aggiornamento delle impostazioni di', 'Atualização de configurações', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (371, 'pass', 'Pass', 'passer', 'passaggio', 'slagen voor', 'Bestehen', 'Pasar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (372, 'event_to', 'Event To', 'Événement à', 'Evento a', 'Evento para', 'Ereignis zu', 'Evento a');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (373, 'all_users', 'All Users', 'tous les utilisateurs', 'tutti gli utenti', 'todos os usuários', 'Alle Nutzer', 'Todos los usuarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (374, 'employees_list', 'Employees List', 'Liste des employés', 'Elenco dei dipendenti', 'Lista de funcionários', 'Mitarbeiterliste', 'Lista de empleados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (375, 'on', 'On', 'sur', 'sopra', 'em', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (376, 'timezone', 'Timezone', 'fuseau horaire', 'fuso orario', 'fuso horário', 'Zeitzone', 'Zona horaria');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (377, 'get_result', 'Get Result', 'Obtenir un résultat', 'Ottenere il risultato', 'Obter resultado', 'Ergebnis abrufen', 'Obtener resultado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (378, 'apply', 'Apply', 'appliquer', 'applicare', 'Aplique', 'Anwenden', 'Aplicar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (379, 'hrm', 'Human Resource', 'ressource humaine', 'risorse umane', 'recursos humanos', 'Humanressourcen', 'Recursos humanos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (380, 'payroll', 'Payroll', 'paie', 'libro paga', 'folha de pagamento', 'Lohn-und Gehaltsabrechnung', 'Nómina de sueldos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (381, 'salary_assign', 'Salary Assign', 'Contrôle des salaires', 'Controllo dello stipendio', 'Controle salarial', 'Gehaltszuweisung', 'Asignación de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (382, 'employee_salary', 'Payment Salary', 'Salaire de paiement', 'Salario del pagamento', 'Salário de pagamento', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (383, 'application', 'Application', 'application', 'applicazione', 'aplicação', 'Anwendung', 'Solicitud');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (384, 'award', 'Award', 'prix', 'premio', 'Prêmio', 'Vergeben', 'Premio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (385, 'basic_salary', 'Basic Salary', 'salaire de base', 'salario di base', 'salário básico', 'Grundgehalt', 'Salario base');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (386, 'employee_name', 'Employee Name', 'Nom de l\'employé', 'Nome dipendente', 'nome do empregado', 'Mitarbeitername', 'Nombre de empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (387, 'name_of_allowance', 'Name Of Allowance', 'nom de l\'allocation', 'nome dell\'indennità', 'Nome do subsídio', 'Name der Zulage', 'Nombre de la asignación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (388, 'name_of_deductions', 'Name Of Deductions', 'Nom des déductions', 'Nome delle deduzioni', 'Nome das deduções', 'Name der Abzüge', 'Nombre de las deducciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (389, 'all_employees', 'All Employees', 'tous les employés', 'tutti gli impiegati', 'todos os empregados', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (390, 'total_allowance', 'Total Allowance', 'Allocation totale', 'Indennità totale', 'Subsídio total', 'Gesamtzulage', 'Subsidio total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (391, 'total_deduction', 'Total Deductions', 'le total des déductions', 'deduzione totale', 'deduções totais', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (392, 'net_salary', 'Net Salary', 'salaire net', 'Salario netto', 'salário líquido', 'Nettogehalt', 'Sueldo neto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (393, 'payslip', 'Payslip', 'Payslip', 'busta paga', 'Pague basculante', 'Gehaltsabrechnung', 'Recibo de sueldo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (394, 'days', 'Days', 'journées', 'giorni', 'dias', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (395, 'category_name_already_used', 'Category Name Already Used', 'Nom de la catégorie déjà utilisé', 'Nome di categoria già utilizzato', 'Nome da categoria já utilizado', 'Kategoriename bereits verwendet', 'Nombre de categoría ya utilizado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (396, 'leave_list', 'Leave List', 'Laisser liste', 'lasciare l\'elenco', 'Sair da lista', 'Liste verlassen', 'Dejar lista');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (397, 'leave_category', 'Leave Category', 'Laisser la catégorie', 'Lasciare la categoria', 'Sair da categoria', 'Kategorie verlassen', 'Dejar categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (398, 'applied_on', 'Applied On', 'appliqué sur', 'Applicato', 'Aplicado em', 'Aufgetragen auf', 'Aplicado en');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (399, 'accepted', 'Accepted', 'accepté', 'accettato', 'aceitaram', 'Akzeptiert', 'Aceptado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (400, 'leave_statistics', 'Leave Statistics', 'Quitter les statistiques', 'Lasciare le statistiche', 'Deixar estatísticas', 'Statistik verlassen', 'Dejar estadísticas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (401, 'leave_type', 'Leave Type', 'Type de permission', 'Lasciare il tipo', 'Deixe o tipo', 'Typ verlassen', 'Dejar tipo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (402, 'reason', 'Reason', 'raison', 'ragionare', 'razão', 'Grund', 'Razón');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (403, 'close', 'Close', 'Fermer', 'vicino', 'fechar', 'Schließen', 'Cerca');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (404, 'give_award', 'Give Award', 'Donner un prix', 'Dare un premio', 'Dar prêmio', 'Preis geben', 'Dar premio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (405, 'list', 'List', 'liste', 'elenco', 'Lista', 'Liste', 'Lista');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (406, 'award_name', 'Award Name', 'nom de l\'attribution', 'Nome del premio', 'Nome do prêmio', 'Award Name', 'Nombre del premio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (407, 'gift_item', 'Gift Item', 'Objet cadeau', 'Elemento regalo', 'Item de presente', 'Geschenkartikel', 'Artículo de regalo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (408, 'cash_price', 'Cash Price', 'Prix ​​en espèces', 'Prezzo in contanti', 'Preço em dinheiro', 'Barpreis', 'Precio en efectivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (409, 'award_reason', 'Award Reason', 'Raison de récompense', 'Ragione del premio', 'Motivo de adjudicação', 'Auszeichnungsgrund', 'Razón del premio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (410, 'given_date', 'Given Date', 'Date donnée', 'Data data', 'Data dada', 'Gegebenes Datum', 'Fecha dada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (411, 'apply_leave', 'Apply Leave', 'Postuler', 'Applicare il permesso', 'Aplicar licença', 'Bewerben Sie sich', 'Aplicar licencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (412, 'leave_application', 'Leave Application', 'laisser l\'application', 'Meninggalkan aplikasi', 'Deixar o aplicativo', 'Verlassen Anwendung', 'Deje la aplicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (413, 'allowances', 'Allowances', 'Allocations', 'indennità', 'Subsídios', 'Zulagen', 'Subsidios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (414, 'add_more', 'Add More', 'ajouter plus', 'aggiungere altro', 'Adicione mais', 'Mehr hinzufügen', 'Añadir más');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (415, 'deductions', 'Deductions', 'Déductions', 'deduzioni', 'Deduções', 'Abzüge', 'Deducciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (416, 'salary_details', 'Salary Details', 'Détails de salaire', 'I dettagli delle retribuzioni', 'Detalhes salariais', 'Gehaltsangaben', 'Detalles salariales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (417, 'salary_month', 'Salary Month', 'Mois de salaire', 'Mese di salario', 'Mês de salário', 'Gehaltsmonat', 'Mes de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (418, 'leave_data_update_successfully', 'Leave Data Updated Successfully', 'Laisser les données mises à jour avec succès', 'Lasciare i dati aggiornati correttamente', 'Deixe os dados atualizados com sucesso', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (419, 'fees_history', 'Fees History', 'Historique des frais', 'La storia dei costi', 'Histórico de taxas', 'Gebühren Geschichte', 'Honorarios Historia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (420, 'bank_name', 'Bank Name', 'Nom de banque', 'nome della banca', 'nome do banco', 'Bank Name', 'Nombre del banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (421, 'branch', 'Branch', 'branche', 'ramo', 'ramo', 'Ast', 'Rama');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (422, 'bank_address', 'Bank Address', 'adresse de la banque', 'indirizzo bancario', 'endereço do banco', 'Bankadresse', 'Dirección del banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (423, 'ifsc_code', 'IFSC Code', 'IFSC code', 'Codice IFSC', 'Código IFSC', 'Bankadresse', 'Dirección del banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (424, 'account_no', 'Account No', 'n ° de compte', 'Conto n', 'Conta não', 'Konto Nr', 'Cuenta no');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (425, 'add_bank', 'Add Bank', 'Ajouter une banque', ' Aggiungi la banca', 'Adicionar banco', 'Bank hinzufügen', 'Agregar banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (426, 'account_name', 'Account Holder', 'nom du compte', 'nome utente', 'nome da conta', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (427, 'database_backup_completed', 'Database Backup Completed', 'Sauvegarde de base de données terminée', 'Backup del database completato', 'Backup do banco de dados concluído', 'Datenbanksicherung abgeschlossen', 'Copia de seguridad de la base de datos completada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (428, 'restore_database', 'Restore Database', 'Restaurer la base de données', 'Ripristinare il database', 'Restaurar o banco de dados', 'Datenbank wiederherstellen', 'Restaurar base de datos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (429, 'template', 'Template', 'modèle', 'modello', 'modelo', 'Vorlage', 'Modelo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (430, 'time_and_date', 'Time And Date', 'heure et date', 'ora e data', 'hora e data', 'Zeit und Datum', 'Hora y fecha');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (431, 'everyone', 'Everyone', 'toutes les personnes', 'tutti', 'todos', 'Jeder', 'Todos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (432, 'invalid_amount', 'Invalid Amount', 'montant invalide', 'importo non valido', 'Montante inválido', 'Ungültige Menge', 'Monto invalido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (433, 'leaving_date_is_not_available_for_you', 'Leaving Date Is Not Available For You', 'la date de sortie n\'est pas disponible pour vous', 'la data di partenza non è disponibile per te', 'A data de saída não está disponível para você', 'Das Abreisedatum ist für Sie nicht verfügbar', 'La fecha de salida no está disponible para usted');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (434, 'animations', 'Animations', 'animations', 'animazioni', 'animações', 'Animationen', 'Animaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (435, 'email_settings', 'Email Settings', 'Paramètres de messagerie', 'impostazioni di posta elettronica', 'configurações de e-mail', 'Email Einstellungen', 'Ajustes del correo electrónico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (436, 'deduct_month', 'Deduct Month', 'déduire le mois', 'detrarre il mese', 'deduz o mês', 'Monat abziehen', 'Deducir mes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (437, 'no_employee_available', 'No Employee Available', 'Aucun employé disponible', 'Nessun dipendente disponibile', 'Nenhum funcionário disponível', 'Kein Mitarbeiter verfügbar', 'Ningún empleado disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (438, 'advance_salary_application_submitted', 'Advance Salary Application Submitted', 'Demande de salaire anticipé soumise', 'Applicazione anticipata salariale presentata', 'Solicitação de Salário Avançado Enviado', 'Vorab-Gehaltsantrag eingereicht', 'Solicitud de salario anticipado presentada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (439, 'date_format', 'Date Format', 'date format', 'formato data', 'Formato de data', 'Date Format', 'Formato de fecha');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (440, 'id_card_generate', 'ID Card Generate', 'Carte d\'identité générer', 'La carta d\'identità genera', 'O cartão de identificação gera', 'ID-Karte generieren', 'Generar tarjeta de identificación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (441, 'issue_salary', 'Issue Salary', 'question salariale', 'emettere stipendio', 'emitir salário', 'Gehalt ausgeben', 'Emitir salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (442, 'advance_salary', 'Advance Salary', 'avance sur salaire', 'salario anticipo', 'Salário adiantado', 'Vorschuss', 'Salario por adelantado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (443, 'logo', 'Logo', 'logo', 'logo', 'logo', 'Logo', 'Logo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (444, 'book_request', 'Book Request', 'demande de livre', 'richiesta di libro', 'pedido de livro', 'Buchanfrage', 'Solicitud de libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (445, 'reporting', 'Reporting', 'rapport', 'segnalazione', 'relatórios', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (446, 'paid_salary', 'Paid Salary', 'salaire payé', 'stipendio retribuito', 'salário pago', 'Bezahltes Gehalt', 'Salario pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (447, 'due_salary', 'Due Salary', 'salaire dû', 'salario dovuto', 'salário devedor', 'Fälliges Gehalt', 'Salario adeudado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (448, 'route', 'Route', 'Route', 'Itinerario', 'Rota', 'Route', 'Ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (449, 'academic_details', 'Academic Details', 'détails académiques', 'dettagli accademici', 'detalhes acadêmicos', 'Akademische Details', 'Detalles académicos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (450, 'guardian_details', 'Guardian Details', 'détails académiques', 'dettagli accademici', 'detalhes acadêmicos', 'Wächter Details', 'Detalles del guardián');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (451, 'due_amount', 'Due Amount', 'montant dû', 'importo dovuto', 'debita moles', 'Fälliger Betrag', 'Cantidad debida');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (452, 'fee_due_report', 'Fee Due Report', 'rapport dû', 'fee due report', 'relatório pago', 'Gebührenpflichtiger Bericht', 'Informe de tarifa adeudada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (453, 'other_details', 'Other Details', 'Autres détails', 'altri dettagli', 'Outros detalhes', 'Andere Details', 'Otros detalles');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (454, 'last_exam_report', 'Last Exam Report', 'Dernier rapport d&#39;examen', 'Rapporto sull\'ultimo esame', 'Relatório do último exame', 'Letzter Prüfungsbericht', 'Informe del último examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (455, 'book_issued', 'Book Issued', 'Livre publié', 'Libro emesso', 'Livro emitido', 'Buch herausgegeben', 'Libro emitido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (456, 'interval_month', 'Interval 30 Days', 'Intervalle 30 jours', 'Intervallo 30 giorni', 'Intervalo 30 dias', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (457, 'attachments', 'Attachments', 'Les pièces jointes', 'allegati', 'Anexos', 'Anhänge', 'Archivos adjuntos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (458, 'fees_payment', 'Fees Payment', 'Paiement des frais', 'Pagamento', 'Pagamento de taxas', 'Gebühren Zahlung', 'Pago de honorarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (459, 'fees_summary', 'Fees Summary', 'Résumé des frais', 'Riepilogo tasse', 'Resumo de taxas', 'Gebührenübersicht', 'Resumen de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (460, 'total_fees', 'Total Fees', 'Total des frais', 'Commissioni totali', 'Taxas totais', 'Gesamtkosten', 'Tarifas totales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (461, 'weekend_attendance_inspection', 'Weekend Attendance Inspection', 'Weekend Attendance Inspection', 'Ispezione presenze weekend', 'Inspeção de Presença no Fim de Semana', 'Inspektion der Wochenendteilnahme', 'Inspección de asistencia de fin de semana');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (462, 'book_issued_list', 'Book Issued List', 'Liste des livres publiés', 'Elenco pubblicato', 'Lista de livros emitidos', 'Buchausgabeliste', 'Lista de libros emitidos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (463, 'lose_your_password', 'Lose Your Password?', 'Perdre votre mot de passe?', 'Perdere la tua password?', 'Perca sua senha?', 'Passwort verlieren?', '¿Perdió su contraseña?');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (464, 'all_branch_dashboard', 'All Branch Dashboard', 'Tableau de bord de toutes les branches', 'All Branch Dashboard', 'All Branch Dashboard', 'Alle Zweig Dashboard', 'Tablero de todas las sucursales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (465, 'academic_session', 'Academic Session', 'Session académique', 'Sessione accademica', 'Sessão Acadêmica', 'Akademische Sitzung', 'Sesión Académica');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (466, 'all_branches', 'All Branches', 'Heures supplémentaires', 'Tutte le filiali', 'Todas as filiais', 'Alle Zweige', 'Todas las ramas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (467, 'admission', 'Admission', 'admission', 'ammissione', 'admissão', 'Eintritt', 'Admisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (468, 'create_admission', 'Create Admission', 'Créer une entrée', 'Crea l\'ammissione', 'Criar admissão', 'Zulassung erstellen', 'Crear admisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (469, 'multiple_import', 'Multiple Import', 'Importation multiple', 'Importazione multipla', 'Múltiplo Import', 'Mehrfachimport', 'Importación múltiple');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (470, 'student_details', 'Student Details', 'Détails de l\'étudiant', 'Dettagli dello studente', 'Detalhes do aluno', 'Studentendetails', 'Detalles del estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (471, 'student_list', 'Student List', 'Liste des étudiants', 'Elenco degli studenti', 'Lista de estudantes', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (472, 'login_deactivate', 'Login Deactivate', 'Login Désactiver', 'Login Disattiva', 'Login Desativar', 'Login Deaktivieren', 'Iniciar sesión Desactivar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (473, 'parents_list', 'Parents List', 'Liste de parents', 'Lista dei genitori', 'Lista de pais', 'Elternliste', 'Lista de padres');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (474, 'add_parent', 'Add Parent', 'Ajouter un parent', 'Aggiungi genitore', 'Adicionar pai', 'Eltern hinzufügen', 'Agregar padre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (475, 'employee_list', 'Employee List', 'Liste des employés', 'Elenco dei dipendenti', 'Lista de empregados', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (476, 'add_department', 'Add Department', 'Ajouter un département', 'Aggiungi dipartimento', 'Adicionar Departamento', 'Abteilung hinzufügen', 'Agregar departamento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (477, 'add_employee', 'Add Employee', 'Ajouter un employé', 'Aggiungi dipendente', 'Adicionar funcionário', 'Mitarbeiter hinzufügen', 'Agregar empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (478, 'salary_template', 'Salary Template', 'Modèle de salaire', 'Modello di stipendio', 'Modelo de salário', 'Gehaltsvorlage', 'Plantilla de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (479, 'salary_payment', 'Salary Payment', 'Paiement du salaire', 'Salario', 'Pagamento de Salário', 'Lohnauszahlung', 'Pago de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (480, 'payroll_summary', 'Payroll Summary', 'Résumé de la paie', 'Riepilogo del libro paga', 'Resumo da folha de pagamento', 'Zusammenfassung der Gehaltsabrechnung', 'Resumen de nómina');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (481, 'academic', 'Academic', 'Académique', 'Accademico', 'Acadêmico', 'Akademisch', 'Académico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (482, 'control_classes', 'Control Classes', 'Control Classes', 'Classi di controllo', 'Classes de Controle', 'Kontrollklassen', 'Clases de control');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (483, 'assign_class_teacher', 'Assign Class Teacher', 'Attribuer un enseignant de classe', 'Assegna un insegnante di classe', 'Atribuir professor de turma', 'Klassenlehrer zuweisen', 'Asignar maestro de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (484, 'class_assign', 'Class Assign', 'Affectation de classe', 'Assegnazione di classe', 'Atribuição de classe', 'Klassenzuweisung', 'Asignación de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (485, 'assign', 'Assign', 'Attribuer', 'Assegnare', 'Atribuir', 'Zuordnen', 'Asignar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (486, 'promotion', 'Promotion', 'Promotion', 'Promozione', 'Promoção', 'Beförderung', 'Promoción');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (487, 'attachments_book', 'Attachments Book', 'Livre des pièces jointes', 'Libro degli allegati', 'Livro de Anexos', 'Anhang Buch', 'Libro de adjuntos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (488, 'upload_content', 'Upload Content', 'Télécharger le contenu', 'Carica contenuto', 'Upload de conteúdo', 'Inhalt hochladen', 'Subir contenido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (489, 'attachment_type', 'Attachment Type', 'Type de pièce jointe', 'Tipo di allegato', 'Tipo de Anexo', 'Art des Anhangs', 'Tipo de adjunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (490, 'exam_master', 'Exam Master', 'Maître d\'examen', 'Maestro dell\'esame', 'Mestre do Exame', 'Prüfungsmeister', 'Examen maestro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (491, 'exam_hall', 'Exam Hall', 'Salle d\'examen', 'Exam Hall', 'Sala de exames', 'Prüfungsraum', 'Sala de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (492, 'mark_entries', 'Mark Entries', 'Marquer les entrées', 'Mark Entries', 'Marcar Entradas', 'Einträge markieren', 'Entradas de marca');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (493, 'tabulation_sheet', 'Tabulation Sheet', 'Feuille de tabulation', 'Foglio di tabulazione', 'Folha de tabulação', 'Tabellenblatt', 'Hoja de tabulación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (494, 'supervision', 'Supervision', 'Supervision', 'supervisione', 'Supervisão', 'Aufsicht', 'Supervisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (495, 'hostel_master', 'Hostel Master', 'Hostel Master', 'Ostello Maestro', 'Mestre do Hostel', 'Hostel Master', 'Hostel Master');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (496, 'hostel_room', 'Hostel Room', 'Chambre d\'auberge', 'Camera dell\'ostello', 'Quarto Hostel', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (497, 'allocation_report', 'Allocation Report', 'Rapport d\'allocation', 'Rapporto di assegnazione', 'Relatório de alocação', 'Zuteilungsbericht', 'Informe de asignación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (498, 'route_master', 'Route Master', 'Route Master', 'Route Master', 'Mestre da rota', 'Routenmaster', 'Maestro de ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (499, 'vehicle_master', 'Vehicle Master', 'Véhicule maître', 'Maestro del veicolo', 'Mestre do Veículo', 'Fahrzeugmeister', 'Vehículo maestro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (500, 'stoppage', 'Stoppage', 'Arrêt', 'Arresto', 'Parada', 'Stillstand', 'Paro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (501, 'assign_vehicle', 'Assign Vehicle', 'Assigner un véhicule', 'Assegna veicolo', 'Atribuir Veículo', 'Fahrzeug zuweisen', 'Asignar vehículo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (502, 'reports', 'Reports', 'Rapports', 'Rapporti', 'Relatórios', 'Berichte', 'Informes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (503, 'books_entry', 'Books Entry', 'Entrée de livres', 'Ingresso dei libri', 'Entrada de livros', 'Bucheintrag', 'Entrada de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (504, 'event_type', 'Event Type', 'Event Type', 'Tipo di evento', 'Tipo de evento', 'Ereignistyp', 'Tipo de evento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (505, 'add_events', 'Add Events', 'Ajouter des événements', 'Aggiungi eventi', 'Adicionar eventos', 'Ereignisse hinzufügen', 'Agregar eventos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (506, 'student_accounting', 'Student Accounting', 'Comptabilité des étudiants', 'Contabilità degli studenti', 'Contabilidade Estudantil', 'Studentenbuchhaltung', 'Contabilidad estudiantil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (507, 'create_single_invoice', 'Create Single Invoice', 'Créer une facture unique', 'Crea una singola fattura', 'Criar uma única fatura', 'Einzelrechnung erstellen', 'Crear factura única');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (508, 'create_multi_invoice', 'Create Multi Invoice', 'Créer une facture multiple', 'Crea una fattura multipla', 'Criar fatura múltipla', 'Erstellen Sie eine Mehrfachrechnung', 'Crear factura múltiple');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (509, 'summary_report', 'Summary Report', 'Rapport sommaire', 'Relazione di sintesi', 'Relatório resumido', 'Kurzbericht', 'Informe resumido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (510, 'office_accounting', 'Office Accounting', 'Comptabilité de bureau', 'officium Accounting', 'Contabilidade de Escritórios', 'Bürobuchhaltung', 'Contabilidad de oficina');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (511, 'under_group', 'Under Group', 'Sous groupe', 'Sotto gruppo', 'Em grupo', 'Unter Gruppe', 'Bajo grupo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (512, 'bank_account', 'Bank Account', 'Compte bancaire', 'Conto bancario', 'Conta bancária', 'Bankkonto', 'Cuenta bancaria');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (513, 'ledger_account', 'Ledger Account', 'Compte général', 'Account di contabilità generale', 'Conta contábil', 'Sachkonto', 'Cuenta contable');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (514, 'create_voucher', 'Create Voucher', 'Créer votre bon', 'Crea un voucher', 'Criar comprovante', 'Gutschein erstellen', 'Crear cupón');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (515, 'day_book', 'Day Book', 'Livre de jour', 'Libro del giorno', 'Livro do dia', 'Tagebuch', 'Libro del dia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (516, 'cash_book', 'Cash Book', 'Livre de caisse', 'Buku Tunai', 'Livro caixa', 'Kassenbuch', 'Libro de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (517, 'bank_book', 'Bank Book', 'Livret de banque', 'Libro bancario', 'Caderneta bancária', 'Bank Buch', 'Banco de libros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (518, 'ledger_book', 'Ledger Book', 'Livre de grand livre', 'Libro mastro', 'Livro contábil', 'Hauptbuch', 'Libro mayor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (519, 'trial_balance', 'Trial Balance', 'Balance de vérification', 'Bilancio di verifica', 'Balancete', 'Probebilanz', 'Balance de prueba');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (520, 'settings', 'Settings', 'Réglages', 'impostazioni', 'Definições', 'die Einstellungen', 'Configuraciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (521, 'sms_settings', 'Sms Settings', 'Paramètres Sms', 'Sms Settings', 'Configurações de SMS', 'SMS-Einstellungen', 'Configuraciones de SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (522, 'cash_book_of', 'Cash Book Of', 'Livre de caisse de', 'Libro cassa di', 'Livro De Dinheiro De', 'Kassenbuch von', 'Libro de caja de');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (523, 'by_cash', 'By Cash', 'En espèces', 'In contanti', 'Em dinheiro', 'Bar', 'En efectivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (524, 'by_bank', 'By Bank', 'Par banque', 'Dalla banca', 'Por banco', 'Bar', 'En efectivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (525, 'total_strength', 'Total Strength', 'Force totale', 'Forza totale', 'Força total', 'Gesamtstärke', 'Fuerza total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (526, 'teachers', 'Teachers', 'Enseignants', 'Insegnanti', 'Professores', 'Lehrer', 'Maestros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (527, 'student_quantity', 'Student Quantity', 'Quantité d\'étudiant', 'Quantità di studenti', 'Quantidade de estudantes', 'Studentenmenge', 'Cantidad de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (528, 'voucher', 'Voucher', 'Bon', 'Voucher; tagliando', 'Comprovante', 'Gutschein', 'Vale');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (529, 'total_number', 'Total Number', 'Nombre total', 'Numero totale', 'Número total', 'Gesamtzahl', 'Numero total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (530, 'total_route', 'Total Route', 'Total Route', 'Percorso totale', 'Total Route', 'Gesamtroute', 'Ruta total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (531, 'total_room', 'Total Room', 'Chambre totale', 'Stanza totale', 'Quarto total', 'Gesamtraum', 'Habitación total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (532, 'amount', 'Amount', 'Montant', 'Jumlah', 'Montante', 'Menge', 'Cantidad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (533, 'branch_dashboard', 'Branch Dashboard', 'Tableau de bord de branche', 'Dashboard del ramo', 'Painel de filiais', 'Zweig-Dashboard', 'Tablero de rama');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (534, 'branch_list', 'Branch List', 'Liste de branche', 'Elenco delle filiali', 'Lista de Filial', 'Branchenliste', 'Lista de sucursales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (535, 'create_branch', 'Create Branch', 'Créer une branche', 'Crea un ramo', 'Criar Filial', 'Zweig erstellen', 'Crear rama');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (536, 'branch_name', 'Branch Name', 'Nom de la filiale', 'Nome del ramo', 'Nome da Filial', 'Zweigname', 'Nombre de la sucursal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (537, 'school_name', 'School Name', 'Nom de l\'école', 'Nome della scuola', 'Nome da escola', 'Schulname', 'Nombre de la escuela');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (538, 'mobile_no', 'Mobile No', 'Mobile No', 'Cellulare n', 'Mobile No', 'Handynummer', 'No móviles');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (539, 'symbol', 'Symbol', 'symbole', 'Simbolo', 'Símbolo', 'Symbol', 'Símbolo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (540, 'city', 'City', 'Ville', 'città', 'Cidade', 'Stadt', 'Ciudad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (541, 'academic_year', 'Academic Year', 'Année académique', 'Anno accademico', 'Ano acadêmico', 'Akademisches Jahr', 'Año académico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (542, 'select_branch_first', 'First Select The Branch', 'D\'abord, sélectionnez la branche', 'Prima seleziona il ramo', 'Primeiro selecione o ramo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (543, 'select_class_first', 'Select Class First', 'Sélectionnez la classe d&#39;abord', 'Seleziona prima la classe', 'Selecione a primeira classe', 'Wählen Sie zuerst Klasse', 'Seleccionar clase primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (544, 'select_country', 'Select Country', 'Choisissez le pays', 'Pilih negara', 'Selecione o pais', 'Land auswählen', 'Seleccionar país');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (545, 'mother_tongue', 'Mother Tongue', 'Langue maternelle', 'Madrelingua', 'Língua nativa', 'Muttersprache', 'Lengua materna');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (546, 'caste', 'Caste', 'Caste', 'Casta', 'Casta', 'Kaste', 'Casta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (547, 'present_address', 'Present Address', 'Adresse actuelle', 'Indirizzo attuale', 'Endereço presente', 'Aktuelle Adresse', 'La dirección actual');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (548, 'permanent_address', 'Permanent Address', 'Permanent Address', 'Residenza', 'Oratio permanent', 'fester Wohnsitz', 'dirección permanente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (549, 'profile_picture', 'Profile Picture', 'Image de profil', 'Immagine del profilo', 'Foto do perfil', 'Profilbild', 'Foto de perfil');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (550, 'login_details', 'Login Details', 'détails de connexion', 'dettagli del login', 'detalhes de login', 'Login-Daten', 'detalles de registro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (551, 'retype_password', 'Retype Password', 'Retaper le mot de passe', 'Ripeti password', 'Redigite a senha', 'Passwort erneut eingeben', 'Vuelva a escribir la contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (552, 'occupation', 'Occupation', 'Ocupación', 'Occupazione', 'Ocupação', 'Besetzung', 'Ocupación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (553, 'income', 'Income', 'Ingresos', 'Reddito', 'Renda', 'Einkommen', 'Ingresos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (554, 'education', 'Education', 'Éducation', 'Formazione scolastica', 'Educação', 'Bildung', 'Educación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (555, 'first_select_the_route', 'First Select The Route', 'Sélectionnez d\'abord l\'itinéraire', 'Prima selezionare la rotta', 'Primeiro selecione a rota', 'Wählen Sie zuerst die Route aus', 'Primero seleccione la ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (556, 'hostel_details', 'Hostel Details', 'Détails de l\'hôtel', 'Dettagli dell\'hotel', 'Detalhes do Hostel', 'Hostel Details', 'Detalles del albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (557, 'first_select_the_hostel', 'First Select The Hostel', 'd\'abord sélectionner l\'hôtel', 'Prima seleziona l\'ostello', 'primeiro selecione o albergue', 'Wählen Sie zuerst das Hostel aus', 'Primero seleccione el albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (558, 'previous_school_details', 'Previous School Details', 'Privilege School Détails', 'Dettagli della scuola precedente', 'Detalhes da escola anterior', 'Details zur vorherigen Schule', 'Detalles de la escuela anterior');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (559, 'book_name', 'Book Name', 'Nom du livre', 'Nome del libro', 'Boeknaam', 'Buchname', 'Nombre del libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (560, 'select_ground', 'Select Ground', 'sélectionnez Ground', 'seleziona Terra', 'selecione Ground', 'Wählen Sie Masse', 'Seleccione tierra');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (561, 'import', 'Import', 'Importation', 'Importare', 'Importar', 'Importieren', 'Importar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (562, 'add_student_category', 'Add Student Category', 'Ajouter une catégorie d\'étudiant', 'Aggiungi categoria studente', 'Adicionar categoria de aluno', 'Schülerkategorie hinzufügen', 'Agregar categoría de estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (563, 'id', 'Id', 'Id', 'Id', 'Identidade', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (564, 'edit_category', 'Edit Category', 'Modifier la catégorie', 'Modifica categoria', 'Editar categoria', 'Kategorie bearbeiten', 'Editar categoria');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (565, 'deactivate_account', 'Deactivate Account', 'Désactiver le compte', 'Disattiva Account', 'Desativar conta', 'Konto deaktivieren', 'desactivar cuenta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (566, 'all_sections', 'All Sections', 'toutes les sections', 'tutte le sezioni', 'todas as seções', 'Alle Abschnitte', 'Todas las secciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (567, 'authentication_activate', 'Authentication Activate', 'Authentification Activer', 'Autenticazione Attivare', 'Autenticação Ativar', 'Authentifizierung aktivieren', 'Activar autenticación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (568, 'department', 'Department', 'département', 'Dipartimento', 'Departamento', 'Abteilung', 'Departamento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (569, 'salary_grades', 'Salary Grades', 'Note salariale', 'Grado di stipendio', 'Grau Salarial', 'Gehaltsstufen', 'Grados salariales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (570, 'overtime', 'Overtime Rate (Per Hour)', 'taux des heures supplémentaires (à l\'heure)', 'tasso di straordinario (per ora)', 'taxa de horas extras (por hora)', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (571, 'salary_grade', 'Salary Grade', 'Note salariale', 'Grado di stipendio', 'Grau Salarial', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (572, 'payable_type', 'Payable Type', 'Payable Type', 'Tipo pagabile', 'Tipo pagável', 'Zahlbare Artec', 'Pagadero Typec');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (573, 'edit_type', 'Edit Type', 'Τύπος επεξεργασίας', 'Modifica il tipo', 'Editar tipo', 'Typ bearbeiten', 'Editar tipo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (574, 'role', 'Role', 'Rôle', 'Peran', 'Função', 'Rolle', 'Papel');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (575, 'remuneration_info_for', 'Remuneration Info For', 'Information de rémunération pour', 'Informazioni sulla remunerazione per', 'Informações sobre Remuneração Para', 'Vergütungsinfo für', 'Información de remuneración para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (576, 'salary_paid', 'Salary Paid', 'Salaire payé', 'Stipendio pagato', 'Salário Pago', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (577, 'salary_unpaid', 'Salary Unpaid', 'Salaire impayé', 'Salario non retribuito', 'Salário não remunerado', 'Gehalt unbezahlt', 'Salario no pagado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (578, 'pay_now', 'Pay Now', 'Payez maintenant', 'Paga ora', 'Pague agora', 'Zahlen Sie jetzt', 'Pagar ahora');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (579, 'employee_role', 'Employee Role', 'Rôle de l\'employé', 'Ruolo dei dipendenti', 'Função do Empregado', 'Mitarbeiterrolle', 'Rol del empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (580, 'create_at', 'Create At', 'Créer à', 'Crea At', 'Criar em', 'Erstellen um', 'Crear en');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (581, 'select_employee', 'Select Employee', 'Sélectionnez un employé', 'Pilih Karyawan', 'Selecione Empregado', 'Wählen Sie Mitarbeiter', 'Seleccionar empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (582, 'review', 'Review', 'revisión', 'Revisione', 'Reveja', 'Rezension', 'revisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (583, 'reviewed_by', 'Reviewed By', 'Revu par', 'Recensito da', 'Revisados ​​pela', 'Rezensiert von', 'Revisado por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (584, 'submitted_by', 'Submitted By', 'Proposé par', 'Inviato da', 'Enviado por', 'Eingereicht von', 'Presentado por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (585, 'employee_type', 'Employee Type', 'Type d\'employé', 'Tipo di dipendente', 'Tipo de Empregado', 'Mitarbeitertyp', 'Tipo de empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (586, 'approved', 'Approved', 'Approuvé', 'Approvato', 'Aprovado', 'Genehmigt', 'Aprobado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (587, 'unreviewed', 'Unreviewed', 'Non revu', 'unreviewed', 'Não revisado', 'Nicht überprüft', 'No revisado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (588, 'creation_date', 'Creation Date', 'Creation Date', 'Data di creazione', 'Data de criação', 'Erstellungsdatum', 'Fecha de creación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (589, 'no_information_available', 'No Information Available', 'Pas d\'information disponible', 'Nessuna informazione disponibile', 'Nenhuma informação disponível', 'Keine Information verfügbar', 'No hay información disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (590, 'continue_to_payment', 'Continue To Payment', 'Continuer au paiement', 'Continua a pagamento', 'Continuar para pagamento', 'Weiter zur Zahlung', 'Continuar al pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (591, 'overtime_total_hour', 'Overtime Total Hour', 'Heures totales supplémentaires', 'Ora totale straordinario', 'Horas Totais de Horas Extras', 'Überstunden Gesamtstunde', 'Horas extra horas totales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (592, 'overtime_amount', 'Overtime Amount', 'Heures supplémentaires', 'Quantità Overtime', 'Overwerkbedrag', 'Überstundenbetrag', 'Cantidad de horas extras');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (593, 'remarks', 'Remarks', 'Remarque', 'Ucapan', 'Opmerking', 'Bemerkungen', 'Observaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (594, 'view', 'View', 'Vue', 'vista', 'Visão', 'Aussicht', 'Ver');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (595, 'leave_appeal', 'Leave Appeal', 'Laisser appel', 'Invia Appello', 'Deixar recurso', 'Berufung einlegen', 'Dejar apelación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (596, 'create_leave', 'Create Leave', 'Créer un congé', 'Crea permesso', 'Criar licença', 'Urlaub erstellen', 'Crear licencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (597, 'user_role', 'User Role', 'Rôle de l\'utilisateur', 'Ruolo utente', 'Papel do usuário', 'Benutzer-Rolle', 'Rol del usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (598, 'date_of_start', 'Date Of Start', 'Date de début', 'Data di inizio', 'Data de início', 'Datum des Starts', 'Fecha de inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (599, 'date_of_end', 'Date Of End', 'Date de fin', 'Data della fine', 'Data do fim', 'Datum des Endes', 'Fecha de finalización');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (600, 'winner', 'Winner', 'Gagnantविजेता', 'Vincitore', 'Vencedora', 'Gewinner', 'Ganador');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (601, 'select_user', 'Select User', 'Sélectionnez un utilisateur', 'Seleziona utente', 'Selecione o usuário', 'Wähle den Benutzer', 'Seleccionar usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (602, 'create_class', 'Create Class', 'Créer une classe', 'Crea classe', 'Criar classe', 'Klasse erstellen', 'Crear clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (603, 'class_teacher_allocation', 'Class Teacher Allocation', 'Affectation des enseignants de classe', 'Allocazione degli insegnanti di classe', 'Alocação de professores de turma', 'Zuweisung von Klassenlehrern', 'Asignación de maestro de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (604, 'class_teacher', 'Class Teacher', 'Professeur de classe', 'Insegnante', 'Professor da classe', 'Klassenlehrer', 'Profesor de la clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (605, 'create_subject', 'Create Subject', 'Créer un sujet', 'Crea soggetto', 'Criar assunto', 'Betreff erstellen', 'Crear asunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (606, 'select_multiple_subject', 'Select Multiple Subject', 'Sélectionnez plusieurs sujets', 'Seleziona soggetto multiplo', 'Выберите несколько объектов', 'Wählen Sie Mehrere Betreffs', 'Seleccionar tema múltiple');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (607, 'teacher_assign', 'Teacher Assign', 'Affectation des enseignants', 'Insegnante Assegna', 'Atribuição de professor', 'Lehrer zuweisen', 'Asignación de maestro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (608, 'teacher_assign_list', 'Teacher Assign List', 'Liste d\'affectation des enseignants', 'Elenco di assegnazione dell&#39;insegnante', 'Lista de Atribuições do Professor', 'Lehrerzuweisungsliste', 'Lista de asignación de maestros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (609, 'select_department_first', 'Select Department First', 'Sélectionnez d\'abord le département', 'Seleziona prima il dipartimento', 'Selecione o departamento primeiro', 'Wählen Sie zuerst Abteilung', 'Seleccione el departamento primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (610, 'create_book', 'Create Book', 'Créer un livre', 'Crea libro', 'Criar livro', 'Buch erstellen', 'Crear libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (611, 'book_title', 'Book Title', 'Titre de livre', 'Titolo del libro', 'Título do livro', 'Buchtitel', 'Titulo del libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (612, 'cover', 'Cover', 'Couverture', 'Copertina', 'tampa', 'Startseite', 'Cubrir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (613, 'edition', 'Edition', 'Édition', 'Edizione', 'Edição', 'Auflage', 'Edición');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (614, 'isbn_no', 'ISBN No', 'ISBN Non', 'Codice ISBN', 'Isbn No', 'ISBN-Nr', 'ISBN no');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (615, 'purchase_date', 'Purchase Date', 'Purchase Date', 'Data di acquisto', 'data de compra', 'Kaufdatum', 'Fecha de compra');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (616, 'cover_image', 'Cover Image', 'Cover Image', 'Immagine di copertina', 'Imagem de capa', 'Titelbild', 'Imagen de portada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (617, 'book_issue', 'Book Issue', 'Numéro de livre', 'Edizione del libro', 'Edição do livro', 'Buchausgabe', 'Edición del libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (618, 'date_of_issue', 'Date Of Issue', 'Date d&#39;Emission', 'Data di emissione', 'Data de emissão', 'Ausgabedatum', 'Fecha de emisión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (619, 'date_of_expiry', 'Date Of Expiry', 'Date d\'expiration', 'Data di scadenza', 'Data de validade', 'Haltbarkeitsdatum', 'Fecha de expiración');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (620, 'select_category_first', 'Select Category First', 'Sélectionnez d\'abord la catégorie', 'Seleziona prima la categoria', 'Selecione a categoria primeiro', 'Wählen Sie zuerst Kategorie', 'Seleccione categoría primero');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (621, 'type_name', 'Type Name', 'Nom du type', 'Digitare il nome', 'Digite o nome', 'Modellname', 'Escribe un nombre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (622, 'type_list', 'Type List', 'Liste des types', 'Elenco dei tipi', 'Lista de tipos', 'Typ Liste', 'Lista de tipos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (623, 'icon', 'Icon', 'Icône', 'Icona', 'Ícone', 'Symbol', 'Icono');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (624, 'event_list', 'Event List', 'Liste des événements', 'Elenco degli eventi', 'Lista de evento', 'Veranstaltungsliste', 'Lista de eventos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (625, 'create_event', 'Create Event', 'Créer un évènement', 'Crea Evento', 'Criar Evento', 'Ereignis erstellen', 'Crear evento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (626, 'type', 'Type', 'Type', 'genere', 'Tipo', 'Art', 'Tipo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (627, 'audience', 'Audience', 'Audience', 'Pubblico', 'Público', 'Publikum', 'Audiencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (628, 'created_by', 'Created By', 'Créé par', 'Creato da', 'Criado por', 'Erstellt von', 'Creado por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (629, 'publish', 'Publish', 'Publier', 'Pubblicare', 'Publicar', 'Veröffentlichen', 'Publicar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (630, 'everybody', 'Everybody', 'Tout le monde', 'Tutti', 'Todo o mundo', 'Jeder', 'Todos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (631, 'selected_class', 'Selected Class', 'Classe sélectionnée', 'Classe selezionata', 'Classe Selecionada', 'Ausgewählte Klasse', 'Clase seleccionada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (632, 'selected_section', 'Selected Section', 'Section sélectionnée', 'Sezione selezionata', 'Seção Selecionada', 'Ausgewählter Abschnitt', 'Sección Seleccionada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (633, 'information_has_been_updated_successfully', 'Information Has Been Updated Successfully', 'Les informations ont été mises à jour avec succès', 'Le informazioni sono state aggiornate con successo', 'Informações foram atualizadas com sucesso', 'Informationen wurden erfolgreich aktualisiert', 'La información ha sido actualizada exitosamente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (634, 'create_invoice', 'Create Invoice', 'Créer une facture', 'Crea fattura', 'Criar recibo', 'Rechnung erstellen', 'Crear factura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (635, 'invoice_entry', 'Invoice Entry', 'Saisie de facture', 'Voce fattura', 'Entrada de fatura', 'Rechnungserfassung', 'Entrada de factura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (636, 'quick_payment', 'Quick Payment', 'Paiement rapide', 'Pagamento rapido', 'Pagamento Rápido', 'Schnelle Zahlung', 'Pago rápido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (637, 'write_your_remarks', 'Write Your Remarks', 'Écrivez vos remarques', 'Scrivi i tuoi commenti', 'Escreva suas observações', 'Schreiben Sie Ihre Bemerkungen', 'Escribe tus comentarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (638, 'reset', 'Reset', 'Réinitialiser', 'Ripristina', 'Restabelecer', 'Zurücksetzen', 'Reiniciar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (639, 'fees_payment_history', 'Fees Payment History', 'Historique des paiements', 'Cronologia pagamenti', 'Histórico de pagamento de taxas', 'Gebühren Zahlungsverlauf', 'Honorarios Historial de pagos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (640, 'fees_summary_report', 'Fees Summary Report', 'Rapport sommaire des frais', 'Rapporto di riepilogo commissioni', 'Relatório resumido de taxas', 'Gebührenübersicht', 'Informe de resumen de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (641, 'add_account_group', 'Add Account Group', 'Ajouter un groupe de comptes', 'Aggiungi gruppo di account', 'Adicionar grupo de contas', 'Kontogruppe hinzufügen', 'Agregar grupo de cuentas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (642, 'account_group', 'Account Group', 'Compte de groupe', 'Gruppo di account', 'Accountgroep', 'Kontengruppe', 'Grupo de cuentas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (643, 'account_group_list', 'Account Group List', 'Liste des groupes de comptes', 'Elenco dei gruppi di account', 'Lista de grupos de contas', 'Kontengruppenliste', 'Lista de grupos de cuentas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (644, 'mailbox', 'Mailbox', 'Boites aux lettres', 'Cassetta postale', 'Caixa de correio', 'Mailbox', 'Buzón');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (645, 'refresh_mail', 'Refresh Mail', 'Refresh Mail', 'Aggiorna posta', 'Refresh Mail', 'Refresh Mail', 'Actualizar correo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (646, 'sender', 'Sender', 'expéditeur', 'mittente', 'remetente', 'Sender', 'remitente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (647, 'general_settings', 'General Settings', 'réglages généraux', 'impostazioni generali', 'Configurações Gerais', 'Allgemeine Einstellungen', 'Configuración general');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (648, 'institute_name', 'Institute Name', 'Nom de l&#39;Institut', 'Nome Istituto', 'Nome do Instituto', 'Institutsname', 'nombre del Instituto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (649, 'institution_code', 'Institution Code', 'Institution Code', 'Codice di istituzione', 'Código da Instituição', 'Institutionscode', 'Código Institucional');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (650, 'sms_service_provider', 'Sms Service Provider', 'Fournisseur de services SMS', 'Sms Service Provider', 'Provedor de serviços de SMS', 'SMS-Dienstleister', 'Proveedor de servicios SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (651, 'footer_text', 'Footer Text', 'Texte de pied de page', 'Piè di pagina di testo', 'Texto de rodapé', 'Fusszeile', 'Texto de pie de página');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (652, 'payment_control', 'Payment Control', 'Contrôle des paiements', 'Controllo dei pagamenti', 'Texto de rodapé', 'Zahlungskontrolle', 'Control de pagos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (653, 'sms_config', 'Sms Config', 'Config Sms', 'Config. SMS', 'Sms Config', 'SMS-Konfiguration', 'Configuración de SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (654, 'sms_triggers', 'Sms Triggers', 'Déclencheurs SMS', 'Trigger Sms', 'Sms Triggers', 'SMS-Trigger', 'Disparadores de SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (655, 'authentication_token', 'Authentication Token', 'Jeton d\'authentification', 'Token di autenticazione', 'Token de Autenticação', 'Authentifizierungstoken', 'Token de autenticación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (656, 'sender_number', 'Sender Number', 'Numéro d\'expéditeur', 'Numero mittente', 'Número do remetente', 'Sender Number', 'Número de remitente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (657, 'username', 'Username', 'Nom d\'utilisateur', 'Nome utente', 'Nome de usuário', 'Nutzername', 'Nombre de usuario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (658, 'api_key', 'Api Key', 'Clé API', 'Api Key', 'Chave API', 'API-Schlüssel', 'Clave API');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (659, 'authkey', 'Authkey', 'Authkey', 'authkey', 'Chave de autenticação', 'Authkey', 'Authkey');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (660, 'sender_id', 'Sender Id', 'Identifiant de l\'expéditeur', 'Identità del mittente', 'ID de envio', 'Sender Id', 'Identificación del remitente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (661, 'sender_name', 'Sender Name', 'Nom de l\'expéditeur', 'Nome del mittente', 'Nome do remetente', 'Sender Name', 'Nombre del remitente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (662, 'hash_key', 'Hash Key', 'Touche dièse', 'Tasto cancelletto', 'Chave de hash', 'Hash-Schlüssel', 'Clave hash');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (663, 'notify_enable', 'Notify Enable', 'Notify Enable', 'Notifica Abilita', 'Notificar Ativar', 'Benachrichtigen aktivieren', 'Notificar Habilitar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (664, 'exam_attendance', 'Exam Attendance', 'Participation aux examens', 'Partecipazione all\'esame', 'Participação no exame', 'Teilnahme an der Prüfung', 'Asistencia al examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (665, 'exam_results', 'Exam Results', 'Résultats d\'examen', 'Risultati degli esami', 'Resultados dos exames', 'Prüfungsergebnisse', 'Resultados de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (666, 'email_config', 'Email Config', 'Email Config', 'Config email', 'Configuração de email', 'E-Mail-Konfiguration', 'Configuración de correo electrónico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (667, 'email_triggers', 'Email Triggers', 'Déclencheurs de messagerie', 'Trigger e-mail', 'Disparadores de email', 'E-Mail-Trigger', 'Disparadores de correo electrónico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (668, 'account_registered', 'Account Registered', 'Compte enregistré', 'Account registrato', 'Conta Registrada', 'Konto registriert', 'Cuenta registrada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (669, 'forgot_password', 'Forgot Password', 'Mot de passe oublié', 'Ha dimenticato la password', 'Esqueceu a senha', 'Passwort vergessen', 'Se te olvidó tu contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (670, 'new_message_received', 'New Message Received', 'Nouveau message reçu', 'Nuovo messaggio ricevuto', 'Nova mensagem recebida', 'Neue Nachricht empfangen', 'Nuevo mensaje recibido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (671, 'payslip_generated', 'Payslip Generated', 'Fiche de paie générée', 'Busta paga generata', 'Payslip Generated', 'Gehaltsabrechnung generiert', 'Boleta de pago generada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (672, 'leave_approve', 'Leave Approve', 'Laisser approuver', 'Lasciare Approva', 'Deixar Aprovar', 'Genehmigen lassen', 'Dejar aprobar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (673, 'leave_reject', 'Leave Reject', 'Laisser rejeter', 'Lascia rifiutare', 'Deixar Rejeitar', 'Ablehnen lassen', 'Dejar rechazar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (674, 'advance_salary_approve', 'Leave Reject', 'Laisser rejeter', 'Lascia rifiutare', 'Deixar Rejeitar', 'Ablehnen lassen', 'Dejar rechazar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (675, 'advance_salary_reject', 'Advance Salary Reject', 'Rejet de salaire anticipé', 'Rifiuto anticipato dello stipendio', 'Rejeição antecipada de salário', 'Vorauszahlung ablehnen', 'Rechazo de salario anticipado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (676, 'add_session', 'Add Session', 'Ajouter une session', 'Aggiungi sessione', 'Adicionar sessão', 'Sitzung hinzufügen', 'Agregar sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (677, 'session', 'Session', 'Session', 'Sessione', 'Sessão', 'Session', 'Sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (678, 'created_at', 'Created At', 'Créé à', 'Creato a', 'Criado em', 'Hergestellt in', 'Creado en');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (679, 'sessions', 'Sessions', 'Sessions', 'sessioni', 'Sessões', 'Sitzungen', 'Sesiones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (680, 'flag', 'Flag', 'Drapeau', 'Bandiera', 'Bandeira', 'Flagge', 'Bandera');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (681, 'stats', 'Stats', 'Statistiques', 'Statistiche', 'Estatísticas', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (682, 'updated_at', 'Updated At', 'Mis à jour à', 'Aggiornato alle', 'Atualizado em', 'Aktualisiert am', 'Actualizado en');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (683, 'flag_icon', 'Flag Icon', 'Icône de drapeau', 'Icona bandiera', 'Ícone de bandeira', 'Flaggensymbol', 'Icono de la bandera');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (684, 'password_restoration', 'Password Restoration', 'Restauration du mot de passe', 'Ripristino password', 'Restauração de senha', 'Passwortwiederherstellung', 'Restauración de contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (685, 'forgot', 'Forgot', 'Oublié', 'dimenticato', 'Esqueceu', 'Vergessen', 'Olvidó');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (686, 'back_to_login', 'Back To Login', 'Retour connexion', 'Torna al login', 'Volte ao login', 'Zurück zur Anmeldung', 'Atrás para iniciar sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (687, 'database_list', 'Database List', 'Liste des bases de données', 'Elenco database', 'Lista de banco de dados', 'Datenbankliste', 'Lista de bases de datos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (688, 'create_backup', 'Create Backup', 'Créer une sauvegarde', 'Creare il backup', 'Criar backup', 'Ein Backup erstellen', 'Crear copia de seguridad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (689, 'backup', 'Backup', 'Sauvegarde', 'Backup', 'Cópia de segurança', 'Backup', 'Apoyo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (690, 'backup_size', 'Backup Size', 'Taille de sauvegarde', 'Dimensione del backup', 'Tamanho do backup', 'Sicherungsgröße', 'Tamaño de respaldo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (691, 'file_upload', 'File Upload', 'Téléchargement de fichiers', 'File Upload', 'Upload de arquivo', 'Datei-Upload', 'Subir archivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (692, 'parents_details', 'Parents Details', 'Détails des parents', 'Dettagli dei genitori', 'Detalhes dos pais', 'Eltern Details', 'Detalles de los padres');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (693, 'social_links', 'Social Links', 'Liens sociaux', 'Link sociali', 'Links sociais', 'Soziale Links', 'vínculos sociales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (694, 'create_hostel', 'Create Hostel', 'Créer une auberge', 'Crea un ostello', 'Criar Hostel', 'Hostel erstellen', 'Crear albergue');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (695, 'allocation_list', 'Allocation List', 'Allocation List', 'Elenco di allocazione', 'Lista de alocação', 'Zuordnungsliste', 'Lista de asignaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (696, 'payslip_history', 'Payslip History', 'Historique des fiches de paie', 'Storia della busta paga', 'Histórico de holerites', 'Gehaltsabrechnungsverlauf', 'Historial de recibo de sueldo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (697, 'my_attendance_overview', 'My Attendance Overview', 'Présentation de My Attendance', 'Panoramica delle mie presenze', 'Visão geral de Minha participação', 'Meine Anwesenheitsübersicht', 'Resumen de mi asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (698, 'total_present', 'Total Present', 'Total présent', 'Totale presente', 'Total Present', 'Gesamtgeschenk', 'Presente total');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (699, 'total_absent', 'Total Absent', 'Total Absent', 'Assente totale', 'Total Ausente', 'Total abwesend', 'Total ausente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (700, 'total_late', 'Total Late', 'Total en retard', 'Totale in ritardo', 'Total Late', 'Total spät', 'Total tarde');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (701, 'class_teacher_list', 'Class Teacher List', 'Liste des enseignants de classe', 'Elenco degli insegnanti di classe', 'Lista de Professores', 'Klassenlehrerliste', 'Lista de maestros de clase');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (702, 'section_control', 'Section Control', 'Section Control', 'Controllo sezione', 'Controle de Seção', 'Abschnittskontrolle', 'Control de sección');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (703, 'capacity ', 'Capacity', 'Capacité', 'Capacità', 'Capacidade', 'Kapazität', 'Capacidad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (704, 'request', 'Request', 'Demande', 'Richiesta', 'Solicitação', 'Anfrage', 'Solicitud');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (705, 'salary_year', 'Salary Year', 'Année de salaire', 'Anno di stipendio', 'Salário Ano', 'Gehaltsjahr', 'Año de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (706, 'create_attachments', 'Create Attachments', 'Créer des pièces jointes', 'Crea allegati', 'Criar Anexos', 'Anhänge erstellen', 'Crear archivos adjuntos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (707, 'publish_date', 'Publish Date', 'Publish Date', 'Data di pubblicazione', 'Data de publicação', 'Datum der Veröffentlichung', 'Fecha de publicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (708, 'attachment_file', 'Attachment File', 'Fichier joint', 'File allegato', 'Ficheiro em anexo', 'Anhangsdatei', 'Archivo adjunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (709, 'age', 'Age', 'Âge', 'Età', 'Era', 'Alter', 'Años');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (710, 'student_profile', 'Student Profile', 'Profil étudiant', 'Profilo dello studente', 'Perfil do aluno', 'Studenten Profil', 'Perfil de estudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (711, 'authentication', 'Authentication', 'Authentification', 'Autenticazione', 'Autenticação', 'Authentifizierung', 'Autenticación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (712, 'parent_information', 'Parent Information', 'Parent Information', 'Informazioni sui genitori', 'Informações aos pais', 'Übergeordnete Informationen', 'Información para padres');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (713, 'full_marks', 'Full Marks', 'La totalité des points', 'Pieni voti', 'Marcas Completas', 'Volle Punktzahl', 'La máxima puntuación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (714, 'passing_marks', 'Passing Marks', 'Marques de passage', 'Segni di passaggio', 'Marcas de passagem', 'Passing Marks', 'Marcas de paso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (715, 'highest_marks', 'Highest Marks', 'Marques les plus élevées', 'I voti più alti', 'Marcas mais altas', 'Höchste Punktzahl', 'Marcas más altas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (716, 'unknown', 'Unknown', 'Inconnue', 'Sconosciuto', 'Desconhecido', 'Unbekannt', 'Desconocido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (717, 'unpublish', 'Unpublish', 'Annuler la publication', 'Non pubblicato', 'Cancelar publicação', 'Nicht veröffentlichen', 'Anular publicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (718, 'login_authentication_deactivate', 'Login Authentication Deactivate', 'Authentification de connexion désactivée', 'Autenticazione di accesso Disattivata', 'Autenticação de login desativada', 'Login-Authentifizierung deaktivieren', 'Autenticación de inicio de sesión Desactivar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (719, 'employee_profile', 'Employee Profile', 'Profil d\'employé', 'Profilo del dipendente', 'Perfil do Funcionário', 'Angestelltenprofil', 'Perfil de empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (720, 'employee_details', 'Employee Details', 'Détails de l\'employé', 'Dettagli dei dipendenti', 'Detalhes do Funcionário', 'Mitarbeiterdetails', 'Detalles sobre empleados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (721, 'salary_transaction', 'Salary Transaction', 'Transaction salariale', 'Transazione salariale', 'Transação Salarial', 'Gehaltsabwicklung', 'Transacción Salarial');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (722, 'documents', 'Documents', 'Documents', 'Documenti', 'Documentos', 'Unterlagen', 'Documentos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (723, 'actions', 'Actions', 'Actions', 'Azioni', 'Ações', 'Aktionen', 'Comportamiento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (724, 'activity', 'Activity', 'Activité', 'Attività', 'Atividade', 'Aktivität', 'Actividad');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (725, 'department_list', 'Department List', 'Liste des départements', 'Elenco dipartimentale', 'Lista de departamentos', 'Abteilungsliste', 'Lista de departamentos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (726, 'manage_employee_salary', 'Manage Employee Salary', 'Gérer le salaire des employés', 'Gestire il salario dei dipendenti', 'Gerenciar salário dos funcionários', 'Mitarbeitergehalt verwalten', 'Administrar el salario del empleado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (727, 'the_configuration_has_been_updated', 'The Configuration Has Been Updated', 'La configuration a été mise à jour', 'La configurazione è stata aggiornata', 'A configuração foi atualizada', 'Die Konfiguration wurde aktualisiert', 'La configuración ha sido actualizada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (728, 'add', 'Add', 'Ajouter', 'Inserisci', 'Adicionar', 'Hinzufügen', 'Añadir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (729, 'create_exam', 'Create Exam', 'Créer un examen', 'Crea esame', 'Criar exame', 'Prüfung erstellen', 'Crear examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (730, 'term', 'Term', 'Terme', 'Termine', 'Prazo', 'Begriff', 'Término');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (731, 'add_term', 'Add Term', 'Ajouter un terme', 'Aggiungi termine', 'Adicionar termo', 'Begriff hinzufügen', 'Agregar término');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (732, 'create_grade', 'Create Grade', 'Créer une note', 'Crea grado', 'Criar nota', 'Note erstellen', 'Crear calificación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (733, 'mark_starting', 'Mark Starting', 'Mark Starting', 'Segna inizio', 'Marcar partida', 'Markieren Sie Start', 'Marcar inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (734, 'mark_until', 'Mark Until', 'Marquer jusqu\'à', 'Mark Until', 'Marcar até', 'Markieren Sie bis', 'Marcar hasta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (735, 'room_list', 'Room List', 'Liste des chambres', 'Elenco camere', 'Lista de quartos', 'Zimmerliste', 'Lista de habitaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (736, 'room', 'Room', 'Chambre', 'Camera', 'Sala', 'Zimmer', 'Habitación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (737, 'route_list', 'Route List', 'Liste des itinéraires', 'Elenco rotte', 'Lista de rotas', 'Routenliste', 'Lista de ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (738, 'create_route', 'Create Route', 'Créer un itinéraire', 'Crea percorso', 'Criar rota', 'Route erstellen', 'Crear ruta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (739, 'vehicle_list', 'Vehicle List', 'Liste des véhicules', 'Elenco dei veicoli', 'Lista de Veículos', 'Fahrzeugliste', 'Lista de vehículos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (740, 'create_vehicle', 'Create Vehicle', 'Créer un véhicule', 'Crea veicolo', 'Criar veículo', 'Fahrzeug erstellen', 'Crear vehículo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (741, 'stoppage_list', 'Stoppage List', 'Liste des arrêts', 'Elenco di interruzione', 'Lista de interrupções', 'Stoppliste', 'Lista de paro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (742, 'create_stoppage', 'Create Stoppage', 'Créer un arrêt', 'Crea interruzione', 'Criar parada', 'Stopp erstellen', 'Crear paro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (743, 'stop_time', 'Stop Time', 'Temps d\'arrêt', 'Tempo di stop', 'Pare o tempo', 'Stoppzeit', 'Para el tiempo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (744, 'employee_attendance', 'Employee Attendance', 'Présence des employés', 'Partecipazione dei dipendenti', 'Atendimento ao Empregado', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (745, 'attendance_report', 'Attendance Report', 'Présence des employés', 'Partecipazione dei dipendenti', 'Participação dos funcionários', 'Mitarbeiterbetreuung', 'Asistencia de empleados');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (746, 'opening_balance', 'Opening Balance', 'Solde d\'ouverture', 'Saldo di apertura', 'Saldo inicial', 'Anfangsbestand', 'Saldo de apertura');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (747, 'add_opening_balance', 'Add Opening Balance', 'Ajouter un solde d\'ouverture', 'Aggiungi saldo iniziale', 'Adicionar saldo inicial', 'Eröffnungsguthaben hinzufügen', 'Agregar saldo inicial');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (748, 'credit', 'Credit', 'Crédit', 'Credito', 'Crédito', 'Anerkennung', 'Crédito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (749, 'debit', 'Debit', 'Débit', 'Addebito', 'Débito', 'Lastschrift', 'Débito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (750, 'opening_balance_list', 'Opening Balance List', 'liste des soldes d\'ouverture', 'elenco di bilancio di apertura', 'lista de balanços de abertura', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (751, 'voucher_list', 'Voucher List', 'Liste des bons', 'Elenco dei buoni', 'Lista de Vouchers', 'Gutscheinliste', 'Lista de cupones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (752, 'voucher_head', 'Voucher Head', 'Tête de bon', 'Voucher Head', 'Chefe de comprovante', 'Gutscheinkopf', 'Cabeza de bono');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (753, 'payment_method', 'Payment Method', 'Mode de paiement', 'Metodo di pagamento', 'Forma de pagamento', 'Bezahlverfahren', 'Método de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (754, 'credit_ledger_account', 'Credit Ledger Account', 'Compte de crédit', 'Conto contabilità', 'Conta do razão de crédito', 'Kredit-Ledger-Konto', 'Cuenta de libro mayor de crédito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (755, 'debit_ledger_account', 'Debit Ledger Account', 'Compte du livre de débit', 'Conto contabilità clienti', 'Conta do razão de débito', 'Debit-Ledger-Konto', 'Cuenta de libro mayor de débito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (756, 'voucher_no', 'Voucher No', 'Numéro de bon', 'Buono n', 'Voucher No', 'Gutschein Nr', 'Vale no');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (757, 'balance', 'Balance', 'Équilibre', 'Equilibrio', 'Saldo', 'Balance', 'Balance');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (758, 'event_details', 'Event Details', 'Détails de l\'évènement', 'dettagli dell\'evento', 'detalhes do evento', 'Veranstaltungsdetails', 'Detalles del evento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (759, 'welcome_to', 'Welcome To', 'Bienvenue à', 'Benvenuto a', 'Bem-vindo ao', 'Willkommen zu', 'Bienvenido a');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (760, 'report_card', 'Report Card', 'Bulletin scolaire', 'Pagella', 'Boletim', 'Zeugnis', 'Boleta de calificaciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (761, 'online_pay', 'Online Pay', 'Paiement en ligne', 'Paga online', 'Pagamento Online', 'Online Pay', 'Pago en línea');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (762, 'annual_fees_summary', 'Annual Fees Summary', 'Résumé des frais annuels', 'Riepilogo tariffe annuali', 'Resumo das taxas anuais', 'Jährliche Gebührenübersicht', 'Resumen de tarifas anuales');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (763, 'my_children', 'My Children', 'Mes enfants', 'I miei figli', 'Minhas crianças', 'Meine Kinder', 'Mis hijos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (764, 'assigned', 'Assigned', 'Attribué', 'Assegnato', 'Atribuído', 'Zugewiesen', 'Asignado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (765, 'confirm_password', 'Confirm Password', 'Confirmez le mot de passe', 'conferma password', 'Confirme a Senha', 'Kennwort bestätigen', 'Confirmar contraseña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (766, 'searching_results', 'Searching Results', 'Résultats de la recherche', 'Ricerca dei risultati', 'Pesquisando Resultados', 'Suchergebnisse', 'Resultados de búsqueda');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (767, 'information_has_been_saved_successfully', 'Information Has Been Saved Successfully', 'Les informations ont été enregistrées avec succès', 'Le informazioni sono state salvate correttamente', 'As informações foram salvas com sucesso', 'Informationen wurden erfolgreich gespeichert', 'La información se ha guardado correctamente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (768, 'information_deleted', 'The information has been successfully deleted', 'L\'information a été supprimée avec succès', 'Le informazioni sono state cancellate con successo', 'A informação foi apagada com sucesso', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (769, 'deleted_note', '*Note : This data will be permanently deleted', '* Remarque: ces données seront définitivement supprimées.', '* Nota: questi dati saranno eliminati in modo permanente', '* Nota: Estes dados serão permanentemente excluídos', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (770, 'are_you_sure', 'Are You Sure?', 'Êtes-vous sûr?', 'Sei sicuro?', 'Você tem certeza?', 'Bist du sicher?', '¿Estás seguro?');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (771, 'delete_this_information', 'Do You Want To Delete This Information?', 'Voulez-vous supprimer cette information?', 'Vuoi eliminare queste informazioni?', 'Você deseja excluir esta informação?', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (772, 'yes_continue', 'Yes, Continue', 'Oui, continuez', 'Sì, continua', 'Sim, continue', 'Ja, weiter', 'Sí, continuar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (773, 'deleted', 'Deleted', 'Effacé', 'Deleted', 'Excluído', 'Gelöscht', 'Eliminado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (774, 'collect', 'Collect', 'Collecte', 'Raccogliere', 'Coletar', 'Sammeln', 'Recoger');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (775, 'school_setting', 'School Setting', 'Milieu scolaire', 'Impostazione della scuola', 'Escola, armando', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (776, 'set', 'Set', 'Ensemble', 'Impostato', 'Conjunto', 'einstellen', 'Conjunto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (777, 'quick_view', 'Quick View', 'Aperçu rapide', 'Occhiata veloce', 'Olhada rápida', 'Schnellansicht', 'Vista rápida');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (778, 'due_fees_invoice', 'Due Fees Invoice', 'Facture due', 'Fattura dovuta', '', 'Rechnung über fällige Gebühren', 'Factura de cuotas adeudadas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (779, 'my_application', 'My Application', 'Mon application', 'La mia applicazione', '', 'Meine Bewerbung', 'Mi aplicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (780, 'manage_application', 'Manage Application', 'Gérer l\'application', 'Gestisci applicazione', '', 'Anwendung verwalten', 'Administrar aplicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (781, 'leave', 'Leave', 'Laisser', 'Partire', '', 'Verlassen', 'Salir');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (782, 'live_class_rooms', 'Live Class Rooms', 'Salles de cours en direct', 'Aule dal vivo', '', 'Live-Klassenräume', 'Salas de clase en vivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (783, 'homework', 'Homework', 'Devoirs', 'Compiti a casa', '', 'Hausaufgaben', 'Deberes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (784, 'evaluation_report', 'Evaluation Report', 'Rapport d\'évaluation', 'Rapporto di valutazione', '', 'Bewertungsbericht', 'Reporte de evaluacion');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (785, 'exam_term', 'Exam Term', 'Durée de l\'examen', 'Termine dell\'esame', '', 'Prüfungssemester', 'Término del examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (786, 'distribution', 'Distribution', 'Distribution', 'Distribuzione', '', 'Verteilung', 'Distribución');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (787, 'exam_setup', 'Exam Setup', 'Configuration de l\'examen', 'Configurazione dell\'esame', '', 'Prüfungsaufbau', 'Configuración de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (788, 'sms', 'Sms', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (789, 'fees_type', 'Fees Type', 'Type de frais', 'Tipo di commissioni', '', 'Gebührenart', 'Tipo de honorarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (790, 'fees_group', 'Fees Group', 'Groupe de frais', 'Gruppo di commissioni', '', 'Gebührengruppe', 'Grupo de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (791, 'fine_setup', 'Fine Setup', 'Configuration fine', 'Setup fine', '', 'Feines Setup', 'Configuración fina');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (792, 'fees_reminder', 'Fees Reminder', 'Rappel des frais', 'Promemoria', '', 'Gebührenerinnerung', 'Recordatorio de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (793, 'new_deposit', 'New Deposit', 'Nouveau dépôt', 'Nuovo deposito', '', 'Neue Einzahlung', 'Nuevo depósito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (794, 'new_expense', 'New Expense', 'Nouvelle dépense', 'Nuova spesa', '', 'Neue Ausgaben', 'Nuevo gasto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (795, 'all_transactions', 'All Transactions', 'toutes transactions', 'Tutte le transazioni', '', 'Alle Transaktionen', 'Todas las transacciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (796, 'head', 'Head', 'Tête', 'Testa', '', 'Kopf', 'Cabeza');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (797, 'fees_reports', 'Fees Reports', 'Rapports sur les frais', 'Commissioni', '', 'Gebührenberichte', 'Informes de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (798, 'fees_report', 'Fees Report', 'Rapport sur les frais', 'Rapporto sulle commissioni', '', 'Gebührenbericht', 'Informe de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (799, 'receipts_report', 'Receipts Report', 'Rapport sur les reçus', 'Rapporto sulle ricevute', '', 'Belegbericht', 'Informe de recibos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (800, 'due_fees_report', 'Due Fees Report', 'Rapport sur les frais dus', 'Rapporto sulle commissioni dovute', '', 'Bericht über fällige Gebühren', 'Informe de tarifas adeudadas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (801, 'fine_report', 'Fine Report', 'Beau rapport', 'Rapporto eccellente', '', '', 'Informe fino');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (802, 'financial_reports', 'Financial Reports', 'Rapports financiers', 'Resoconti finanziari', '', '', 'Reportes financieros');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (803, 'statement', 'Statement', 'Déclaration', 'dichiarazione', '', '', 'Declaración');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (804, 'repots', 'Repots', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (805, 'expense', 'Expense', 'Frais', 'Spese', '', '', 'Gastos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (806, 'transitions', 'Transitions', 'Transitions', 'transizioni', '', '', 'Transiciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (807, 'sheet', 'Sheet', 'Feuille', 'Foglio', '', '', 'Sábana');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (808, 'income_vs_expense', 'Income Vs Expense', 'Revenu contre dépenses', 'Entrate vs. spese', '', '', 'Ingresos vs gastos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (809, 'attendance_reports', 'Attendance Reports', 'Rapports de présence', 'Rapporti di presenza', '', '', 'Informes de asistencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (810, 'examination', 'Examination', 'Examen', 'Visita medica', '', '', 'Examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (811, 'school_settings', 'School Settings', 'Impostazione della scuola', 'Impostazioni della scuola', '', '', 'Configuraciones escolares');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (812, 'role_permission', 'Role Permission', 'Autorisation de rôle', 'Autorizzazione al ruolo', '', '', 'Permiso de rol');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (813, 'cron_job', 'Cron Job', 'Tâche planifiée', 'Cron Job', '', '', 'Cron Job');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (814, 'custom_field', 'Custom Field', 'Champ personnalisé', 'Campo personalizzato', '', '', 'Campo personalizado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (815, 'enter_valid_email', 'Enter Valid Email', 'Entrez une adresse email valide', 'Inserisci un indirizzo e-mail valido', '', '', 'Ingrese un email valido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (816, 'lessons', 'Lessons', 'Cours', 'Lezioni', '', '', 'Lecciones');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (817, 'live_class', 'Live Class', 'Cours en direct', 'Classe dal vivo', '', '', 'Clase en vivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (818, 'sl', 'Sl', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (819, 'meeting_id', 'Meeting ID', 'Cours en direct', 'Classe dal vivo', '', '', 'Clase en vivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (820, 'start_time', 'Start Time', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (821, 'end_time', 'End Time', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (822, 'zoom_meeting_id', 'Zoom Meeting Id', 'Zoom ID de réunion', 'Zoom ID riunione', '', '', 'Zoom ID de reunión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (823, 'zoom_meeting_password', 'Zoom Meeting Password', 'Zoom sur le mot de passe de la réunion', 'Zoom password riunione', '', '', 'Zoom Contraseña de reunión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (824, 'time_slot', 'Time Slot', 'Créneau horaire', 'Fascia oraria', '', '', 'Ranura de tiempo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (825, 'send_notification_sms', 'Send Notification Sms', 'Envoyer des SMS de notification', 'Invia SMS di notifica', '', '', 'Enviar SMS de notificación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (826, 'host', 'Host', 'Hôte', 'Ospite', '', '', 'Anfitrión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (827, 'school', 'School', 'École', 'Scuola', '', '', 'Colegio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (828, 'accounting_links', 'Accounting Links', 'Liens comptables', 'Collegamenti di contabilità', '', '', 'Enlaces contables');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (829, 'applicant', 'Applicant', 'Demandeur', 'Richiedente', '', '', 'Solicitante');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (830, 'apply_date', 'Apply Date', 'Date d\'application', 'Applica data', '', '', 'Fecha de aplicación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (831, 'add_leave', 'Add Leave', 'Ajouter un congé', 'Aggiungi congedo', '', '', 'Agregar licencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (832, 'leave_date', 'Leave Date', 'Date de départ', 'Lascia la data', '', '', 'Fecha de partida');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (833, 'attachment', 'Attachment', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (834, 'comments', 'Comments', 'commentaires', 'Commenti', '', '', 'Comentarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (835, 'staff_id', 'Staff Id', 'Identifiant du personnel', 'ID personale', '', '', 'Identificación del personal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (836, 'income_vs_expense_of', 'Income Vs Expense Of', 'Revenu contre dépenses de', 'Entrate vs spese di', '', '', 'Ingresos vs gastos de');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (837, 'designation_name', 'Designation Name', 'Nom de la désignation', 'Nome di designazione', '', '', 'Nombre de designación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (838, 'already_taken', 'This %s already exists.', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (839, 'department_name', 'Department Name', 'Nom du département', 'Nome Dipartimento', '', '', 'Nombre de Departamento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (840, 'date_of_birth', 'Date Of Birth', '', '', '', 'Geburtsdatum', 'Fecha de nacimiento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (841, 'bulk_delete', 'Bulk Delete', 'Suppression groupée', 'Elimina in blocco', '', '', 'Eliminar a granel');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (842, 'guardian_name', 'Guardian Name', 'Nom du gardien', 'Nome della guardia', '', '', 'Nombre del tutor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (843, 'fees_progress', 'Fees Progress', 'Progression des frais', 'Commissioni Progresso', '', '', 'Tasas de progreso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (844, 'evaluate', 'Evaluate', 'Évaluer', 'Valutare', '', '', 'Evaluar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (845, 'date_of_homework', 'Date Of Homework', 'Date des devoirs', 'Data dei compiti', '', '', 'Fecha de tarea');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (846, 'date_of_submission', 'Date Of Submission', 'Date de soumission', 'Data di presentazione', '', '', 'Fecha de presentación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (847, 'student_fees_report', 'Student Fees Report', 'Rapport sur les frais de scolarité', 'Rapporto sulle tasse studentesche', '', '', 'Informe de tarifas estudiantiles');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (848, 'student_fees_reports', 'Student Fees Reports', 'Rapports sur les frais de scolarité', 'Rapporti sulle tasse degli studenti', '', '', 'Informes de tarifas de estudiantes');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (849, 'due_date', 'Due Date', 'Due Date', 'Due Date', '', '', 'Fecha de vencimiento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (850, 'payment_date', 'Payment Date', 'Date de paiement', 'Data di pagamento', '', '', 'Fecha de pago');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (851, 'payment_via', 'Payment Via', 'Paiement via', 'Pagamento via', '', '', 'Pago vía');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (852, 'generate', 'Generate', 'produire', 'creare', '', '', 'Generar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (853, 'print_date', 'Print Date', 'Print Date', 'Data di stampa', '', '', 'Fecha de impresion');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (854, 'bulk_sms_and_email', 'Bulk Sms And Email', 'Sms en vrac et email', 'SMS all\'ingrosso ed e-mail', '', '', 'SMS a granel y correo electrónico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (855, 'campaign_type', 'Campaign Type', 'Type de campagne', 'Tipo di campagna', '', '', 'Tipo de campaña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (856, 'both', 'Both', 'Tous les deux', 'Tutti e due', '', '', 'Ambos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (857, 'regular', 'Regular', 'Ordinaire', 'Regolare', '', '', 'Regular');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (858, 'Scheduled', 'Scheduled', 'Programmé', 'In programma', '', '', 'Programado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (859, 'campaign', 'Campaign', 'Campagne', 'Campagna', '', '', 'Campaña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (860, 'campaign_name', 'Campaign Name', 'Nom de la campagne', 'Nome della campagna', '', '', 'Nombre de campaña');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (861, 'sms_gateway', 'Sms Gateway', 'Passerelle SMS', 'Sms Gateway', '', '', 'Sms Gateway');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (862, 'recipients_type', 'Recipients Type', 'Type de destinataires', 'Tipo di destinatario', '', '', 'Tipo de destinatarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (863, 'recipients_count', 'Recipients Count', 'Nombre de destinataires', 'Conteggio dei destinatari', '', '', 'Recuento de destinatarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (864, 'body', 'Body', 'Corps', 'Corpo', '', '', 'Cuerpo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (865, 'guardian_already_exist', 'Guardian Already Exist', 'Guardian existe déjà', 'Il guardiano esiste già', '', '', 'Guardian ya existe');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (866, 'guardian', 'Guardian', 'Gardien', 'Custode', '', '', 'guardián');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (867, 'mother_name', 'Mother Name', 'Nom de la mère', 'Nome della madre', '', '', 'Nombre de la madre');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (868, 'bank_details', 'Bank Details', 'coordonnées bancaires', 'coordinate bancarie', 'Detalhes bancários', 'Bankdaten', 'Detalles del banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (869, 'skipped_bank_details', 'Skipped Bank Details', 'Détails bancaires ignorés', 'Dettagli bancari saltati', 'Detalhes bancários ignorados', 'Übersprungene Bankdaten', 'Detalles bancarios omitidos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (870, 'bank', 'Bank', 'Banque', 'Banca', '', '', 'Banco');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (871, 'holder_name', 'Holder Name', 'Nom du titulaire', 'Nome del titolare', '', '', 'Nombre del titular');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (872, 'bank_branch', 'Bank Branch', 'Agence bancaire', 'Filiale bancaria', '', '', 'Sucursal bancaria');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (873, 'custom_field_for', 'Custom Field For', 'Champ personnalisé pour', 'Campo personalizzato per', '', '', 'Campo personalizado para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (874, 'label', 'Label', 'Label', 'Etichetta', '', '', 'Etiqueta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (875, 'order', 'Order', 'Ordre', 'Ordine', '', '', 'Orden');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (876, 'online_admission', 'Online Admission', 'Online Admission', 'Ammissione online', '', '', 'Admisión en línea');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (877, 'field_label', 'Field Label', 'Étiquette de champ', 'Etichetta sul campo', '', '', 'Etiqueta de campo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (878, 'field_type', 'Field Label', 'Étiquette de champ', 'Etichetta sul campo', '', '', 'Etiqueta de campo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (879, 'default_value', 'Default Value', 'Valeur par défaut', 'Valore predefinito', '', '', 'Valor por defecto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (880, 'checked', 'Checked', 'Vérifié', 'verificato', '', '', 'Comprobado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (881, 'unchecked', 'Unchecked', 'Décoché', 'non verificato', '', '', 'Desenfrenado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (882, 'roll_number', 'Roll Number', 'Numéro de rôle', 'Numero del rullino', '', '', 'Número de rollo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (883, 'add_rows', 'Add Rows', 'Ajouter des lignes', 'Aggiungi righe', '', '', 'Agregar filas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (884, 'salary', 'Salary', 'Un salaire', 'Stipendio', '', '', 'Salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (885, 'basic', 'Basic', 'De base', 'Di base', '', '', 'Básico');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (886, 'allowance', 'Allowance', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (887, 'deduction', 'Deduction', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (888, 'net', 'Net', 'Net', 'Netto', '', '', 'Red');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (889, 'activated_sms_gateway', 'Activated Sms Gateway', 'Passerelle Sms activée', 'Gateway SMS attivato', '', '', 'Gateway SMS activado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (890, 'account_sid', 'Account Sid', 'Compte Sid', 'Conto Sid', '', '', 'Cuenta Sid');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (891, 'roles', 'Roles', 'Les rôles', 'ruoli', '', '', 'Roles');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (892, 'system_role', 'System Role', 'Rôle système', 'Ruolo di sistema', '', '', 'Rol del sistema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (893, 'permission', 'Permission', 'Permission', 'Autorizzazione', '', '', 'Permiso');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (894, 'edit_session', 'Edit Session', 'Edit Session', 'Modifica sessione', '', '', 'Editar sesión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (895, 'transactions', 'Transactions', 'Transactions', 'Le transazioni', '', '', 'Actas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (896, 'default_account', 'Default Account', 'Compte par défaut', 'Account predefinito', '', '', 'Cuenta predeterminada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (897, 'deposit', 'Deposit', 'Dépôt', 'Depositare', '', '', 'Depositar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (898, 'acccount', 'Acccount', 'Compte', 'acccount', '', '', 'Cuenta');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (899, 'role_permission_for', 'Role Permission For', 'Autorisation de rôle pour', 'Autorizzazione al ruolo per', '', '', 'Permiso de rol para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (900, 'feature', 'Feature', 'Fonctionnalité', 'caratteristica', '', '', 'Característica');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (901, 'access_denied', 'Access Denied', 'Accès refusé', 'Accesso negato', '', 'Zugriff abgelehnt', 'Acceso denegado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (902, 'time_start', 'Time Start', 'Heure de début', 'Time Start', '', 'Mal starten', 'Hora de inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (903, 'time_end', 'Time End', 'Fin de temps', 'Time End', '', 'Zeitende', 'Fin del tiempo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (904, 'month_of_salary', 'Month Of Salary', 'Mois de salaire', 'Mese Di Stipendio', '', 'Monat des Gehalts', 'Mes de salario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (905, 'add_documents', 'Add Documents', 'Ajouter des documents', 'Aggiungi documenti', '', 'Dokumente hinzufügen', 'Agregar documentos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (906, 'document_type', 'Document Type', 'Document Type', 'tipo di documento', '', 'Dokumententyp', 'Tipo de Documento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (907, 'document', 'Document', 'Document', 'Documento', '', 'Dokumentieren', 'Documento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (908, 'document_title', 'Document Title', 'Titre du document', 'Titolo del documento', '', 'Dokumenttitel', 'Titulo del documento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (909, 'document_category', 'Document Category', 'Catégorie de document', 'Categoria del documento', '', 'Dokumentkategorie', 'Categoría de documento');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (910, 'exam_result', 'Exam Result', 'Résultat d\'éxamen', 'Risultato dell\'esame', '', 'Prüfungsergebnis', 'Resultado del examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (911, 'my_annual_fee_summary', 'My Annual Fee Summary', 'Mon résumé des frais annuels', 'Riepilogo commissioni annuali', '', 'Meine jährliche Gebührenübersicht', 'Mi resumen anual de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (912, 'book_manage', 'Book Manage', 'Book Manage', 'Prenota Gestisci', '', 'Buch verwalten', 'Administrar libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (913, 'add_leave_category', 'Add Leave Category', 'Ajouter une catégorie de congé', 'Aggiungi categoria di abbandono', '', 'Urlaubskategorie hinzufügen', 'Agregar categoría de licencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (914, 'edit_leave_category', 'Edit Leave Category', 'Modifier la catégorie de congé', 'Modifica lascia categoria', '', '', 'Editar dejar la categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (915, 'staff_role', 'Staff Role', 'Rôle du personnel', 'Ruolo del personale', '', '', 'Rol del personal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (916, 'edit_assign', 'Edit Assign', 'Modifier l\'attribution', 'Modifica assegnazione', '', '', 'Editar asignación');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (917, 'view_report', 'View Report', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (918, 'rank_out_of_5', 'Rank Out Of 5', 'Classement sur 5', 'Rango fuori da 5', '', '', 'Rango fuera de 5');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (919, 'hall_no', 'Hall No', 'Salle No', 'Sala n', '', '', 'Hall No');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (920, 'no_of_seats', 'No Of Seats', 'Pas de sièges', 'No Di Posti', '', '', 'No de asientos');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (921, 'mark_distribution', 'Mark Distribution', 'Mark Distribution', 'Mark Distribution', '', '', 'Mark Distribution');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (922, 'exam_type', 'Exam Type', 'Type d\'examen', 'Tipo di esame', '', 'Prüfungstyp', 'Tipo de examen');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (923, 'marks_and_grade', 'Marks And Grade', 'Marques et grade', 'Segni e grado', '', 'Noten und Note', 'Marcas y grado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (924, 'min_percentage', 'Min Percentage', 'Pourcentage minimal', 'Percentuale minima', '', 'Min. Prozentsatz', 'Porcentaje min.');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (925, 'max_percentage', 'Max Percentage', 'Pourcentage max', 'Percentuale massima', '', '', 'Porcentaje Máx.');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (926, 'cost_per_bed', 'Cost Per Bed', 'Coût par lit', 'Costo per letto', 'Custo por cama', 'Kosten pro Bett', 'Costo por cama');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (927, 'add_category', 'Add Category', 'ajouter une catégorie', 'Aggiungi categoria', 'Adicionar categoria', 'Kategorie hinzufügen', 'añadir categoría');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (928, 'category_for', 'Category For', 'Catégorie Pour', 'Categoria per', 'Categoria para', 'Kategorie für', 'Categoría para');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (929, 'start_place', 'Start Place', 'Start Place', 'Inizia il posto', 'Start Place', 'Startplatz', 'Lugar de inicio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (930, 'stop_place', 'Stop Place', 'Stop Place', 'Stop Place', 'Stop Place', 'Stop Place', 'Lugar de parada');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (931, 'vehicle', 'Vehicle', 'Véhicule', 'Veicolo', 'Veículo', 'Fahrzeug', 'Vehículo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (932, 'select_multiple_vehicle', 'Select Multiple Vehicle', 'Sélectionnez plusieurs véhicules', 'Seleziona Veicolo multiplo', 'Selecionar veículo múltiplo', 'Wählen Sie Mehrere Fahrzeuge', 'Seleccionar vehículo múltiple');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (933, 'book_details', 'Book Details', 'Détails du livre', 'Dettagli del libro', 'Detalhes do livro', 'Buchdetails', 'Detalles del libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (934, 'issued_by', 'Issued By', 'Délivré par', 'Rilasciato da', 'Publicado por', 'Ausgestellt durch', 'Emitido por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (935, 'return_by', 'Return By', 'Retour par', 'Ritorna entro', 'Retorno por', 'Zurück durch', 'Volver por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (936, 'group', 'Group', 'Groupe', 'Gruppo', 'Grupo', 'Gruppe', 'Grupo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (937, 'individual', 'Individual', 'Individuel', 'Individuale', 'Individual', 'Individuell', 'Individual');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (938, 'recipients', 'Recipients', 'Destinataires', 'destinatari', 'Destinatários', 'Empfänger', 'Destinatarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (939, 'group_name', 'Group Name', 'Nom de groupe', 'Nome del gruppo', 'Nome do grupo', 'Gruppenname', 'Nombre del grupo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (940, 'fee_code', 'Fee Code', 'Fee Code', 'Codice tariffa', 'Código da taxa', 'Gebührencode', 'Código de tarifa');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (941, 'fine_type', 'Fine Type', 'Type fin', 'Tipo fine', 'Tipo Fino', 'Feiner Typ', 'Tipo fino');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (942, 'fine_value', 'Fine Value', 'Fine Value', 'Ottimo valore', 'Valor Fino', 'Feiner Wert', 'Valor fino');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (943, 'late_fee_frequency', 'Late Fee Frequency', 'Fréquence des frais de retard', 'Frequenza delle commissioni in ritardo', 'Frequência de taxas atrasadas', 'Späte Gebührenhäufigkeit', 'Frecuencia de pago tardío');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (944, 'fixed_amount', 'Fixed Amount', 'Montant fixé', 'Importo fisso', 'Quantia fixa', 'Fester Betrag', 'Cantidad fija');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (945, 'fixed', 'Fixed', 'Fixé', 'Fisso', 'Fixo', 'Fest', 'Fijo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (946, 'daily', 'Daily', 'du quotidien', 'Quotidiano', 'Diariamente', 'Täglich', 'Diario');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (947, 'weekly', 'Weekly', 'Hebdomadaire', 'settimanalmente', 'Semanal', 'Wöchentlich', 'Semanal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (948, 'monthly', 'Monthly', 'Mensuel', 'Mensile', 'Por mês', 'Monatlich', 'Mensual');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (949, 'annually', 'Annually', 'Annuellement', 'Annualmente', 'Anualmente', 'Jährlich', 'Anualmente');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (950, 'first_select_the_group', 'First Select The Group', 'Sélectionnez d\'abord le groupe', 'Prima seleziona il gruppo', 'Primeiro selecione o grupo', 'Wählen Sie zuerst die Gruppe aus', 'Primero seleccione el grupo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (951, 'percentage', 'Percentage', '', '', '', 'Prozentsatz', 'Porcentaje');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (952, 'value', 'Value', 'Valeur', 'Valore', 'Valor', 'Wert', 'Valor');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (953, 'fee_group', 'Fee Group', 'Groupe de frais', 'Gruppo di commissioni', 'Grupo de taxas', 'Gebührengruppe', 'Grupo de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (954, 'due_invoice', 'Due Invoice', 'Facture due', 'Fattura dovuta', 'Fatura vencida', 'Fällige Rechnung', 'Factura vencida');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (955, 'reminder', 'Reminder', 'Rappel', 'Promemoria', 'Lembrete', 'Erinnerung', 'Recordatorio');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (956, 'frequency', 'Frequency', 'La fréquence', 'Frequenza', 'Frequência', 'Frequenz', 'Frecuencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (957, 'notify', 'Notify', 'Notifier', 'Notificare', 'Notificar', 'Benachrichtigen', 'Notificar');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (958, 'before', 'Before', 'Avant', 'Prima', 'Antes', 'Vor', 'antes de');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (959, 'after', 'After', 'Après', 'Dopo', 'Depois de', 'Nach', 'Después');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (960, 'number', 'Number', 'Nombre', 'Numero', 'Número', 'Nummer', 'Número');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (961, 'ref_no', 'Ref No', 'Réf No', 'Ref no', 'Nº de referência', 'Referenznummer', 'Número de referencia');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (962, 'pay_via', 'Pay Via', 'Payez via', 'Pay Via', 'Pay Via', 'Zahlen Sie über', 'Pagar vía');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (963, 'ref', 'Ref', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (964, 'dr', 'Dr', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (965, 'cr', 'Cr', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (966, 'edit_book', 'Edit Book', 'Modifier le livre', 'Modifica libro', 'Editar livro', 'Buch bearbeiten', 'Editar libro');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (967, 'leaves', 'Leaves', 'Feuilles', 'Le foglie', 'Folhas', 'Blätter', 'Hojas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (968, 'leave_request', 'Leave Request', 'Demande de congé', 'Lascia una richiesta', 'Deixar pedido', 'Anfrage hinterlassen', 'Dejar petición');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (969, 'this_file_type_is_not_allowed', 'This File Type Is Not Allowed', 'Ce type de fichier n\'est pas autorisé', 'Questo tipo di file non è consentito', 'Este tipo de arquivo não é permitido', 'Dieser Dateityp ist nicht zulässig', 'Este tipo de archivo no está permitido');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (970, 'error_reading_the_file', 'Error Reading The File', 'Erreur de lecture du fichier', 'Errore durante la lettura del file', 'Erro ao ler o arquivo', 'Fehler beim Lesen der Datei', 'Error al leer el archivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (971, 'staff', 'Staff', 'Personnel', 'Personale', 'Funcionários', 'Mitarbeiter', 'Personal');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (972, 'waiting', 'Waiting', 'Attendre', 'In attesa', 'Esperando', 'Warten', 'Esperando');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (973, 'live', 'Live', 'Vivre', 'Vivere', 'Viver', 'Leben', 'En Vivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (974, 'by', 'By', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (975, 'host_live_class', 'Host Live Class', 'Host Live Class', 'Ospita classe dal vivo', 'Host Live Class', 'Host Live Class', 'Host Live Class');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (976, 'join_live_class', 'Join Live Class', 'Rejoignez Live Class', 'Unisciti alla Live Class', 'Participar de aulas ao vivo', 'Treten Sie der Live-Klasse bei', 'Únete a la clase en vivo');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (977, 'system_logo', 'System Logo', 'Logo du système', 'Logo di sistema', 'System Logo', 'Systemlogo', 'Logotipo del sistema');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (978, 'text_logo', 'Text Logo', 'Logo texte', 'Logo di testo', 'Text Logo', 'Text Logo', 'Logo de texto');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (979, 'printing_logo', 'Printing Logo', 'Printing Logo', 'Stampa del logo', 'Printing Logo', 'Logo drucken', 'Logo de impresión');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (980, 'expired', 'Expired', 'Expiré', 'Scaduto', 'Expirado', 'Abgelaufen', 'Caducado');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (981, 'collect_fees', 'Collect Fees', 'Percevoir les frais', 'Raccogliere commissioni', 'Cobrar taxas', 'Gebühren sammeln', 'Cobrar tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (982, 'fees_code', 'Fees Code', 'Code des frais', 'Codice delle tasse', 'Código das taxas', 'Gebührencode', 'Código de tarifas');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (983, 'collect_by', 'Collect By', 'Collecter par', 'Colleziona da', 'Coletar por', 'Sammeln von', 'Recoger por');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (984, 'fee_payment', 'Fee Payment', 'Paiement des frais', 'Pagamento delle commissioni', 'Pagamento da taxa', 'Gebührenzahlung', 'Pago de honorarios');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (985, 'write_message', 'Write Message', 'Écrire un message', 'Scrivi un messaggio', 'Escrever mensagem', 'Nachricht schreiben', 'Escribe un mensaje');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (986, 'discard', 'Discard', 'Jeter', 'Scartare', 'Descartar', 'Verwerfen', 'Descarte');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (987, 'message_sent_successfully', 'Message Sent Successfully', 'Message envoyé avec succès', 'Messaggio inviato con successo', 'Mensagem enviada com sucesso', 'Nachricht erfolgreich gesendet', 'Mensaje enviado con éxito');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (988, 'visit_home_page', 'Visit Home Page', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (989, 'frontend', 'Frontend', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (990, 'setting', 'Setting', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (991, 'menu', 'Menu', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (992, 'page', 'Page', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (993, 'manage', 'Manage', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (994, 'slider', 'Slider', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (995, 'features', 'Features', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (996, 'testimonial', 'Testimonial', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (997, 'service', 'Service', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (998, 'faq', 'Faq', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (999, 'card_management', 'Card Management', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1000, 'id_card', 'Id Card', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1001, 'templete', 'Templete', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1002, 'admit_card', 'Admit Card', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1003, 'certificate', 'Certificate', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1004, 'system_update', 'System Update', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1005, 'url', 'Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1006, 'content', 'Content', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1007, 'banner_photo', 'Banner Photo', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1008, 'meta', 'Meta', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1009, 'keyword', 'Keyword', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1010, 'applicable_user', 'Applicable User', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1011, 'page_layout', 'Page Layout', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1012, 'background', 'Background', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1013, 'image', 'Image', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1014, 'width', 'Width', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1015, 'height', 'Height', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1016, 'signature', 'Signature', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1017, 'website', 'Website', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1018, 'cms', 'Cms', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1019, 'url_alias', 'Url Alias', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1020, 'cms_frontend', 'Cms Frontend', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1021, 'enabled', 'Enabled', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1022, 'receive_email_to', 'Receive Email To', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1023, 'captcha_status', 'Captcha Status', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1024, 'recaptcha_site_key', 'Recaptcha Site Key', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1025, 'recaptcha_secret_key', 'Recaptcha Secret Key', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1026, 'working_hours', 'Working Hours', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1027, 'fav_icon', 'Fav Icon', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1028, 'theme', 'Theme', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1029, 'fax', 'Fax', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1030, 'footer_about_text', 'Footer About Text', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1031, 'copyright_text', 'Copyright Text', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1032, 'facebook_url', 'Facebook Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1033, 'twitter_url', 'Twitter Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1034, 'youtube_url', 'Youtube Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1035, 'google_plus', 'Google Plus', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1036, 'linkedin_url', 'Linkedin Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1037, 'pinterest_url', 'Pinterest Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1038, 'instagram_url', 'Instagram Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1039, 'play', 'Play', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1040, 'video', 'Video', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1041, 'usename', 'Usename', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1042, 'experience_details', 'Experience Details', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1043, 'total_experience', 'Total Experience', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1044, 'class_schedule', 'Class Schedule', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1045, 'cms_default_branch', 'Cms Default Branch', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1046, 'website_page', 'Website Page', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1047, 'welcome', 'Welcome', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1048, 'services', 'Services', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1049, 'call_to_action_section', 'Call To Action Section', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1050, 'subtitle', 'Subtitle', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1051, 'cta', 'Cta', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1052, 'button_text', 'Button Text', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1053, 'button_url', 'Button Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1054, '_title', ' Title', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1055, 'contact', 'Contact', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1056, 'box_title', 'Box Title', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1057, 'box_description', 'Box Description', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1058, 'box_photo', 'Box Photo', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1059, 'form_title', 'Form Title', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1060, 'submit_button_text', 'Submit Button Text', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1061, 'map_iframe', 'Map Iframe', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1062, 'email_subject', 'Email Subject', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1063, 'prefix', 'Prefix', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1064, 'surname', 'Surname', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1065, 'rank', 'Rank', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1066, 'submit', 'Submit', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1067, 'certificate_name', 'Certificate Name', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1068, 'layout_width', 'Layout Width', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1069, 'layout_height', 'Layout Height', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1070, 'expiry_date', 'Expiry Date', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1071, 'position', 'Position', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1072, 'target_new_window', 'Target New Window', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1073, 'external_url', 'External Url', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1074, 'external_link', 'External Link', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1075, 'sms_notification', 'Sms Notification', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1076, 'scheduled_at', 'Scheduled At', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1077, 'published', 'Published', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1078, 'unpublished_on_website', 'Unpublished On Website', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1079, 'published_on_website', 'Published On Website', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1080, 'no_selection_available', 'No Selection Available', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1081, 'select_for_everyone', 'Select For Everyone', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1082, 'teacher_restricted', 'Teacher Restricted', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1083, 'guardian_relation', 'Guardian Relation', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1084, 'username_prefix', 'Username Prefix', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1085, 'default_password', 'Default Password', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1086, 'parents_profile', 'Parents Profile', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1087, 'childs', 'Childs', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1088, 'page_title', 'Page Title', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1089, 'select_menu', 'Select Menu', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1090, 'meta_keyword', 'Meta Keyword', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1091, 'meta_description', 'Meta Description', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1092, 'evaluation_date', 'Evaluation Date', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1093, 'evaluated_by', 'Evaluated By', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1094, 'complete', 'Complete', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1095, 'incomplete', 'Incomplete', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1096, 'payment_details', 'Payment Details', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1097, 'edit_attachments', 'Edit Attachments', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1098, 'live_classes', 'Live Classes', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1099, 'duration', 'Duration', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1100, 'metting_id', 'Metting Id', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1101, 'set_record', 'Set Record', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1102, 'set_mute_on_start', 'Set Mute On Start', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1103, 'button_text_1', 'Button Text 1', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1104, 'button_url_1', 'Button Url 1', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1105, 'button_text_2', 'Button Text 2', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1106, 'button_url_2', 'Button Url 2', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1107, 'left', 'Left', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1108, 'center', 'Center', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1109, 'right', 'Right', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1110, 'about', 'About', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1111, 'about_photo', 'About Photo', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1112, 'parallax_photo', 'Parallax Photo', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1113, 'decline', 'Decline', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1114, 'edit_grade', 'Edit Grade', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1115, 'mark', 'Mark', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1116, 'hall_room', 'Hall Room', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1117, 'student_promotion', 'Student Promotion', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1118, 'username_has_already_been_used', 'Username Has Already Been Used', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1119, 'fee_collection', 'Fee Collection', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1120, 'not_found_anything', 'Not Found Anything', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1121, 'preloader_backend', 'Preloader Backend', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1122, 'ive_class_method', 'Ive Class Method', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1123, 'live_class_method', 'Live Class Method', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1124, 'api_credential', 'Api Credential', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1125, 'translation_update', 'Translation Update', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1126, ' live_class_reports', ' Live Class Reports', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1127, 'live_class_reports', 'Live Class Reports', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1128, 'all', 'All', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1129, 'student_participation_report', 'Student Participation Report', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1130, 'joining_time', 'Joining Time', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1131, 'gallery', 'Gallery', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1132, 'reception', 'Reception', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1133, 'admission_enquiry', 'Admission Enquiry', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1134, 'postal_record', 'Postal Record', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1135, 'call_log', 'Call Log', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1136, 'visitor_log', 'Visitor Log', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1137, 'complaint', 'Complaint', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1138, 'online_exam', 'Online Exam', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1139, 'question_bank', 'Question Bank', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1140, 'question_group', 'Question Group', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1141, 'progress', 'Progress', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1142, 'system_student_field', 'System Student Field', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1143, 'february', 'February', '', '', '', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `french`, `italian`, `portuguese`, `german`, `spanish`) VALUES (1144, 'today_birthday', 'Today Birthday', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: leave_application
#

DROP TABLE IF EXISTS `leave_application`;

CREATE TABLE `leave_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `category_id` int(2) NOT NULL,
  `reason` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_days` varchar(20) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT 1 COMMENT '1=pending,2=accepted 3=rejected',
  `apply_date` date DEFAULT NULL,
  `approved_by` int(11) NOT NULL,
  `orig_file_name` varchar(255) NOT NULL,
  `enc_file_name` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: leave_category
#

DROP TABLE IF EXISTS `leave_category`;

CREATE TABLE `leave_category` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `days` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: live_class
#

DROP TABLE IF EXISTS `live_class`;

CREATE TABLE `live_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_method` tinyint(1) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `meeting_id` varchar(255) NOT NULL,
  `meeting_password` varchar(255) NOT NULL,
  `own_api_key` tinyint(1) NOT NULL DEFAULT 0,
  `duration` int(11) NOT NULL,
  `bbb` longtext NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` text NOT NULL,
  `remarks` text NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: live_class_config
#

DROP TABLE IF EXISTS `live_class_config`;

CREATE TABLE `live_class_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zoom_api_key` varchar(255) DEFAULT NULL,
  `zoom_api_secret` varchar(255) DEFAULT NULL,
  `bbb_salt_key` varchar(355) DEFAULT NULL,
  `bbb_server_base_url` varchar(355) DEFAULT NULL,
  `staff_api_credential` tinyint(1) NOT NULL DEFAULT 0,
  `student_api_credential` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: live_class_reports
#

DROP TABLE IF EXISTS `live_class_reports`;

CREATE TABLE `live_class_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(2) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'admin@gmail.com', '$2y$10$63jhvhPnxy9kKemy4fUq5eMgiKS7DAoIsuamdHcockaJaJhrJeSOG', 1, 1, '2023-02-11 22:29:15', '2023-02-11 22:27:32', NULL);


#
# TABLE STRUCTURE FOR: mark
#

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `mark` text DEFAULT NULL,
  `absent` varchar(4) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: message
#

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `subject` varchar(255) NOT NULL,
  `file_name` text DEFAULT NULL,
  `enc_name` text DEFAULT NULL,
  `trash_sent` tinyint(1) NOT NULL,
  `trash_inbox` int(11) NOT NULL,
  `fav_inbox` tinyint(1) NOT NULL,
  `fav_sent` tinyint(1) NOT NULL,
  `reciever` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 unread 1 read',
  `reply_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 unread 1 read',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: message_reply
#

DROP TABLE IF EXISTS `message_reply`;

CREATE TABLE `message_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `file_name` text NOT NULL,
  `enc_name` text NOT NULL,
  `identity` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `migrations` (`version`) VALUES ('530');


#
# TABLE STRUCTURE FOR: online_admission
#

DROP TABLE IF EXISTS `online_admission`;

CREATE TABLE `online_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` varchar(25) DEFAULT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `blood_group` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `present_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `admission_date` varchar(100) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `student_photo` varchar(255) DEFAULT NULL,
  `category_id` varchar(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `previous_school_details` text DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `guardian_relation` varchar(50) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `grd_occupation` varchar(255) DEFAULT NULL,
  `grd_income` varchar(25) DEFAULT NULL,
  `grd_education` varchar(255) DEFAULT NULL,
  `grd_email` varchar(255) DEFAULT NULL,
  `grd_mobile_no` varchar(50) DEFAULT NULL,
  `grd_address` text DEFAULT NULL,
  `grd_city` varchar(255) DEFAULT NULL,
  `grd_state` varchar(255) DEFAULT NULL,
  `grd_photo` varchar(255) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT 1,
  `payment_status` tinyint(1) NOT NULL DEFAULT 0,
  `payment_amount` decimal(18,2) NOT NULL,
  `payment_details` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` varchar(11) DEFAULT NULL,
  `apply_date` datetime NOT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_admission_fields
#

DROP TABLE IF EXISTS `online_admission_fields`;

CREATE TABLE `online_admission_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `system` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam
#

DROP TABLE IF EXISTS `online_exam`;

CREATE TABLE `online_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` text NOT NULL,
  `subject_id` text NOT NULL,
  `limits_participation` int(11) NOT NULL,
  `exam_start` datetime DEFAULT NULL,
  `exam_end` datetime DEFAULT NULL,
  `duration` time NOT NULL,
  `mark_type` tinyint(1) NOT NULL DEFAULT 1,
  `passing_mark` float NOT NULL DEFAULT 0,
  `instruction` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `publish_result` tinyint(1) NOT NULL DEFAULT 0,
  `marks_display` tinyint(1) NOT NULL DEFAULT 1,
  `neg_mark` tinyint(1) NOT NULL DEFAULT 0,
  `question_type` tinyint(1) NOT NULL DEFAULT 0,
  `publish_status` tinyint(1) NOT NULL DEFAULT 0,
  `exam_type` tinyint(1) NOT NULL DEFAULT 0,
  `fee` float NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `position_generated` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_answer
#

DROP TABLE IF EXISTS `online_exam_answer`;

CREATE TABLE `online_exam_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_attempts
#

DROP TABLE IF EXISTS `online_exam_attempts`;

CREATE TABLE `online_exam_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `count` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_payment
#

DROP TABLE IF EXISTS `online_exam_payment`;

CREATE TABLE `online_exam_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `payment_method` tinyint(4) NOT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `transaction_id` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_submitted
#

DROP TABLE IF EXISTS `online_exam_submitted`;

CREATE TABLE `online_exam_submitted` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `remark` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: parent
#

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `relation` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` varchar(100) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobileno` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `active` tinyint(2) NOT NULL DEFAULT 0 COMMENT '0(active) 1(deactivate)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payment_config
#

DROP TABLE IF EXISTS `payment_config`;

CREATE TABLE `payment_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paypal_username` varchar(255) DEFAULT NULL,
  `paypal_password` varchar(255) DEFAULT NULL,
  `paypal_signature` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_sandbox` tinyint(4) DEFAULT NULL,
  `paypal_status` tinyint(4) DEFAULT NULL,
  `stripe_secret` varchar(255) DEFAULT NULL,
  `stripe_publishiable` varchar(255) NOT NULL,
  `stripe_demo` varchar(255) DEFAULT NULL,
  `stripe_status` tinyint(4) DEFAULT NULL,
  `payumoney_key` varchar(255) DEFAULT NULL,
  `payumoney_salt` varchar(255) DEFAULT NULL,
  `payumoney_demo` tinyint(4) DEFAULT NULL,
  `payumoney_status` tinyint(4) DEFAULT NULL,
  `paystack_secret_key` varchar(255) NOT NULL,
  `paystack_status` tinyint(4) NOT NULL,
  `razorpay_key_id` varchar(255) NOT NULL,
  `razorpay_key_secret` varchar(255) NOT NULL,
  `razorpay_demo` tinyint(4) NOT NULL,
  `razorpay_status` tinyint(4) NOT NULL,
  `sslcz_store_id` varchar(255) NOT NULL,
  `sslcz_store_passwd` varchar(255) NOT NULL,
  `sslcommerz_sandbox` tinyint(1) NOT NULL,
  `sslcommerz_status` tinyint(1) NOT NULL,
  `jazzcash_merchant_id` varchar(255) NOT NULL,
  `jazzcash_passwd` varchar(255) NOT NULL,
  `jazzcash_integerity_salt` varchar(255) NOT NULL,
  `jazzcash_sandbox` tinyint(1) NOT NULL,
  `jazzcash_status` tinyint(1) NOT NULL,
  `midtrans_client_key` varchar(255) NOT NULL,
  `midtrans_server_key` varchar(255) NOT NULL,
  `midtrans_sandbox` tinyint(1) NOT NULL,
  `midtrans_status` tinyint(1) NOT NULL,
  `flutterwave_public_key` varchar(255) DEFAULT NULL,
  `flutterwave_secret_key` varchar(255) DEFAULT NULL,
  `flutterwave_sandbox` tinyint(4) NOT NULL DEFAULT 0,
  `flutterwave_status` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payment_salary_stipend
#

DROP TABLE IF EXISTS `payment_salary_stipend`;

CREATE TABLE `payment_salary_stipend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payment_types
#

DROP TABLE IF EXISTS `payment_types`;

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (1, 'Cash', 0, '2019-07-27 18:12:21');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (2, 'Card', 0, '2019-07-27 18:12:31');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (3, 'Cheque', 0, '2019-12-21 10:07:59');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (4, 'Bank Transfer', 0, '2019-12-21 10:08:36');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (5, 'Other', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (6, 'Paypal', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (7, 'Stripe', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (8, 'PayUmoney', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (9, 'Paystack', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (10, 'Razorpay', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (11, 'SSLcommerz', 0, '2021-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (12, 'Jazzcash', 0, '2021-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (13, 'Midtrans', 0, '2021-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (14, 'Flutter Wave', 0, '2022-05-15 10:08:45');


#
# TABLE STRUCTURE FOR: payslip
#

DROP TABLE IF EXISTS `payslip`;

CREATE TABLE `payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` varchar(200) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `total_allowance` decimal(18,2) NOT NULL,
  `total_deduction` decimal(18,2) NOT NULL,
  `net_salary` decimal(18,2) NOT NULL,
  `bill_no` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `pay_via` tinyint(1) NOT NULL,
  `hash` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_by` varchar(200) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payslip_details
#

DROP TABLE IF EXISTS `payslip_details`;

CREATE TABLE `payslip_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(1) DEFAULT 1,
  `show_add` tinyint(1) DEFAULT 1,
  `show_edit` tinyint(1) DEFAULT 1,
  `show_delete` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Student', 'student', 1, 1, 1, 1, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Multiple Import', 'multiple_import', 0, 1, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 2, 'Student Category', 'student_category', 1, 1, 1, 1, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 2, 'Student Id Card', 'student_id_card', 1, 0, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 2, 'Disable Authentication', 'student_disable_authentication', 1, 1, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 4, 'Employee', 'employee', 1, 1, 1, 1, '2020-01-22 06:55:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (7, 3, 'Parent', 'parent', 1, 1, 1, 1, '2020-01-22 08:24:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (8, 3, 'Disable Authentication', 'parent_disable_authentication', 1, 1, 0, 0, '2020-01-22 09:22:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 4, 'Department', 'department', 1, 1, 1, 1, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 4, 'Designation', 'designation', 1, 1, 1, 1, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 4, 'Disable Authentication', 'employee_disable_authentication', 1, 1, 0, 0, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 5, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2020-01-23 00:13:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 5, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2020-01-23 00:14:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 5, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2020-01-24 01:45:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 5, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2020-03-14 13:09:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 5, 'Advance Salary', 'advance_salary', 1, 1, 1, 1, '2020-01-28 13:23:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 5, 'Advance Salary Manage', 'advance_salary_manage', 1, 1, 1, 1, '2020-01-24 23:57:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 5, 'Advance Salary Request', 'advance_salary_request', 1, 1, 0, 1, '2020-01-28 12:49:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 5, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2020-01-28 21:46:23');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 5, 'Leave Request', 'leave_request', 1, 1, 1, 1, '2020-01-30 07:06:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 5, 'Leave Manage', 'leave_manage', 1, 1, 1, 1, '2020-01-29 02:27:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 5, 'Award', 'award', 1, 1, 1, 1, '2020-01-31 13:49:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 6, 'Classes', 'classes', 1, 1, 1, 1, '2020-02-01 13:10:00');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 6, 'Section', 'section', 1, 1, 1, 1, '2020-02-01 16:06:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 6, 'Assign Class Teacher', 'assign_class_teacher', 1, 1, 1, 1, '2020-02-02 02:09:22');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 6, 'Subject', 'subject', 1, 1, 1, 1, '2020-02-02 23:32:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 6, 'Subject Class Assign ', 'subject_class_assign', 1, 1, 1, 1, '2020-02-03 12:43:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 6, 'Subject Teacher Assign', 'subject_teacher_assign', 1, 1, 0, 1, '2020-02-03 14:05:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 6, 'Class Timetable', 'class_timetable', 1, 1, 1, 1, '2020-02-04 00:50:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 2, 'Student Promotion', 'student_promotion', 1, 1, 0, 0, '2020-02-05 13:20:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 8, 'Attachments', 'attachments', 1, 1, 1, 1, '2020-02-06 12:59:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (32, 7, 'Homework', 'homework', 1, 1, 1, 1, '2020-02-07 00:40:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 8, 'Attachment Type', 'attachment_type', 1, 1, 1, 1, '2020-02-07 02:16:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (34, 9, 'Exam', 'exam', 1, 1, 1, 1, '2020-02-07 04:59:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (35, 9, 'Exam Term', 'exam_term', 1, 1, 1, 1, '2020-02-07 07:09:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (36, 9, 'Exam Hall', 'exam_hall', 1, 1, 1, 1, '2020-02-07 09:31:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (37, 9, 'Exam Timetable', 'exam_timetable', 1, 1, 0, 1, '2020-02-08 12:04:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (38, 9, 'Exam Mark', 'exam_mark', 1, 1, 1, 1, '2020-02-10 07:53:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (39, 9, 'Exam Grade', 'exam_grade', 1, 1, 1, 1, '2020-02-10 12:29:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (40, 10, 'Hostel', 'hostel', 1, 1, 1, 1, '2020-02-10 23:41:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (41, 10, 'Hostel Category', 'hostel_category', 1, 1, 1, 1, '2020-02-11 02:52:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (42, 10, 'Hostel Room', 'hostel_room', 1, 1, 1, 1, '2020-02-11 06:50:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (43, 10, 'Hostel Allocation', 'hostel_allocation', 1, 0, 0, 1, '2020-02-11 08:06:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (44, 11, 'Transport Route', 'transport_route', 1, 1, 1, 1, '2020-02-12 00:26:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (45, 11, 'Transport Vehicle', 'transport_vehicle', 1, 1, 1, 1, '2020-02-12 00:57:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (46, 11, 'Transport Stoppage', 'transport_stoppage', 1, 1, 1, 1, '2020-02-12 01:49:20');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (47, 11, 'Transport Assign', 'transport_assign', 1, 1, 1, 1, '2020-02-12 04:55:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (48, 11, 'Transport Allocation', 'transport_allocation', 1, 0, 0, 1, '2020-02-12 14:33:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 12, 'Student Attendance', 'student_attendance', 0, 1, 0, 0, '2020-02-13 00:25:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 12, 'Employee Attendance', 'employee_attendance', 0, 1, 0, 0, '2020-02-13 05:04:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 12, 'Exam Attendance', 'exam_attendance', 0, 1, 0, 0, '2020-02-13 06:08:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 12, 'Student Attendance Report', 'student_attendance_report', 1, 0, 0, 0, '2020-02-13 14:20:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 12, 'Employee Attendance Report', 'employee_attendance_report', 1, 0, 0, 0, '2020-02-14 01:08:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 12, 'Exam Attendance Report', 'exam_attendance_report', 1, 0, 0, 0, '2020-02-14 01:21:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (55, 13, 'Book', 'book', 1, 1, 1, 1, '2020-02-14 01:40:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (56, 13, 'Book Category', 'book_category', 1, 1, 1, 1, '2020-02-14 23:11:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (57, 13, 'Book Manage', 'book_manage', 1, 1, 0, 1, '2020-02-15 06:13:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (58, 13, 'Book Request', 'book_request', 1, 1, 0, 1, '2020-02-17 01:45:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (59, 14, 'Event', 'event', 1, 1, 1, 1, '2020-02-17 13:02:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (60, 14, 'Event Type', 'event_type', 1, 1, 1, 1, '2020-02-17 23:40:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (61, 15, 'Sendsmsmail', 'sendsmsmail', 1, 1, 0, 1, '2020-02-22 02:19:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (62, 15, 'Sendsmsmail Template', 'sendsmsmail_template', 1, 1, 1, 1, '2020-02-22 05:14:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (63, 17, 'Account', 'account', 1, 1, 1, 1, '2020-02-25 04:34:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (64, 17, 'Deposit', 'deposit', 1, 1, 1, 1, '2020-02-25 07:56:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (65, 17, 'Expense', 'expense', 1, 1, 1, 1, '2020-02-26 01:35:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (66, 17, 'All Transactions', 'all_transactions', 1, 0, 0, 0, '2020-02-26 08:35:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (67, 17, 'Voucher Head', 'voucher_head', 1, 1, 1, 1, '2020-02-25 05:50:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (68, 17, 'Accounting Reports', 'accounting_reports', 1, 1, 1, 1, '2020-02-25 08:36:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (69, 16, 'Fees Type', 'fees_type', 1, 1, 1, 1, '2020-02-27 05:11:03');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (70, 16, 'Fees Group', 'fees_group', 1, 1, 1, 1, '2020-02-26 00:49:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (71, 16, 'Fees Fine Setup', 'fees_fine_setup', 1, 1, 1, 1, '2020-03-04 21:59:27');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (72, 16, 'Fees Allocation', 'fees_allocation', 1, 1, 1, 1, '2020-03-01 08:47:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (73, 16, 'Collect Fees', 'collect_fees', 0, 1, 0, 0, '2020-03-15 00:23:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (74, 16, 'Fees Reminder', 'fees_reminder', 1, 1, 1, 1, '2020-03-15 00:29:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (75, 16, 'Due Invoice', 'due_invoice', 1, 0, 0, 0, '2020-03-15 00:33:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (76, 16, 'Invoice', 'invoice', 1, 0, 0, 1, '2020-03-15 00:38:06');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (77, 9, 'Mark Distribution', 'mark_distribution', 1, 1, 1, 1, '2020-03-19 09:02:54');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (78, 9, 'Report Card', 'report_card', 1, 0, 0, 0, '2020-03-20 08:20:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (79, 9, 'Tabulation Sheet', 'tabulation_sheet', 1, 0, 0, 0, '2020-03-21 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (80, 15, 'Sendsmsmail Reports', 'sendsmsmail_reports', 1, 0, 0, 0, '2020-03-21 13:02:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (81, 18, 'Global Settings', 'global_settings', 1, 0, 1, 0, '2020-03-22 01:05:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (82, 18, 'Payment Settings', 'payment_settings', 1, 1, 0, 0, '2020-03-22 01:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (83, 18, 'Sms Settings', 'sms_settings', 1, 1, 1, 1, '2020-03-22 01:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (84, 18, 'Email Settings', 'email_settings', 1, 1, 1, 1, '2020-03-22 01:10:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (85, 18, 'Translations', 'translations', 1, 1, 1, 1, '2020-03-22 01:18:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (86, 18, 'Backup', 'backup', 1, 1, 1, 1, '2020-03-22 03:09:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (87, 18, 'Backup Restore', 'backup_restore', 0, 1, 0, 0, '2020-03-22 03:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (88, 7, 'Homework Evaluate', 'homework_evaluate', 1, 1, 0, 0, '2020-03-28 00:20:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (89, 7, 'Evaluation Report', 'evaluation_report', 1, 0, 0, 0, '2020-03-28 05:56:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (90, 18, 'School Settings', 'school_settings', 1, 0, 1, 0, '2020-03-30 13:36:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (91, 1, 'Monthly Income Vs Expense Pie Chart', 'monthly_income_vs_expense_chart', 1, 0, 0, 0, '2020-03-31 02:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (92, 1, 'Annual Student Fees Summary Chart', 'annual_student_fees_summary_chart', 1, 0, 0, 0, '2020-03-31 02:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (93, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (94, 1, 'Student Count Widget', 'student_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (95, 1, 'Parent Count Widget', 'parent_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (96, 1, 'Teacher Count Widget', 'teacher_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (97, 1, 'Student Quantity Pie Chart', 'student_quantity_pie_chart', 1, 0, 0, 0, '2020-03-31 03:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (98, 1, 'Weekend Attendance Inspection Chart', 'weekend_attendance_inspection_chart', 1, 0, 0, 0, '2020-03-31 03:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (99, 1, 'Admission Count Widget', 'admission_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (100, 1, 'Voucher Count Widget', 'voucher_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (101, 1, 'Transport Count Widget', 'transport_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (102, 1, 'Hostel Count Widget', 'hostel_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (103, 18, 'Accounting Links', 'accounting_links', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (104, 16, 'Fees Reports', 'fees_reports', 1, 0, 0, 0, '2020-04-01 11:52:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (105, 18, 'Cron Job', 'cron_job', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (106, 18, 'Custom Field', 'custom_field', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (107, 5, 'Leave Reports', 'leave_reports', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (108, 18, 'Live Class Config', 'live_class_config', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (109, 19, 'Live Class', 'live_class', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (110, 20, 'Certificate Templete', 'certificate_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (111, 20, 'Generate Student Certificate', 'generate_student_certificate', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (112, 20, 'Generate Employee Certificate', 'generate_employee_certificate', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (113, 21, 'ID Card Templete', 'id_card_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (114, 21, 'Generate Student ID Card', 'generate_student_idcard', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (115, 21, 'Generate Employee ID Card', 'generate_employee_idcard', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (116, 21, 'Admit Card Templete', 'admit_card_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (117, 21, 'Generate Admit card', 'generate_admit_card', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (118, 22, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-10 23:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (119, 22, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 00:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (120, 22, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 00:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (121, 22, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 01:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (122, 22, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 02:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (123, 22, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 02:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (124, 22, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 02:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (125, 22, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 03:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (126, 22, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (127, 2, 'Online Admission', 'online_admission', 1, 1, 0, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (128, 18, 'System Update', 'system_update', 0, 1, 0, 0, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (129, 19, 'Live Class Reports', 'live_class_reports', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (130, 16, 'Fees Revert', 'fees_revert', 0, 0, 0, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (131, 22, 'Frontend Gallery', 'frontend_gallery', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (132, 22, 'Frontend Gallery Category', 'frontend_gallery_category', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (133, 6, 'Teacher Timetable', 'teacher_timetable', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (134, 18, 'Whatsapp Config', 'whatsapp_config', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (135, 18, 'System Student Field', 'system_student_field', 1, 0, 1, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (136, 23, 'Online Exam', 'online_exam', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (137, 23, 'Question Bank', 'question_bank', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (138, 23, 'Add Questions', 'add_questions', 0, 1, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (139, 23, 'Question Group', 'question_group', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (140, 23, 'Exam Result', 'exam_result', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (141, 23, 'Position Generate', 'position_generate', 1, 1, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (142, 24, 'Postal Record', 'postal_record', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (143, 24, 'Call Log', 'call_log', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (144, 24, 'Visitor Log', 'visitor_log', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (145, 24, 'Complaint', 'complaint', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (146, 24, 'Enquiry', 'enquiry', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (147, 24, 'Follow Up', 'follow_up', 1, 1, 0, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (148, 24, 'Config Reception', 'config_reception', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (149, 15, 'Student Birthday Wishes', 'student_birthday_wishes', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (150, 15, 'Staff Birthday Wishes', 'staff_birthday_wishes', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (151, 1, 'Student Birthday Wishes Widget', 'student_birthday_widget', 1, 0, 0, 0, '2021-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (152, 1, 'Staff Birthday Wishes Widget', 'staff_birthday_widget', 1, 0, 0, 0, '2021-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (153, 9, 'Progress Reports', 'progress_reports', 1, 0, 0, 0, '2021-03-21 03:12:38');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (2, 'Student', 'student', 1, 3, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (3, 'Parents', 'parents', 1, 4, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (4, 'Employee', 'employee', 1, 5, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (5, 'Human Resource', 'human_resource', 1, 8, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (6, 'Academic', 'academic', 1, 9, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (7, 'Homework', 'homework', 1, 12, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (8, 'Attachments Book', 'attachments_book', 1, 11, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (9, 'Exam Master', 'exam_master', 1, 13, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (10, 'Hostel', 'hostel', 1, 14, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (11, 'Transport', 'transport', 1, 15, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (12, 'Attendance', 'attendance', 1, 16, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (13, 'Library', 'library', 1, 17, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (14, 'Events', 'events', 1, 18, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (15, 'Bulk Sms And Email', 'bulk_sms_and_email', 1, 19, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (16, 'Student Accounting', 'student_accounting', 1, 20, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (17, 'Office Accounting', 'office_accounting', 1, 21, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (18, 'Settings', 'settings', 1, 23, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (19, 'Live Class', 'live_class', 1, 10, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (20, 'Certificate', 'certificate', 1, 7, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (21, 'Card Management', 'card_management', 1, 6, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (22, 'Website', 'website', 1, 2, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (23, 'Online Exam', 'online_exam', 1, 22, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (24, 'Reception', 'reception', 1, 23, '2019-05-26 18:23:00');


#
# TABLE STRUCTURE FOR: postal_record
#

DROP TABLE IF EXISTS `postal_record`;

CREATE TABLE `postal_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_title` varchar(255) DEFAULT NULL,
  `receiver_title` varchar(255) DEFAULT NULL,
  `reference_no` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `date` date NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(250) NOT NULL,
  `confidential` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: promotion_history
#

DROP TABLE IF EXISTS `promotion_history`;

CREATE TABLE `promotion_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `pre_class` int(11) NOT NULL,
  `pre_section` int(11) NOT NULL,
  `pre_session` int(11) NOT NULL,
  `pro_class` int(11) NOT NULL,
  `pro_section` int(11) NOT NULL,
  `pro_session` int(11) NOT NULL,
  `prev_due` float NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: question_group
#

DROP TABLE IF EXISTS `question_group`;

CREATE TABLE `question_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: questions
#

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `level` tinyint(1) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `subject_id` int(11) NOT NULL DEFAULT 0,
  `group_id` int(11) NOT NULL,
  `question` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_1` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_2` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_3` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_4` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `answer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `mark` float(10,2) NOT NULL DEFAULT 0.00,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: questions_manage
#

DROP TABLE IF EXISTS `questions_manage`;

CREATE TABLE `questions_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `onlineexam_id` int(11) DEFAULT NULL,
  `marks` float(10,2) NOT NULL DEFAULT 0.00,
  `neg_marks` float(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onlineexam_id` (`onlineexam_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: rm_sessions
#

DROP TABLE IF EXISTS `rm_sessions`;

CREATE TABLE `rm_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b4a7e2afda18676cc4431c47a41fc7de6add3c2', '187.86.166.63', 1676172828, '__ci_last_regenerate|i:1676172828;name|s:8:\"humberto\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"4\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b4e0494c345c034a320f760e8d463d156564f325', '187.86.166.63', 1676173767, '__ci_last_regenerate|i:1676173767;name|s:8:\"humberto\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"spanish\";set_session_id|s:1:\"4\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f42ab2d19f9733e661b597cd94aaa7378e5187fb', '187.86.166.63', 1676173767, '__ci_last_regenerate|i:1676173767;name|s:8:\"humberto\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"spanish\";set_session_id|s:1:\"4\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f56322cfc88e78389980fdda411abe408a882d4e', '187.86.166.63', 1676173132, '__ci_last_regenerate|i:1676173132;name|s:8:\"humberto\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"spanish\";set_session_id|s:1:\"4\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7350e5a33adaa64f6972f14fcd6a7b7fb6e2521', '187.86.166.63', 1676173465, '__ci_last_regenerate|i:1676173465;name|s:8:\"humberto\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"spanish\";set_session_id|s:1:\"4\";loggedin|b:1;');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Teacher', 'teacher', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (4, 'Accountant', 'accountant', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (5, 'Librarian', 'librarian', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (6, 'Parent', 'parent', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (7, 'Student', 'student', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (8, 'Receptionist', 'receptionist', '1');


#
# TABLE STRUCTURE FOR: salary_template
#

DROP TABLE IF EXISTS `salary_template`;

CREATE TABLE `salary_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL DEFAULT '0',
  `branch_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: salary_template_details
#

DROP TABLE IF EXISTS `salary_template_details`;

CREATE TABLE `salary_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: schoolyear
#

DROP TABLE IF EXISTS `schoolyear`;

CREATE TABLE `schoolyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (1, '2019-2020', 1, '2020-02-25 14:35:41', '2020-02-26 16:54:49');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (3, '2020-2021', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (4, '2021-2022', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (5, '2022-2023', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (6, '2023-2024', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (7, '2024-2025', 1, '2020-02-25 14:35:41', '2020-02-26 01:20:04');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (9, '2025-2026', 1, '2020-02-26 02:00:10', '2020-02-26 13:00:24');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `capacity` varchar(20) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sections_allocation
#

DROP TABLE IF EXISTS `sections_allocation`;

CREATE TABLE `sections_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sms_api
#

DROP TABLE IF EXISTS `sms_api`;

CREATE TABLE `sms_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_api` (`id`, `name`) VALUES (1, 'twilio');
INSERT INTO `sms_api` (`id`, `name`) VALUES (2, 'clickatell');
INSERT INTO `sms_api` (`id`, `name`) VALUES (3, 'msg91');
INSERT INTO `sms_api` (`id`, `name`) VALUES (4, 'bulksms');
INSERT INTO `sms_api` (`id`, `name`) VALUES (5, 'textlocal');
INSERT INTO `sms_api` (`id`, `name`) VALUES (6, 'smscountry');
INSERT INTO `sms_api` (`id`, `name`) VALUES (7, 'bulksmsbd');


#
# TABLE STRUCTURE FOR: sms_credential
#

DROP TABLE IF EXISTS `sms_credential`;

CREATE TABLE `sms_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_api_id` int(11) NOT NULL,
  `field_one` varchar(300) NOT NULL,
  `field_two` varchar(300) NOT NULL,
  `field_three` varchar(300) NOT NULL,
  `field_four` varchar(300) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sms_template
#

DROP TABLE IF EXISTS `sms_template`;

CREATE TABLE `sms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (1, 'admission', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (2, 'fee_collection', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {paid_amount}, {paid_date} ');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (3, 'attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (4, 'exam_attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (5, 'exam_results', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}, {marks}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (6, 'homework', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {subject}, {date_of_homework}, {date_of_submission}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (7, 'live_class', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {date_of_live_class}, {start_time}, {end_time}, {host_by}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (8, 'online_exam_publish', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_title}, {start_time}, {end_time}, {time_duration}, {attempt}, {passing_mark}, {exam_fee}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (9, 'student_birthday_wishes', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {birthday}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (10, 'staff_birthday_wishes', '{name}, {birthday}, {joining_date}');


#
# TABLE STRUCTURE FOR: sms_template_details
#

DROP TABLE IF EXISTS `sms_template_details`;

CREATE TABLE `sms_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `dlt_template_id` varchar(255) DEFAULT NULL,
  `notify_student` tinyint(3) NOT NULL DEFAULT 1,
  `notify_parent` tinyint(3) NOT NULL DEFAULT 1,
  `template_body` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `experience_details` varchar(255) DEFAULT NULL,
  `total_experience` varchar(255) DEFAULT NULL,
  `designation` int(11) NOT NULL,
  `joining_date` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `salary_template_id` int(11) DEFAULT 0,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (1, '1406be7', 'humberto', 0, '', NULL, NULL, 0, '2023-02-12', '', '', '', '', '', '', '', 'admin@gmail.com', 0, NULL, NULL, NULL, NULL, NULL, '2023-02-11 22:27:32', NULL);


#
# TABLE STRUCTURE FOR: staff_attendance
#

DROP TABLE IF EXISTS `staff_attendance`;

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `status` varchar(11) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_bank_account
#

DROP TABLE IF EXISTS `staff_bank_account`;

CREATE TABLE `staff_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_department
#

DROP TABLE IF EXISTS `staff_department`;

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_designation
#

DROP TABLE IF EXISTS `staff_designation`;

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_documents
#

DROP TABLE IF EXISTS `staff_documents`;

CREATE TABLE `staff_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=793 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 3, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (2, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (3, 3, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (4, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (5, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (6, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (7, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (8, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (9, 3, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (10, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (11, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (12, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (13, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (14, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (15, 3, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (16, 3, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (17, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (18, 3, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (20, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (21, 3, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (22, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (23, 3, 22, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (24, 3, 23, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (25, 3, 24, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (26, 3, 25, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (27, 3, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (28, 3, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (29, 3, 28, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (30, 3, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (31, 3, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (32, 3, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (33, 3, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (34, 3, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (35, 3, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (36, 3, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (37, 3, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (38, 3, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (39, 3, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (40, 3, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (41, 3, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (42, 3, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (43, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (44, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (45, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (46, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (47, 3, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (48, 3, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (49, 3, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (50, 3, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (51, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (52, 3, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (53, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (54, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (55, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (56, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (57, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (58, 3, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (59, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (60, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (61, 3, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (62, 3, 59, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (63, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (64, 3, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (65, 3, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (66, 3, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (67, 3, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (68, 3, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (69, 3, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (70, 3, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (71, 3, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (72, 3, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (73, 3, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (74, 3, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (75, 3, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (76, 3, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (77, 3, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (78, 3, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (79, 3, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (80, 3, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (81, 3, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (82, 3, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (83, 3, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (84, 3, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (85, 3, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (86, 3, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (87, 3, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 2, 2, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 2, 4, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 2, 5, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 2, 30, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 2, 6, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 2, 11, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 2, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 2, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 2, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 2, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 2, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 2, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 2, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 2, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 2, 24, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 2, 25, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 2, 26, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 2, 27, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 2, 28, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 2, 29, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 2, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 2, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 2, 37, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 2, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 2, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 2, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 2, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 2, 79, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 2, 40, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 2, 41, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 2, 42, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 2, 43, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 2, 44, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 2, 45, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 2, 46, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 2, 47, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 2, 48, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 2, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 2, 50, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 2, 51, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 2, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 2, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 2, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 2, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 2, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 2, 59, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 2, 60, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 2, 61, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 2, 62, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 2, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 2, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 2, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 2, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 2, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 2, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 2, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 2, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 2, 76, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 2, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 2, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 2, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 2, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 2, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 2, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 2, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 2, 82, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 2, 83, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 2, 84, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 2, 85, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 2, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 2, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 7, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 7, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 7, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 7, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 7, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 7, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 7, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 7, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 7, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 7, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 7, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 7, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 7, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 7, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 7, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 7, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 7, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 7, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 7, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 7, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 7, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 7, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 7, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 7, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 7, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 7, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 7, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 7, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 7, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 7, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 7, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 7, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 7, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 7, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 7, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 7, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 89, 89, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 2, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 2, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 2, 90, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 91, 91, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 92, 92, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 2, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 2, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 93, 93, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 94, 94, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 95, 95, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 96, 96, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 2, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 2, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 2, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 2, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 97, 97, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 98, 98, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 2, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 2, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 99, 99, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 100, 100, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 101, 101, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 102, 102, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 2, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 2, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 2, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 2, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 103, 103, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 2, 103, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (296, 3, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (297, 3, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (298, 3, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (299, 3, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (300, 3, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (301, 3, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (302, 3, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (303, 3, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (304, 3, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (305, 3, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (306, 3, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (307, 3, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (308, 3, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (309, 3, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (310, 3, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (311, 3, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 4, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 4, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 4, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 4, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 4, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 4, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 4, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 4, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 4, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 4, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 4, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 4, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 4, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 4, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 4, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 4, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 4, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 4, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 4, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 4, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 4, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 4, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 4, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 4, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 4, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 4, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 4, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 4, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 4, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 4, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (353, 4, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (354, 4, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (355, 4, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (356, 4, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (357, 4, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (358, 4, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (359, 4, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (360, 4, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (361, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (362, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (363, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (364, 4, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (365, 4, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (366, 4, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (367, 4, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (368, 4, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (369, 4, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (370, 4, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (371, 4, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (372, 4, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (373, 4, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (374, 4, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (375, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (376, 4, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (377, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (378, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (379, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (380, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (381, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (382, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (383, 4, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (384, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (385, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (386, 4, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (387, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (388, 4, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (389, 4, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (390, 4, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (391, 4, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (392, 4, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (393, 4, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (394, 4, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (395, 4, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (396, 4, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (397, 4, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (398, 4, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (399, 4, 76, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (400, 4, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (401, 4, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (402, 4, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (403, 4, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (404, 4, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (405, 4, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (406, 4, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (407, 4, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (408, 4, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (409, 4, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (410, 4, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (411, 4, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (412, 4, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (413, 4, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (414, 4, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (415, 5, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (416, 5, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (417, 5, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (418, 5, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (419, 5, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (420, 5, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (421, 5, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (422, 5, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (423, 5, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (424, 5, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (425, 5, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (426, 5, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (427, 5, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (428, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (429, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (430, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (431, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (432, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (433, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (434, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (435, 5, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (436, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (437, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (438, 5, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (439, 5, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (440, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (441, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (442, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (443, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (444, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (446, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (447, 5, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (448, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (449, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (450, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (451, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (452, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (453, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (454, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (455, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (456, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (457, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (458, 5, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (459, 5, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (460, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (461, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (462, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (463, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (464, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (465, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (466, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (467, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (468, 5, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (469, 5, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (470, 5, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (471, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (472, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (473, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (474, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (475, 5, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (476, 5, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (477, 5, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (478, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (479, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (480, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (481, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (482, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (483, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (484, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (485, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (486, 5, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (487, 5, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (488, 5, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (489, 5, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (490, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (491, 5, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (492, 5, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (493, 5, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (494, 5, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (495, 5, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (496, 5, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (497, 5, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (498, 5, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (499, 5, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (500, 5, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (501, 5, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (502, 5, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (503, 5, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (504, 5, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (505, 5, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (506, 5, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (507, 5, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (508, 5, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (509, 5, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (510, 5, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (511, 5, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (512, 5, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (513, 5, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (514, 5, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (515, 5, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (516, 5, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (517, 5, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (518, 104, 104, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (519, 2, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (520, 4, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (521, 2, 18, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (522, 2, 105, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (523, 2, 106, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (524, 2, 107, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (525, 2, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (526, 2, 108, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (527, 3, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (528, 3, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (529, 3, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (530, 3, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (531, 3, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (532, 3, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (533, 3, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (534, 2, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (535, 2, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (536, 2, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (537, 2, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (538, 2, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (539, 2, 115, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (540, 2, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (541, 2, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (542, 3, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (543, 3, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (544, 3, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (545, 3, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (546, 3, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (547, 3, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (548, 3, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (549, 3, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (550, 2, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (551, 2, 118, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (552, 2, 119, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (553, 2, 120, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (554, 2, 121, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (555, 2, 122, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (556, 2, 123, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (557, 2, 124, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (558, 2, 125, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (559, 2, 126, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (560, 3, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (561, 3, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (562, 3, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (563, 3, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (564, 3, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (565, 3, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (566, 3, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (567, 3, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (568, 3, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (569, 3, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (570, 3, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (571, 2, 129, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (572, 2, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (573, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (574, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (575, 2, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (576, 4, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (577, 4, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (578, 4, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (579, 4, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (580, 4, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (581, 4, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (582, 4, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (583, 4, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (584, 4, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (585, 4, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (586, 4, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (587, 4, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (588, 4, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (589, 4, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (590, 4, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (591, 4, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (592, 4, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (593, 4, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (594, 4, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (595, 4, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (596, 4, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (597, 4, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (598, 4, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (599, 4, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (600, 4, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (601, 4, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (602, 4, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (603, 4, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (604, 4, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (605, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (606, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (607, 2, 133, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (608, 3, 133, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (609, 2, 134, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (610, 2, 136, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (611, 2, 137, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (612, 2, 138, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (613, 2, 139, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (614, 2, 140, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (615, 2, 135, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (616, 3, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (617, 3, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (618, 3, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (619, 3, 130, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (620, 3, 136, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (621, 3, 137, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (622, 3, 138, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (623, 3, 139, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (624, 3, 140, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (625, 3, 134, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (626, 3, 135, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (627, 2, 141, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (628, 2, 142, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (629, 2, 143, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (630, 2, 144, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (631, 2, 145, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (632, 2, 146, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (633, 2, 147, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (634, 2, 148, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (635, 2, 149, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (636, 2, 150, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (637, 2, 151, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (638, 2, 152, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (639, 2, 153, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (640, 8, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (641, 8, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (642, 8, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (643, 8, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (644, 8, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (645, 8, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (646, 8, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (647, 8, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (648, 8, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (649, 8, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (650, 8, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (651, 8, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (652, 8, 151, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (653, 8, 152, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (654, 8, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (655, 8, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (656, 8, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (657, 8, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (658, 8, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (659, 8, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (660, 8, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (661, 8, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (662, 8, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (663, 8, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (664, 8, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (665, 8, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (666, 8, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (667, 8, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (668, 8, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (669, 8, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (670, 8, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (671, 8, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (672, 8, 7, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (673, 8, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (674, 8, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (675, 8, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (676, 8, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (677, 8, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (678, 8, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (679, 8, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (680, 8, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (681, 8, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (682, 8, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (683, 8, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (684, 8, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (685, 8, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (686, 8, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (687, 8, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (688, 8, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (689, 8, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (690, 8, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (691, 8, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (692, 8, 18, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (693, 8, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (694, 8, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (695, 8, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (696, 8, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (697, 8, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (698, 8, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (699, 8, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (700, 8, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (701, 8, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (702, 8, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (703, 8, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (704, 8, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (705, 8, 133, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (706, 8, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (707, 8, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (708, 8, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (709, 8, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (710, 8, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (711, 8, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (712, 8, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (713, 8, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (714, 8, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (715, 8, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (716, 8, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (717, 8, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (718, 8, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (719, 8, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (720, 8, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (721, 8, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (722, 8, 153, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (723, 8, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (724, 8, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (725, 8, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (726, 8, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (727, 8, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (728, 8, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (729, 8, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (730, 8, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (731, 8, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (732, 8, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (733, 8, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (734, 8, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (735, 8, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (736, 8, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (737, 8, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (738, 8, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (739, 8, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (740, 8, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (741, 8, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (742, 8, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (743, 8, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (744, 8, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (745, 8, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (746, 8, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (747, 8, 149, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (748, 8, 150, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (749, 8, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (750, 8, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (751, 8, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (752, 8, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (753, 8, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (754, 8, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (755, 8, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (756, 8, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (757, 8, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (758, 8, 130, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (759, 8, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (760, 8, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (761, 8, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (762, 8, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (763, 8, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (764, 8, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (765, 8, 136, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (766, 8, 137, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (767, 8, 138, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (768, 8, 139, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (769, 8, 140, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (770, 8, 141, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (771, 8, 142, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (772, 8, 143, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (773, 8, 144, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (774, 8, 145, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (775, 8, 146, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (776, 8, 147, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (777, 8, 148, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (778, 8, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (779, 8, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (780, 8, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (781, 8, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (782, 8, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (783, 8, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (784, 8, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (785, 8, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (786, 8, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (787, 8, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (788, 8, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (789, 8, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (790, 8, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (791, 8, 134, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (792, 8, 135, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: student
#

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_no` varchar(100) DEFAULT NULL,
  `admission_date` varchar(100) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `blood_group` varchar(100) DEFAULT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `current_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `mobileno` varchar(100) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT 0,
  `email` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `route_id` int(11) NOT NULL DEFAULT 0,
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  `hostel_id` int(11) NOT NULL DEFAULT 0,
  `room_id` int(11) NOT NULL DEFAULT 0,
  `previous_details` text DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_admission_fields
#

DROP TABLE IF EXISTS `student_admission_fields`;

CREATE TABLE `student_admission_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_attendance
#

DROP TABLE IF EXISTS `student_attendance`;

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` text DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_category
#

DROP TABLE IF EXISTS `student_category`;

CREATE TABLE `student_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_documents
#

DROP TABLE IF EXISTS `student_documents`;

CREATE TABLE `student_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_fields
#

DROP TABLE IF EXISTS `student_fields`;

CREATE TABLE `student_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) NOT NULL,
  `default_status` tinyint(1) NOT NULL DEFAULT 1,
  `default_required` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (1, 'roll', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (2, 'last_name', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (3, 'gender', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (4, 'birthday', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (5, 'admission_date', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (6, 'category', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (7, 'section', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (8, 'religion', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (9, 'caste', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (10, 'blood_group', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (11, 'mother_tongue', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (12, 'present_address', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (13, 'permanent_address', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (14, 'city', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (15, 'state', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (16, 'student_email', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (17, 'student_mobile_no', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (18, 'student_photo', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (19, 'previous_school_details', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (20, 'guardian_name', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (21, 'guardian_relation', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (22, 'father_name', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (23, 'mother_name', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (24, 'guardian_occupation', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (25, 'guardian_income', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (26, 'guardian_education', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (27, 'guardian_email', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (28, 'guardian_mobile_no', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (29, 'guardian_address', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (30, 'guardian_photo', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (31, 'upload_documents', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (32, 'guardian_city', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (33, 'guardian_state', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (34, 'first_name', 1, 1, '2022-04-25 20:27:04');


#
# TABLE STRUCTURE FOR: student_profile_fields
#

DROP TABLE IF EXISTS `student_profile_fields`;

CREATE TABLE `student_profile_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject_code` varchar(200) NOT NULL,
  `subject_type` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `subject_author` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: teacher_allocation
#

DROP TABLE IF EXISTS `teacher_allocation`;

CREATE TABLE `teacher_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: teacher_note
#

DROP TABLE IF EXISTS `teacher_note`;

CREATE TABLE `teacher_note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `file_name` longtext NOT NULL,
  `enc_name` longtext NOT NULL,
  `type_id` int(11) NOT NULL,
  `class_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `border_mode` varchar(200) NOT NULL,
  `dark_skin` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'true', 'true', '2018-10-23 12:59:38', '2020-05-10 14:08:47');


#
# TABLE STRUCTURE FOR: timetable_class
#

DROP TABLE IF EXISTS `timetable_class`;

CREATE TABLE `timetable_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `break` varchar(11) DEFAULT 'false',
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_room` varchar(100) DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `day` varchar(20) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: timetable_exam
#

DROP TABLE IF EXISTS `timetable_exam`;

CREATE TABLE `timetable_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `time_start` varchar(20) NOT NULL,
  `time_end` varchar(20) NOT NULL,
  `mark_distribution` text NOT NULL,
  `hall_id` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `voucher_head_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `bal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `date` date NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transactions_links
#

DROP TABLE IF EXISTS `transactions_links`;

CREATE TABLE `transactions_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) DEFAULT NULL,
  `deposit` tinyint(3) DEFAULT NULL,
  `expense` tinyint(3) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_assign
#

DROP TABLE IF EXISTS `transport_assign`;

CREATE TABLE `transport_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `stoppage_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_route
#

DROP TABLE IF EXISTS `transport_route`;

CREATE TABLE `transport_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `start_place` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `stop_place` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_stoppage
#

DROP TABLE IF EXISTS `transport_stoppage`;

CREATE TABLE `transport_stoppage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_position` varchar(255) NOT NULL,
  `stop_time` time NOT NULL,
  `route_fare` decimal(18,2) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_vehicle
#

DROP TABLE IF EXISTS `transport_vehicle`;

CREATE TABLE `transport_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_no` longtext NOT NULL,
  `capacity` longtext NOT NULL,
  `insurance_renewal` longtext NOT NULL,
  `driver_name` longtext NOT NULL,
  `driver_phone` longtext NOT NULL,
  `driver_license` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: visitor_log
#

DROP TABLE IF EXISTS `visitor_log`;

CREATE TABLE `visitor_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `purpose_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `entry_time` time DEFAULT NULL,
  `exit_time` time DEFAULT NULL,
  `number_of_visitor` float DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `token_pass` varchar(255) DEFAULT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: visitor_purpose
#

DROP TABLE IF EXISTS `visitor_purpose`;

CREATE TABLE `visitor_purpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: voucher_head
#

DROP TABLE IF EXISTS `voucher_head`;

CREATE TABLE `voucher_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `system` tinyint(1) DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: whatsapp_agent
#

DROP TABLE IF EXISTS `whatsapp_agent`;

CREATE TABLE `whatsapp_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_name` varchar(255) NOT NULL,
  `agent_image` varchar(255) NOT NULL,
  `agent_designation` varchar(255) NOT NULL,
  `whataspp_number` varchar(255) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `weekend` varchar(20) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: whatsapp_chat
#

DROP TABLE IF EXISTS `whatsapp_chat`;

CREATE TABLE `whatsapp_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `header_title` varchar(255) NOT NULL,
  `subtitle` varchar(355) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT NULL,
  `popup_message` varchar(255) DEFAULT NULL,
  `frontend_enable_chat` tinyint(1) NOT NULL DEFAULT 0,
  `backend_enable_chat` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `whatsapp_chat` (`id`, `header_title`, `subtitle`, `footer_text`, `popup_message`, `frontend_enable_chat`, `backend_enable_chat`, `branch_id`, `created_at`) VALUES (1, 'Start a Conversation', 'Start a Conversation', 'Use this feature to chat with our agent.', NULL, 1, 1, 1, '2022-02-16 13:49:13');
INSERT INTO `whatsapp_chat` (`id`, `header_title`, `subtitle`, `footer_text`, `popup_message`, `frontend_enable_chat`, `backend_enable_chat`, `branch_id`, `created_at`) VALUES (2, 'Conversation', 'Hi! Click one of our members below to chat on WhatsApp ;)', 'Use this feature to chat with our agent.', NULL, 1, 1, 2, '2022-02-16 13:49:13');


#
# TABLE STRUCTURE FOR: zoom_own_api
#

DROP TABLE IF EXISTS `zoom_own_api`;

CREATE TABLE `zoom_own_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `zoom_api_key` varchar(255) NOT NULL,
  `zoom_api_secret` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

