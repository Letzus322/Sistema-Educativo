<?php

namespace PhpOffice\Math\Element;

class Row extends AbstractGroupElement
{
}
