<?php

namespace PhpOffice\Math\Element;

class Operator extends AbstractElement
{
    /**
     * @var string
     */
    protected $value;

    public function __construct(string $value)
    {
        $this->value = $value;
    }

    public function getValue(): string
    {
        return $this->value;
    }
}
